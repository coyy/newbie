namespace License.RNCryptor
{
	public enum AesMode : short
	{
		CTR,
		CBC
	}
}
