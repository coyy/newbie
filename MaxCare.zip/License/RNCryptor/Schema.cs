namespace License.RNCryptor
{
	public enum Schema : short
	{
		V0,
		V1,
		V2,
		V3
	}
}
