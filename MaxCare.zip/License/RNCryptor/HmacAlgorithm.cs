namespace License.RNCryptor
{
	public enum HmacAlgorithm : short
	{
		SHA1,
		SHA256
	}
}
