namespace License.RNCryptor
{
	public enum Options : short
	{
		V0,
		V1
	}
}
