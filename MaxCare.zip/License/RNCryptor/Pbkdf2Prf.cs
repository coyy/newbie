namespace License.RNCryptor
{
	public enum Pbkdf2Prf : short
	{
		SHA1
	}
}
