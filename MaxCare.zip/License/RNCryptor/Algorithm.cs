namespace License.RNCryptor
{
	public enum Algorithm : short
	{
		AES
	}
}
