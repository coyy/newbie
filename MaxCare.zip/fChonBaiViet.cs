using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using MCommon;
using MetroFramework.Controls;

namespace maxcare
{
	public class fChonBaiViet : Form
	{
		private bool checkAll = false;

		private List<string> lstData = new List<string>();

		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Panel panel1;

		private BunifuDragControl bunifuDragControl1;

		private ToolTip toolTip1;

		private Button btnCancel;

		private Button btnSave;

		private GroupBox groupBox2;

		private GroupBox groupBox1;

		public DataGridView dgvDSBaiViet;

		private MetroButton metroButton1;

		private Label label1;

		private ComboBox cbbChuDe;

		private Label lblCountAcc;

		private Label label7;

		private BunifuCards bunifuCards2;

		private Panel pnlHeader;

		private PictureBox pictureBox1;

		private Button btnMinimize;

		private BunifuCustomLabel bunifuCustomLabel1;

		private Label label2;

		public DataGridView dgvBaiVietDaChon;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem thêmBàiViếtToolStripMenuItem;

		private ToolStripMenuItem sửaBàiViếtToolStripMenuItem;

		private ToolStripMenuItem xóaBàiViếtToolStripMenuItem;

		private ToolStripMenuItem làmMớiDanhSáchToolStripMenuItem;

		private ToolStripMenuItem chiTiếtBàiViếtToolStripMenuItem;

		private ToolStripMenuItem hiểnThịTấtCảBàiViếtToolStripMenuItem;

		private Label label3;

		private DataGridViewTextBoxColumn cStt1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;

		private DataGridViewTextBoxColumn cId;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn cStt;

		private DataGridViewTextBoxColumn cChuDe;

		private DataGridViewTextBoxColumn cIdBaiViet;

		private DataGridViewTextBoxColumn cTieuDe;

		private DataGridViewTextBoxColumn cAnh;

		private DataGridViewTextBoxColumn cVideo;

		public fChonBaiViet(ref List<string> lstData)
		{
			InitializeComponent();
			LoadcbbChuDe();
			this.lstData = lstData;
			RefreshDtgvDaChon();
		}

		private void RefreshDtgvDaChon()
		{
			if (lstData.Count <= 0)
			{
				return;
			}
			dgvBaiVietDaChon.Rows.Clear();
			for (int i = 0; i < lstData.Count; i++)
			{
				try
				{
					BaiViet infoPosyByID = GetInfoPosyByID(lstData[i]);
					dgvBaiVietDaChon.Rows.Add(i + 1, infoPosyByID.tenChuDe, infoPosyByID.id, infoPosyByID.tieuDe, infoPosyByID.anh.Split('|').Length - 1, infoPosyByID.video.Split('|').Length - 1);
				}
				catch
				{
					lstData.RemoveAt(i--);
				}
			}
		}

		private BaiViet GetInfoPosyByID(string id)
		{
			BaiViet result = new BaiViet();
			try
			{
				result = CommonSQL.GetListBaiVietByID(id)[0];
			}
			catch
			{
			}
			return result;
		}

		private void LoadcbbChuDe(bool check = false)
		{
			int selectedIndex = cbbChuDe.SelectedIndex;
			cbbChuDe.Items.Clear();
			List<string> listChuDe = CommonSQL.GetListChuDe();
			for (int i = 0; i < listChuDe.Count; i++)
			{
				cbbChuDe.Items.Add(listChuDe[i]);
			}
			if (cbbChuDe.Items.Count == 0)
			{
				cbbChuDe.SelectedIndex = -1;
			}
			else if (cbbChuDe.Items.Count == 1)
			{
				cbbChuDe.SelectedIndex = 0;
			}
			else if (selectedIndex == -1)
			{
				cbbChuDe.SelectedIndex = 0;
			}
			else if (cbbChuDe.Items.Count - 1 < selectedIndex)
			{
				cbbChuDe.SelectedIndex = cbbChuDe.Items.Count - 1;
			}
			else
			{
				cbbChuDe.SelectedIndex = selectedIndex;
			}
			LoadDsBaiVietByChuDe(check);
			RefreshDtgvDaChon();
		}

		private void LoadDsBaiVietByChuDe(bool isLoadAll = true)
		{
			try
			{
				dgvDSBaiViet.Rows.Clear();
				List<BaiViet> list = new List<BaiViet>();
				list = (isLoadAll ? CommonSQL.GetListBaiViet() : CommonSQL.GetListBaiViet(cbbChuDe.SelectedItem.ToString()));
				BaiViet baiViet = new BaiViet();
				for (int i = 0; i < list.Count; i++)
				{
					baiViet = list[i];
					dgvDSBaiViet.Rows.Add(i + 1, baiViet.tenChuDe, baiViet.id, baiViet.tieuDe, baiViet.anh.Split('|').Length - 1, baiViet.video.Split('|').Length - 1);
				}
			}
			catch
			{
			}
		}

		private void BtnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void FConfigGenneral_Load(object sender, EventArgs e)
		{
		}

		private void BtnSave_Click(object sender, EventArgs e)
		{
			lstData.Clear();
			for (int i = 0; i < dgvBaiVietDaChon.RowCount; i++)
			{
				lstData.Add(dgvBaiVietDaChon.Rows[i].Cells["cId"].Value.ToString());
			}
			if (MessageBox.Show("Lưu thành công, bạn có muốn đóng cửa sổ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				Close();
			}
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fDanhSachChuDe());
			LoadcbbChuDe(checkAll);
		}

		private void thêmBàiViếtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				int count = CommonSQL.GetListBaiViet().Count;
				MCommon.Common.ShowForm(new fThemBaiViet(cbbChuDe.SelectedIndex));
				int count2 = CommonSQL.GetListBaiViet().Count;
				if (count2 > count)
				{
					BaiViet baiViet = CommonSQL.GetBaiVietNewest()[0];
					dgvDSBaiViet.Rows.Add(dgvDSBaiViet.RowCount + 1, baiViet.tenChuDe, baiViet.id, baiViet.tieuDe, baiViet.anh.Split('|').Length - 1, baiViet.video.Split('|').Length - 1);
				}
			}
			catch
			{
			}
		}

		private void sửaBàiViếtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				DataGridViewRow dataGridViewRow = dgvDSBaiViet.SelectedRows[0];
				int idBaiviet = Convert.ToInt32(dataGridViewRow.Cells[2].Value);
				MCommon.Common.ShowForm(new fSuaBaiViet(idBaiviet));
				BaiViet baiViet = CommonSQL.GetListBaiVietByID(idBaiviet.ToString())[0];
				MCommon.Common.SetStatusDataGridView(dgvDSBaiViet, dataGridViewRow.Index, "cTieuDe", baiViet.tieuDe);
				MCommon.Common.SetStatusDataGridView(dgvDSBaiViet, dataGridViewRow.Index, "cAnh", baiViet.anh.Split('|').Length - 1);
				MCommon.Common.SetStatusDataGridView(dgvDSBaiViet, dataGridViewRow.Index, "cVideo", baiViet.video.Split('|').Length - 1);
				RefreshDtgvDaChon();
			}
			catch
			{
			}
		}

		private bool checkTrung(string id)
		{
			bool result = false;
			for (int i = 0; i < dgvBaiVietDaChon.Rows.Count; i++)
			{
				if (id == dgvBaiVietDaChon.Rows[i].Cells[2].Value.ToString())
				{
					result = true;
					break;
				}
			}
			return result;
		}

		private void dtgvKichBan_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			int num = Convert.ToInt32(dgvDSBaiViet.SelectedRows[0].Cells[2].Value);
			List<BaiViet> listBaiVietByID = CommonSQL.GetListBaiVietByID(num.ToString());
			BaiViet baiViet = new BaiViet();
			for (int i = 0; i < listBaiVietByID.Count; i++)
			{
				if (checkTrung(num.ToString()))
				{
					break;
				}
				baiViet = listBaiVietByID[i];
				dgvBaiVietDaChon.Rows.Add(dgvBaiVietDaChon.Rows.Count + 1, baiViet.tenChuDe, baiViet.id, baiViet.tieuDe, baiViet.anh.Split('|').Length - 1, baiViet.video.Split('|').Length - 1);
				lstData.Add(baiViet.id.ToString());
			}
			lblCountAcc.Text = dgvBaiVietDaChon.Rows.Count.ToString();
		}

		private void chiTiếtBàiViếtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				int idBaiviet = Convert.ToInt32(dgvDSBaiViet.SelectedRows[0].Cells[2].Value);
				fChiTietBaiViet fChiTietBaiViet2 = new fChiTietBaiViet(idBaiviet);
				fChiTietBaiViet2.Show();
			}
			catch
			{
			}
		}

		private void UpdateSTTOnDtgvAcc()
		{
			for (int i = 0; i < dgvBaiVietDaChon.RowCount; i++)
			{
				MCommon.Common.SetStatusDataGridView(dgvBaiVietDaChon, i, "cStt1", i + 1);
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			dgvDSBaiViet.Rows.Clear();
			List<BaiViet> listBaiViet = CommonSQL.GetListBaiViet(cbbChuDe.SelectedItem.ToString());
			BaiViet baiViet = new BaiViet();
			for (int i = 0; i < listBaiViet.Count; i++)
			{
				try
				{
					baiViet = listBaiViet[i];
					dgvDSBaiViet.Rows.Add(i + 1, baiViet.tenChuDe, baiViet.id, baiViet.tieuDe, baiViet.anh.Split('|').Length - 1, baiViet.video.Split('|').Length - 1);
				}
				catch
				{
				}
			}
		}

		private void làmMớiDanhSáchToolStripMenuItem_Click(object sender, EventArgs e)
		{
			LoadDsBaiVietByChuDe(checkAll);
		}

		private void cbbChuDe_TextChanged(object sender, EventArgs e)
		{
		}

		private void hiểnThịTấtCảBàiViếtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			checkAll = true;
			dgvDSBaiViet.Rows.Clear();
			LoadDsBaiVietByChuDe(checkAll);
		}

		private void cbbChuDe_Click(object sender, EventArgs e)
		{
		}

		private void dgvBaiVietDaChon_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			foreach (DataGridViewRow selectedRow in dgvBaiVietDaChon.SelectedRows)
			{
				dgvBaiVietDaChon.Rows.RemoveAt(selectedRow.Index);
			}
			lblCountAcc.Text = dgvBaiVietDaChon.Rows.Count.ToString();
		}

		private void xóaBàiViếtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				DataGridViewRow dataGridViewRow = dgvDSBaiViet.SelectedRows[0];
				if (dataGridViewRow != null && MessageBox.Show("Bạn có muốn xóa bài viết này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					int id = Convert.ToInt32(dataGridViewRow.Cells[2].Value);
					CommonSQL.DeleteBaiViet(id);
					dgvDSBaiViet.Rows.Remove(dataGridViewRow);
					RefreshDtgvDaChon();
				}
			}
			catch
			{
			}
		}

		private void dgvDSBaiViet_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
		}

		private void dgvBaiVietDaChon_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
		{
			UpdateSTTOnDtgvAcc();
			lblCountAcc.Text = dgvBaiVietDaChon.Rows.Count.ToString();
		}

		private void dgvBaiVietDaChon_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			UpdateSTTOnDtgvAcc();
			lblCountAcc.Text = dgvBaiVietDaChon.Rows.Count.ToString();
		}

		private void cbbChuDe_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkAll = false;
			LoadDsBaiVietByChuDe(checkAll);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fChonBaiViet));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel1 = new System.Windows.Forms.Panel();
			bunifuCards2 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			btnMinimize = new System.Windows.Forms.Button();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			groupBox2 = new System.Windows.Forms.GroupBox();
			label3 = new System.Windows.Forms.Label();
			lblCountAcc = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			dgvBaiVietDaChon = new System.Windows.Forms.DataGridView();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label2 = new System.Windows.Forms.Label();
			metroButton1 = new MetroFramework.Controls.MetroButton();
			label1 = new System.Windows.Forms.Label();
			cbbChuDe = new System.Windows.Forms.ComboBox();
			dgvDSBaiViet = new System.Windows.Forms.DataGridView();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			thêmBàiViếtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			sửaBàiViếtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			xóaBàiViếtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			chiTiếtBàiViếtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			làmMớiDanhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			hiểnThịTấtCảBàiViếtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			btnCancel = new System.Windows.Forms.Button();
			btnSave = new System.Windows.Forms.Button();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			cStt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cChuDe = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cIdBaiViet = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cTieuDe = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cAnh = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cVideo = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cStt1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			panel1.SuspendLayout();
			bunifuCards2.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dgvBaiVietDaChon).BeginInit();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dgvDSBaiViet).BeginInit();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 5;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.SaddleBrown;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(270, 47);
			bunifuCards1.TabIndex = 12;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(bunifuCards2);
			panel1.Controls.Add(groupBox2);
			panel1.Controls.Add(groupBox1);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(btnSave);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(927, 517);
			panel1.TabIndex = 37;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			bunifuCards2.BackColor = System.Drawing.Color.White;
			bunifuCards2.BorderRadius = 0;
			bunifuCards2.BottomSahddow = true;
			bunifuCards2.color = System.Drawing.Color.SaddleBrown;
			bunifuCards2.Controls.Add(pnlHeader);
			bunifuCards2.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards2.LeftSahddow = false;
			bunifuCards2.Location = new System.Drawing.Point(0, 0);
			bunifuCards2.Name = "bunifuCards2";
			bunifuCards2.RightSahddow = true;
			bunifuCards2.ShadowDepth = 20;
			bunifuCards2.Size = new System.Drawing.Size(925, 37);
			bunifuCards2.TabIndex = 43;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(925, 31);
			pnlHeader.TabIndex = 9;
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(0, 4);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Image = (System.Drawing.Image)resources.GetObject("btnMinimize.Image");
			btnMinimize.Location = new System.Drawing.Point(896, 3);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(30, 30);
			btnMinimize.TabIndex = 9;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			btnMinimize.Click += new System.EventHandler(BtnCancel_Click);
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(925, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Chọn bình luận";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			groupBox2.BackColor = System.Drawing.Color.White;
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(lblCountAcc);
			groupBox2.Controls.Add(label7);
			groupBox2.Controls.Add(dgvBaiVietDaChon);
			groupBox2.Location = new System.Drawing.Point(465, 40);
			groupBox2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox2.Name = "groupBox2";
			groupBox2.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox2.Size = new System.Drawing.Size(454, 423);
			groupBox2.TabIndex = 41;
			groupBox2.TabStop = false;
			groupBox2.Text = "Bình luận cần sử dụng";
			label3.AutoSize = true;
			label3.ForeColor = System.Drawing.Color.Red;
			label3.Location = new System.Drawing.Point(6, 401);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(167, 16);
			label3.TabIndex = 80;
			label3.Text = "(Click đúp vào dòng để xóa)";
			lblCountAcc.AutoSize = true;
			lblCountAcc.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 163);
			lblCountAcc.ForeColor = System.Drawing.Color.Blue;
			lblCountAcc.Location = new System.Drawing.Point(349, 401);
			lblCountAcc.Name = "lblCountAcc";
			lblCountAcc.Size = new System.Drawing.Size(16, 16);
			lblCountAcc.TabIndex = 78;
			lblCountAcc.Text = "0";
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 163);
			label7.Location = new System.Drawing.Point(307, 401);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(44, 16);
			label7.TabIndex = 79;
			label7.Text = "Tổng:";
			dgvBaiVietDaChon.AllowUserToAddRows = false;
			dgvBaiVietDaChon.AllowUserToDeleteRows = false;
			dgvBaiVietDaChon.AllowUserToResizeRows = false;
			dgvBaiVietDaChon.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.Color.Teal;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dgvBaiVietDaChon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dgvBaiVietDaChon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgvBaiVietDaChon.Columns.AddRange(cStt1, dataGridViewTextBoxColumn2, cId, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, Column1);
			dgvBaiVietDaChon.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dgvBaiVietDaChon.Location = new System.Drawing.Point(6, 52);
			dgvBaiVietDaChon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			dgvBaiVietDaChon.MultiSelect = false;
			dgvBaiVietDaChon.Name = "dgvBaiVietDaChon";
			dgvBaiVietDaChon.RowHeadersVisible = false;
			dgvBaiVietDaChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dgvBaiVietDaChon.Size = new System.Drawing.Size(444, 345);
			dgvBaiVietDaChon.TabIndex = 76;
			dgvBaiVietDaChon.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvBaiVietDaChon_CellDoubleClick);
			dgvBaiVietDaChon.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(dgvBaiVietDaChon_RowsAdded);
			dgvBaiVietDaChon.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dgvBaiVietDaChon_RowsRemoved);
			groupBox1.BackColor = System.Drawing.Color.White;
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(metroButton1);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(cbbChuDe);
			groupBox1.Controls.Add(dgvDSBaiViet);
			groupBox1.Location = new System.Drawing.Point(3, 39);
			groupBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox1.Name = "groupBox1";
			groupBox1.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox1.Size = new System.Drawing.Size(456, 423);
			groupBox1.TabIndex = 42;
			groupBox1.TabStop = false;
			groupBox1.Text = "Danh sách bình luận";
			label2.AutoSize = true;
			label2.ForeColor = System.Drawing.Color.Red;
			label2.Location = new System.Drawing.Point(7, 401);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(174, 16);
			label2.TabIndex = 80;
			label2.Text = "(Click đúp vào dòng để chọn)";
			metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton1.Location = new System.Drawing.Point(282, 23);
			metroButton1.Name = "metroButton1";
			metroButton1.Size = new System.Drawing.Size(109, 25);
			metroButton1.TabIndex = 79;
			metroButton1.Text = "Quản lý chủ đề";
			metroButton1.UseSelectable = true;
			metroButton1.Click += new System.EventHandler(metroButton1_Click);
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(8, 27);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(53, 16);
			label1.TabIndex = 78;
			label1.Text = "Chủ đề:";
			cbbChuDe.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbChuDe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbChuDe.FormattingEnabled = true;
			cbbChuDe.Location = new System.Drawing.Point(64, 23);
			cbbChuDe.Name = "cbbChuDe";
			cbbChuDe.Size = new System.Drawing.Size(212, 24);
			cbbChuDe.TabIndex = 77;
			cbbChuDe.SelectedIndexChanged += new System.EventHandler(cbbChuDe_SelectedIndexChanged);
			dgvDSBaiViet.AllowUserToAddRows = false;
			dgvDSBaiViet.AllowUserToDeleteRows = false;
			dgvDSBaiViet.AllowUserToResizeRows = false;
			dgvDSBaiViet.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Teal;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dgvDSBaiViet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			dgvDSBaiViet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgvDSBaiViet.Columns.AddRange(cStt, cChuDe, cIdBaiViet, cTieuDe, cAnh, cVideo);
			dgvDSBaiViet.ContextMenuStrip = contextMenuStrip1;
			dgvDSBaiViet.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dgvDSBaiViet.Location = new System.Drawing.Point(10, 54);
			dgvDSBaiViet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			dgvDSBaiViet.MultiSelect = false;
			dgvDSBaiViet.Name = "dgvDSBaiViet";
			dgvDSBaiViet.RowHeadersVisible = false;
			dgvDSBaiViet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dgvDSBaiViet.Size = new System.Drawing.Size(440, 343);
			dgvDSBaiViet.TabIndex = 76;
			dgvDSBaiViet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvDSBaiViet_CellContentClick);
			dgvDSBaiViet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(dtgvKichBan_CellDoubleClick);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[6] { thêmBàiViếtToolStripMenuItem, sửaBàiViếtToolStripMenuItem, xóaBàiViếtToolStripMenuItem, chiTiếtBàiViếtToolStripMenuItem, làmMớiDanhSáchToolStripMenuItem, hiểnThịTấtCảBàiViếtToolStripMenuItem });
			contextMenuStrip1.Name = "contextMenuStrip1";
			contextMenuStrip1.Size = new System.Drawing.Size(202, 158);
			contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(contextMenuStrip1_Opening);
			thêmBàiViếtToolStripMenuItem.Name = "thêmBàiViếtToolStripMenuItem";
			thêmBàiViếtToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			thêmBàiViếtToolStripMenuItem.Text = "Thêm bình luận";
			thêmBàiViếtToolStripMenuItem.Click += new System.EventHandler(thêmBàiViếtToolStripMenuItem_Click);
			sửaBàiViếtToolStripMenuItem.Name = "sửaBàiViếtToolStripMenuItem";
			sửaBàiViếtToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			sửaBàiViếtToolStripMenuItem.Text = "Sửa bình luận";
			sửaBàiViếtToolStripMenuItem.Click += new System.EventHandler(sửaBàiViếtToolStripMenuItem_Click);
			xóaBàiViếtToolStripMenuItem.Name = "xóaBàiViếtToolStripMenuItem";
			xóaBàiViếtToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			xóaBàiViếtToolStripMenuItem.Text = "Xóa bình luận";
			xóaBàiViếtToolStripMenuItem.Click += new System.EventHandler(xóaBàiViếtToolStripMenuItem_Click);
			chiTiếtBàiViếtToolStripMenuItem.Name = "chiTiếtBàiViếtToolStripMenuItem";
			chiTiếtBàiViếtToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			chiTiếtBàiViếtToolStripMenuItem.Text = "Chi tiết bình luận";
			chiTiếtBàiViếtToolStripMenuItem.Click += new System.EventHandler(chiTiếtBàiViếtToolStripMenuItem_Click);
			làmMớiDanhSáchToolStripMenuItem.Name = "làmMớiDanhSáchToolStripMenuItem";
			làmMớiDanhSáchToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			làmMớiDanhSáchToolStripMenuItem.Text = "Làm mới danh sách";
			làmMớiDanhSáchToolStripMenuItem.Click += new System.EventHandler(làmMớiDanhSáchToolStripMenuItem_Click);
			hiểnThịTấtCảBàiViếtToolStripMenuItem.Name = "hiểnThịTấtCảBàiViếtToolStripMenuItem";
			hiểnThịTấtCảBàiViếtToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
			hiểnThịTấtCảBàiViếtToolStripMenuItem.Text = "Hiển thị tất cả bình luận";
			hiểnThịTấtCảBàiViếtToolStripMenuItem.Click += new System.EventHandler(hiểnThịTấtCảBàiViếtToolStripMenuItem_Click);
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(468, 473);
			btnCancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 20;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(BtnCancel_Click);
			btnSave.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
			btnSave.FlatAppearance.BorderSize = 0;
			btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnSave.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnSave.ForeColor = System.Drawing.Color.White;
			btnSave.Location = new System.Drawing.Point(361, 473);
			btnSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			btnSave.Name = "btnSave";
			btnSave.Size = new System.Drawing.Size(92, 29);
			btnSave.TabIndex = 19;
			btnSave.Text = "Lưu";
			btnSave.UseVisualStyleBackColor = false;
			btnSave.Click += new System.EventHandler(BtnSave_Click);
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 200;
			toolTip1.ReshowDelay = 40;
			cStt.HeaderText = "STT";
			cStt.Name = "cStt";
			cStt.Width = 35;
			cChuDe.HeaderText = "Chủ đề";
			cChuDe.Name = "cChuDe";
			cIdBaiViet.HeaderText = "ID Bài viết";
			cIdBaiViet.Name = "cIdBaiViet";
			cIdBaiViet.Visible = false;
			cIdBaiViet.Width = 90;
			cTieuDe.HeaderText = "Tiêu đề";
			cTieuDe.Name = "cTieuDe";
			cTieuDe.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cTieuDe.Width = 230;
			cAnh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			cAnh.HeaderText = "Ảnh";
			cAnh.Name = "cAnh";
			cVideo.HeaderText = "Video";
			cVideo.Name = "cVideo";
			cVideo.Visible = false;
			cVideo.Width = 50;
			cStt1.HeaderText = "STT";
			cStt1.Name = "cStt1";
			cStt1.Width = 35;
			dataGridViewTextBoxColumn2.HeaderText = "Chủ đề";
			dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			cId.HeaderText = "ID Bài viết";
			cId.Name = "cId";
			cId.Visible = false;
			cId.Width = 90;
			dataGridViewTextBoxColumn4.HeaderText = "Tiêu đề";
			dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			dataGridViewTextBoxColumn4.Width = 230;
			dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			dataGridViewTextBoxColumn5.HeaderText = "Ảnh";
			dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			Column1.HeaderText = "Video";
			Column1.Name = "Column1";
			Column1.Visible = false;
			Column1.Width = 50;
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(927, 517);
			base.Controls.Add(panel1);
			base.Controls.Add(bunifuCards1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fChonBaiViet";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "Cấu hình chung";
			base.Load += new System.EventHandler(FConfigGenneral_Load);
			panel1.ResumeLayout(false);
			bunifuCards2.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dgvBaiVietDaChon).EndInit();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dgvDSBaiViet).EndInit();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
