using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.KichBan;
using maxcare.Properties;
using MCommon;
using MetroFramework.Controls;

namespace maxcare
{
	public class fHDDangStatus : Form
	{
		private JSON_Settings setting;

		private string id_KichBan;

		private string id_TuongTac;

		private string Id_HanhDong;

		private int type;

		public static bool isSave;

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private Panel panel1;

		private TextBox txtTenHanhDong;

		private Label label1;

		private Button btnCancel;

		private Button btnAdd;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private Button button1;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private CheckBox ckbAnh;

		private CheckBox ckbVanBan;

		private Panel plVanBan;

		private Label label8;

		private Label lblStatus;

		private Panel plAnh;

		private TextBox txtPathAnh;

		private Label label3;

		private Panel plVideo;

		private TextBox txtPathVideo;

		private Label label7;

		private CheckBox ckbVideo;

		private RichTextBox txtNoiDung;

		private RadioButton rbNganCachKyTu;

		private RadioButton rbNganCachMoiDong;

		private Label label9;

		private MetroButton btnDown;

		private MetroButton btnUp;

		private CheckBox ckbUseBackground;

		private Panel plTag;

		private RichTextBox txtUidTag;

		private Label label11;

		private Label label10;

		private Label lbUid;

		private CheckBox ckbTag;

		private NumericUpDown nudUidTo;

		private NumericUpDown nudUidFrom;

		private Label label13;

		private Label label14;

		private RadioButton rbUidTuNhap;

		private RadioButton rbUidBanBe;

		private Label label12;

		private Panel plUidTuNhap;

		private Label label19;

		private Label label20;

		private NumericUpDown nudKhoangCachTo;

		private NumericUpDown nudKhoangCachFrom;

		private Label label18;

		private Label label17;

		private NumericUpDown nudSoLuongTo;

		private NumericUpDown nudSoLuongFrom;

		private Label label16;

		private Label label15;

		private NumericUpDown nudSoLuongVideoTo;

		private NumericUpDown nudSoLuongVideoFrom;

		private Label label5;

		private Label label6;

		private Label label22;

		private NumericUpDown nudSoLuongAnhTo;

		private NumericUpDown nudSoLuongAnhFrom;

		private Label label2;

		private Label label4;

		private Label label21;

		private Button button2;

		private Button button3;

		private Button button4;

		private LinkLabel linkLabel1;

		public fHDDangStatus(string id_KichBan, int type = 0, string id_HanhDong = "")
		{
			InitializeComponent();
			ChangeLanguage();
			isSave = false;
			this.id_KichBan = id_KichBan;
			Id_HanhDong = id_HanhDong;
			this.type = type;
			if (InteractSQL.GetTuongTac("", "HDDangStatus").Rows.Count == 0)
			{
				maxcare.KichBan.Connector.Instance.ExecuteNonQuery("INSERT INTO \"main\".\"Tuong_Tac\" (\"TenTuongTac\", \"CauHinh\", \"MoTa\") VALUES ('HDDangStatus', '{  \"ckbVanBan\": \"False\",\"txtNoiDung\": \"\",   \"ckbAnh\": \"False\",\"txtPathAnh\":\"\",\"nudSoLuongAnh\": \"1\",  \"ckbVideo\": \"False\",\"txtPathVideo\":\"\",\"nudSoLuongVideo\": \"1\"}', 'Đăng status');");
			}
			string jsonStringOrPathFile = "";
			switch (type)
			{
			case 0:
			{
				DataTable tuongTac = InteractSQL.GetTuongTac("", "HDDangStatus");
				jsonStringOrPathFile = tuongTac.Rows[0]["CauHinh"].ToString();
				id_TuongTac = tuongTac.Rows[0]["Id_TuongTac"].ToString();
				txtTenHanhDong.Text = Language.GetValue(tuongTac.Rows[0]["MoTa"].ToString());
				break;
			}
			case 1:
			{
				DataTable hanhDongById = InteractSQL.GetHanhDongById(id_HanhDong);
				jsonStringOrPathFile = hanhDongById.Rows[0]["CauHinh"].ToString();
				btnAdd.Text = Language.GetValue("Câ\u0323p nhâ\u0323t");
				txtTenHanhDong.Text = hanhDongById.Rows[0]["TenHanhDong"].ToString();
				break;
			}
			}
			setting = new JSON_Settings(jsonStringOrPathFile, isJsonString: true);
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(label1);
			Language.GetValue(label15);
			Language.GetValue(label17);
			Language.GetValue(label18);
			Language.GetValue(label16);
			Language.GetValue(label20);
			Language.GetValue(label19);
			Language.GetValue(ckbVanBan);
			Language.GetValue(lblStatus);
			Language.GetValue(button2);
			Language.GetValue(label8);
			Language.GetValue(ckbAnh);
			Language.GetValue(label3);
			Language.GetValue(label21);
			Language.GetValue(label2);
			Language.GetValue(label4);
			Language.GetValue(ckbUseBackground);
			Language.GetValue(ckbVideo);
			Language.GetValue(label7);
			Language.GetValue(label22);
			Language.GetValue(label5);
			Language.GetValue(label6);
			Language.GetValue(ckbTag);
			Language.GetValue(label10);
			Language.GetValue(label13);
			Language.GetValue(label12);
			Language.GetValue(rbUidBanBe);
			Language.GetValue(rbUidTuNhap);
			Language.GetValue(lbUid);
			Language.GetValue(label11);
			Language.GetValue(btnAdd);
			Language.GetValue(btnCancel);
		}

		private void FConfigInteract_Load(object sender, EventArgs e)
		{
			try
			{
				nudSoLuongFrom.Value = setting.GetValueInt("nudSoLuongFrom", 1);
				nudSoLuongTo.Value = setting.GetValueInt("nudSoLuongTo", 1);
				nudKhoangCachFrom.Value = setting.GetValueInt("nudKhoangCachFrom", 5);
				nudKhoangCachTo.Value = setting.GetValueInt("nudKhoangCachTo", 10);
				ckbVanBan.Checked = setting.GetValueBool("ckbVanBan");
				ckbUseBackground.Checked = setting.GetValueBool("ckbUseBackground");
				txtNoiDung.Text = setting.GetValue("txtNoiDung");
				ckbAnh.Checked = setting.GetValueBool("ckbAnh");
				ckbVideo.Checked = setting.GetValueBool("ckbVideo");
				nudSoLuongAnhFrom.Value = setting.GetValueInt("nudSoLuongAnhFrom", 1);
				nudSoLuongAnhTo.Value = setting.GetValueInt("nudSoLuongAnhTo", 1);
				nudSoLuongVideoFrom.Value = setting.GetValueInt("nudSoLuongVideoFrom", 1);
				nudSoLuongVideoTo.Value = setting.GetValueInt("nudSoLuongVideoTo", 1);
				txtPathAnh.Text = setting.GetValue("txtPathAnh");
				txtPathVideo.Text = setting.GetValue("txtPathVideo");
				if (setting.GetValueInt("typeNganCach") == 1)
				{
					rbNganCachKyTu.Checked = true;
				}
				else
				{
					rbNganCachMoiDong.Checked = true;
				}
				if (setting.GetValueInt("typeUidTag") == 0)
				{
					rbUidBanBe.Checked = true;
				}
				else
				{
					rbUidTuNhap.Checked = true;
				}
				ckbTag.Checked = setting.GetValueBool("ckbTag");
				txtUidTag.Text = setting.GetValue("txtUidTag");
				nudUidFrom.Value = setting.GetValueInt("nudUidFrom", 1);
				nudUidTo.Value = setting.GetValueInt("nudUidTo", 1);
			}
			catch (Exception)
			{
			}
			CheckedChangeFull();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			string text = txtTenHanhDong.Text.Trim();
			if (text == "")
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lo\u0300ng nhâ\u0323p tên ha\u0300nh đô\u0323ng!"), 3);
				return;
			}
			if (ckbAnh.Checked && !Directory.Exists(txtPathAnh.Text.Trim()))
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Đường dẫn ảnh không tồn tại!"), 3);
				return;
			}
			if (ckbVideo.Checked && !Directory.Exists(txtPathVideo.Text.Trim()))
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Đường dẫn video không tồn tại!"), 3);
				return;
			}
			JSON_Settings jSON_Settings = new JSON_Settings();
			jSON_Settings.Update("nudSoLuongFrom", nudSoLuongFrom.Value);
			jSON_Settings.Update("nudSoLuongTo", nudSoLuongTo.Value);
			jSON_Settings.Update("nudKhoangCachFrom", nudKhoangCachFrom.Value);
			jSON_Settings.Update("nudKhoangCachTo", nudKhoangCachTo.Value);
			jSON_Settings.Update("ckbVanBan", ckbVanBan.Checked);
			jSON_Settings.Update("ckbUseBackground", ckbUseBackground.Checked);
			jSON_Settings.Update("ckbAnh", ckbAnh.Checked);
			jSON_Settings.Update("ckbVideo", ckbVideo.Checked);
			jSON_Settings.Update("nudSoLuongAnhFrom", nudSoLuongAnhFrom.Value);
			jSON_Settings.Update("nudSoLuongAnhTo", nudSoLuongAnhTo.Value);
			jSON_Settings.Update("nudSoLuongVideoFrom", nudSoLuongVideoFrom.Value);
			jSON_Settings.Update("nudSoLuongVideoTo", nudSoLuongVideoTo.Value);
			jSON_Settings.Update("txtNoiDung", txtNoiDung.Text.Trim());
			jSON_Settings.Update("txtPathAnh", txtPathAnh.Text.Trim());
			jSON_Settings.Update("txtPathVideo", txtPathVideo.Text.Trim());
			int num = 0;
			if (rbNganCachKyTu.Checked)
			{
				num = 1;
			}
			jSON_Settings.Update("typeNganCach", num);
			if (rbUidBanBe.Checked)
			{
				jSON_Settings.Update("typeUidTag", 0);
			}
			else if (rbUidTuNhap.Checked)
			{
				jSON_Settings.Update("typeUidTag", 1);
			}
			jSON_Settings.Update("ckbTag", ckbTag.Checked);
			jSON_Settings.Update("txtUidTag", txtUidTag.Text.Trim());
			jSON_Settings.Update("nudUidFrom", nudUidFrom.Value);
			jSON_Settings.Update("nudUidTo", nudUidTo.Value);
			string fullString = jSON_Settings.GetFullString();
			if (type == 0)
			{
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n thêm ha\u0300nh đô\u0323ng mơ\u0301i?")) == DialogResult.Yes)
				{
					if (InteractSQL.InsertHanhDong(id_KichBan, text, id_TuongTac, fullString))
					{
						isSave = true;
						Close();
					}
					else
					{
						MessageBoxHelper.ShowMessageBox(Language.GetValue("Thêm thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
					}
				}
			}
			else if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n câ\u0323p nhâ\u0323t ha\u0300nh đô\u0323ng?")) == DialogResult.Yes)
			{
				if (InteractSQL.UpdateHanhDong(Id_HanhDong, text, fullString))
				{
					isSave = true;
					Close();
				}
				else
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Câ\u0323p nhâ\u0323t thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
				}
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			if (panel1.BorderStyle == BorderStyle.FixedSingle)
			{
				int num = 1;
				int num2 = 0;
				using Pen pen = new Pen(Color.DarkViolet, 1f);
				e.Graphics.DrawRectangle(pen, new Rectangle(num2, num2, panel1.ClientSize.Width - num, panel1.ClientSize.Height - num));
			}
		}

		private void CheckedChangeFull()
		{
			ckbVanBan_CheckedChanged(null, null);
			ckbAnh_CheckedChanged(null, null);
			ckbVideo_CheckedChanged(null, null);
			ckbTag_CheckedChanged(null, null);
			rbUidTuNhap_CheckedChanged(null, null);
		}

		private void ckbVanBan_CheckedChanged(object sender, EventArgs e)
		{
			plVanBan.Enabled = ckbVanBan.Checked;
			if (!ckbVanBan.Checked)
			{
				ckbUseBackground.Checked = false;
			}
		}

		private void ckbAnh_CheckedChanged(object sender, EventArgs e)
		{
			plAnh.Enabled = ckbAnh.Checked;
			if (ckbAnh.Checked)
			{
				ckbUseBackground.Checked = false;
			}
		}

		private void ckbVideo_CheckedChanged(object sender, EventArgs e)
		{
			plVideo.Enabled = ckbVideo.Checked;
			if (ckbVideo.Checked)
			{
				ckbUseBackground.Checked = false;
			}
		}

		private void txtNoiDung_TextChanged(object sender, EventArgs e)
		{
			UpdateSoLuongBinhLuan();
		}

		private void UpdateSoLuongBinhLuan()
		{
			try
			{
				List<string> list = new List<string>();
				list = ((!rbNganCachMoiDong.Checked) ? txtNoiDung.Text.Split(new string[1] { "\n|\n" }, StringSplitOptions.RemoveEmptyEntries).ToList() : txtNoiDung.Lines.ToList());
				list = MCommon.Common.RemoveEmptyItems(list);
				lblStatus.Text = string.Format(Language.GetValue("Danh sa\u0301ch nô\u0323i dung ({0}):"), list.Count.ToString());
			}
			catch
			{
			}
		}

		private void UpdateSoLuongUid()
		{
			try
			{
				List<string> list = new List<string>();
				list = ((!rbNganCachMoiDong.Checked) ? txtUidTag.Text.Split(new string[1] { "\n|\n" }, StringSplitOptions.RemoveEmptyEntries).ToList() : txtUidTag.Lines.ToList());
				list = MCommon.Common.RemoveEmptyItems(list);
				lbUid.Text = string.Format(Language.GetValue("Danh sách Uid ({0}):"), list.Count.ToString());
			}
			catch
			{
			}
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
			txtPathAnh.Text = MCommon.Common.SelectFolder();
		}

		private void metroButton2_Click(object sender, EventArgs e)
		{
			txtPathVideo.Text = MCommon.Common.SelectFolder();
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				btnUp.Visible = true;
				btnDown.Visible = true;
			}
		}

		private void btnDown_Click(object sender, EventArgs e)
		{
			plVanBan.Height = 325;
		}

		private void btnUp_Click(object sender, EventArgs e)
		{
			plVanBan.Height = 276;
		}

		private void rbNganCachMoiDong_CheckedChanged(object sender, EventArgs e)
		{
			UpdateSoLuongBinhLuan();
		}

		private void rbNganCachKyTu_CheckedChanged(object sender, EventArgs e)
		{
			UpdateSoLuongBinhLuan();
		}

		private void ckbUseBackground_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbTag_CheckedChanged(object sender, EventArgs e)
		{
			plTag.Enabled = ckbTag.Checked;
		}

		private void txtUid_TextChanged(object sender, EventArgs e)
		{
			UpdateSoLuongUid();
		}

		private void lbUid_Click(object sender, EventArgs e)
		{
		}

		private void label11_Click(object sender, EventArgs e)
		{
		}

		private void rbUidTuNhap_CheckedChanged(object sender, EventArgs e)
		{
			plUidTuNhap.Enabled = rbUidTuNhap.Checked;
		}

		private void txtPathAnh_TextChanged(object sender, EventArgs e)
		{
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			string s = Language.GetValue("Có thể dùng:") + Environment.NewLine + Language.GetValue("- [full_name] để thay thế họ tên của tài khoản!") + Environment.NewLine + Language.GetValue("- [name] để thay thế tên của tài khoản!");
			MessageBoxHelper.ShowMessageBox(s);
		}

		private void button4_Click(object sender, EventArgs e)
		{
			MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng nhập mỗi dòng là 1 nội dung!"));
			txtNoiDung.Focus();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fHelpNhapComment());
			txtNoiDung.Focus();
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			MCommon.Common.ShowForm(new fHuongDanRandom());
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fHDDangStatus));
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			button1 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			panel1 = new System.Windows.Forms.Panel();
			label19 = new System.Windows.Forms.Label();
			label20 = new System.Windows.Forms.Label();
			nudKhoangCachTo = new System.Windows.Forms.NumericUpDown();
			nudKhoangCachFrom = new System.Windows.Forms.NumericUpDown();
			label18 = new System.Windows.Forms.Label();
			label17 = new System.Windows.Forms.Label();
			nudSoLuongTo = new System.Windows.Forms.NumericUpDown();
			nudSoLuongFrom = new System.Windows.Forms.NumericUpDown();
			label16 = new System.Windows.Forms.Label();
			label15 = new System.Windows.Forms.Label();
			plTag = new System.Windows.Forms.Panel();
			plUidTuNhap = new System.Windows.Forms.Panel();
			lbUid = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			txtUidTag = new System.Windows.Forms.RichTextBox();
			rbUidTuNhap = new System.Windows.Forms.RadioButton();
			rbUidBanBe = new System.Windows.Forms.RadioButton();
			nudUidTo = new System.Windows.Forms.NumericUpDown();
			nudUidFrom = new System.Windows.Forms.NumericUpDown();
			label12 = new System.Windows.Forms.Label();
			label10 = new System.Windows.Forms.Label();
			label13 = new System.Windows.Forms.Label();
			label14 = new System.Windows.Forms.Label();
			plVanBan = new System.Windows.Forms.Panel();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			btnDown = new MetroFramework.Controls.MetroButton();
			button4 = new System.Windows.Forms.Button();
			btnUp = new MetroFramework.Controls.MetroButton();
			rbNganCachKyTu = new System.Windows.Forms.RadioButton();
			rbNganCachMoiDong = new System.Windows.Forms.RadioButton();
			label9 = new System.Windows.Forms.Label();
			txtNoiDung = new System.Windows.Forms.RichTextBox();
			label8 = new System.Windows.Forms.Label();
			lblStatus = new System.Windows.Forms.Label();
			btnAdd = new System.Windows.Forms.Button();
			plVideo = new System.Windows.Forms.Panel();
			nudSoLuongVideoTo = new System.Windows.Forms.NumericUpDown();
			nudSoLuongVideoFrom = new System.Windows.Forms.NumericUpDown();
			label5 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			label22 = new System.Windows.Forms.Label();
			txtPathVideo = new System.Windows.Forms.TextBox();
			label7 = new System.Windows.Forms.Label();
			plAnh = new System.Windows.Forms.Panel();
			nudSoLuongAnhTo = new System.Windows.Forms.NumericUpDown();
			nudSoLuongAnhFrom = new System.Windows.Forms.NumericUpDown();
			label2 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			label21 = new System.Windows.Forms.Label();
			txtPathAnh = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			ckbVideo = new System.Windows.Forms.CheckBox();
			ckbTag = new System.Windows.Forms.CheckBox();
			ckbUseBackground = new System.Windows.Forms.CheckBox();
			ckbAnh = new System.Windows.Forms.CheckBox();
			ckbVanBan = new System.Windows.Forms.CheckBox();
			txtTenHanhDong = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			btnCancel = new System.Windows.Forms.Button();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			linkLabel1 = new System.Windows.Forms.LinkLabel();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudKhoangCachTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudKhoangCachFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongFrom).BeginInit();
			plTag.SuspendLayout();
			plUidTuNhap.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudUidTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudUidFrom).BeginInit();
			plVanBan.SuspendLayout();
			plVideo.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudSoLuongVideoTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongVideoFrom).BeginInit();
			plAnh.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudSoLuongAnhTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongAnhFrom).BeginInit();
			bunifuCards1.SuspendLayout();
			SuspendLayout();
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(680, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Cấu hình Đăng status";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = pnlHeader;
			bunifuDragControl2.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button1);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(680, 31);
			pnlHeader.TabIndex = 9;
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
			button1.Location = new System.Drawing.Point(649, 1);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(30, 30);
			button1.TabIndex = 0;
			button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(label19);
			panel1.Controls.Add(label20);
			panel1.Controls.Add(nudKhoangCachTo);
			panel1.Controls.Add(nudKhoangCachFrom);
			panel1.Controls.Add(label18);
			panel1.Controls.Add(label17);
			panel1.Controls.Add(nudSoLuongTo);
			panel1.Controls.Add(nudSoLuongFrom);
			panel1.Controls.Add(label16);
			panel1.Controls.Add(label15);
			panel1.Controls.Add(plTag);
			panel1.Controls.Add(plVanBan);
			panel1.Controls.Add(btnAdd);
			panel1.Controls.Add(plVideo);
			panel1.Controls.Add(plAnh);
			panel1.Controls.Add(ckbVideo);
			panel1.Controls.Add(ckbTag);
			panel1.Controls.Add(ckbUseBackground);
			panel1.Controls.Add(ckbAnh);
			panel1.Controls.Add(ckbVanBan);
			panel1.Controls.Add(txtTenHanhDong);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(bunifuCards1);
			panel1.Cursor = System.Windows.Forms.Cursors.Arrow;
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(683, 591);
			panel1.TabIndex = 0;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			label19.AutoSize = true;
			label19.Location = new System.Drawing.Point(291, 108);
			label19.Name = "label19";
			label19.Size = new System.Drawing.Size(31, 16);
			label19.TabIndex = 43;
			label19.Text = "giây";
			label20.Location = new System.Drawing.Point(205, 108);
			label20.Name = "label20";
			label20.Size = new System.Drawing.Size(29, 16);
			label20.TabIndex = 42;
			label20.Text = "đến";
			label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			nudKhoangCachTo.Location = new System.Drawing.Point(236, 106);
			nudKhoangCachTo.Name = "nudKhoangCachTo";
			nudKhoangCachTo.Size = new System.Drawing.Size(51, 23);
			nudKhoangCachTo.TabIndex = 41;
			nudKhoangCachFrom.Location = new System.Drawing.Point(151, 106);
			nudKhoangCachFrom.Name = "nudKhoangCachFrom";
			nudKhoangCachFrom.Size = new System.Drawing.Size(51, 23);
			nudKhoangCachFrom.TabIndex = 40;
			label18.AutoSize = true;
			label18.Location = new System.Drawing.Point(291, 83);
			label18.Name = "label18";
			label18.Size = new System.Drawing.Size(25, 16);
			label18.TabIndex = 39;
			label18.Text = "bài";
			label17.Location = new System.Drawing.Point(205, 83);
			label17.Name = "label17";
			label17.Size = new System.Drawing.Size(29, 16);
			label17.TabIndex = 38;
			label17.Text = "đến";
			label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			nudSoLuongTo.Location = new System.Drawing.Point(236, 78);
			nudSoLuongTo.Name = "nudSoLuongTo";
			nudSoLuongTo.Size = new System.Drawing.Size(51, 23);
			nudSoLuongTo.TabIndex = 37;
			nudSoLuongFrom.Location = new System.Drawing.Point(151, 78);
			nudSoLuongFrom.Name = "nudSoLuongFrom";
			nudSoLuongFrom.Size = new System.Drawing.Size(51, 23);
			nudSoLuongFrom.TabIndex = 36;
			label16.AutoSize = true;
			label16.Location = new System.Drawing.Point(30, 108);
			label16.Name = "label16";
			label16.Size = new System.Drawing.Size(117, 16);
			label16.TabIndex = 35;
			label16.Text = "Khoảng cách đăng:";
			label15.AutoSize = true;
			label15.Location = new System.Drawing.Point(30, 83);
			label15.Name = "label15";
			label15.Size = new System.Drawing.Size(109, 16);
			label15.TabIndex = 34;
			label15.Text = "Số lượng bài viết:";
			plTag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plTag.Controls.Add(plUidTuNhap);
			plTag.Controls.Add(rbUidTuNhap);
			plTag.Controls.Add(rbUidBanBe);
			plTag.Controls.Add(nudUidTo);
			plTag.Controls.Add(nudUidFrom);
			plTag.Controls.Add(label12);
			plTag.Controls.Add(label10);
			plTag.Controls.Add(label13);
			plTag.Controls.Add(label14);
			plTag.Enabled = false;
			plTag.Location = new System.Drawing.Point(369, 266);
			plTag.Name = "plTag";
			plTag.Size = new System.Drawing.Size(278, 255);
			plTag.TabIndex = 33;
			plUidTuNhap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plUidTuNhap.Controls.Add(lbUid);
			plUidTuNhap.Controls.Add(label11);
			plUidTuNhap.Controls.Add(txtUidTag);
			plUidTuNhap.Location = new System.Drawing.Point(17, 97);
			plUidTuNhap.Name = "plUidTuNhap";
			plUidTuNhap.Size = new System.Drawing.Size(248, 151);
			plUidTuNhap.TabIndex = 34;
			lbUid.AutoSize = true;
			lbUid.Location = new System.Drawing.Point(3, 3);
			lbUid.Name = "lbUid";
			lbUid.Size = new System.Drawing.Size(115, 16);
			lbUid.TabIndex = 0;
			lbUid.Text = "Danh sa\u0301ch Uid (0):";
			lbUid.Click += new System.EventHandler(lbUid_Click);
			label11.AutoSize = true;
			label11.Location = new System.Drawing.Point(4, 127);
			label11.Name = "label11";
			label11.Size = new System.Drawing.Size(134, 16);
			label11.TabIndex = 0;
			label11.Text = "(Mỗi nội dung 1 dòng)";
			label11.Click += new System.EventHandler(label11_Click);
			txtUidTag.Location = new System.Drawing.Point(7, 22);
			txtUidTag.Name = "txtUidTag";
			txtUidTag.Size = new System.Drawing.Size(236, 102);
			txtUidTag.TabIndex = 34;
			txtUidTag.Text = "";
			txtUidTag.WordWrap = false;
			txtUidTag.TextChanged += new System.EventHandler(txtUid_TextChanged);
			rbUidTuNhap.AutoSize = true;
			rbUidTuNhap.Cursor = System.Windows.Forms.Cursors.Hand;
			rbUidTuNhap.Location = new System.Drawing.Point(17, 73);
			rbUidTuNhap.Name = "rbUidTuNhap";
			rbUidTuNhap.Size = new System.Drawing.Size(187, 20);
			rbUidTuNhap.TabIndex = 42;
			rbUidTuNhap.Text = "Theo danh sách Uid tự nhập";
			rbUidTuNhap.UseVisualStyleBackColor = true;
			rbUidTuNhap.CheckedChanged += new System.EventHandler(rbUidTuNhap_CheckedChanged);
			rbUidBanBe.AutoSize = true;
			rbUidBanBe.Checked = true;
			rbUidBanBe.Cursor = System.Windows.Forms.Cursors.Hand;
			rbUidBanBe.Location = new System.Drawing.Point(17, 50);
			rbUidBanBe.Name = "rbUidBanBe";
			rbUidBanBe.Size = new System.Drawing.Size(195, 20);
			rbUidBanBe.TabIndex = 42;
			rbUidBanBe.TabStop = true;
			rbUidBanBe.Text = "Ngẫu nhiên danh sách bạn bè";
			rbUidBanBe.UseVisualStyleBackColor = true;
			nudUidTo.Location = new System.Drawing.Point(208, 4);
			nudUidTo.Maximum = new decimal(new int[4] { 50, 0, 0, 0 });
			nudUidTo.Name = "nudUidTo";
			nudUidTo.Size = new System.Drawing.Size(36, 23);
			nudUidTo.TabIndex = 39;
			nudUidTo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudUidFrom.Location = new System.Drawing.Point(137, 4);
			nudUidFrom.Maximum = new decimal(new int[4] { 50, 0, 0, 0 });
			nudUidFrom.Name = "nudUidFrom";
			nudUidFrom.Size = new System.Drawing.Size(36, 23);
			nudUidFrom.TabIndex = 38;
			nudUidFrom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label12.AutoSize = true;
			label12.Location = new System.Drawing.Point(3, 31);
			label12.Name = "label12";
			label12.Size = new System.Drawing.Size(127, 16);
			label12.TabIndex = 0;
			label12.Text = "Tùy chọn Uid để tag:";
			label10.AutoSize = true;
			label10.Location = new System.Drawing.Point(3, 6);
			label10.Name = "label10";
			label10.Size = new System.Drawing.Size(118, 16);
			label10.TabIndex = 0;
			label10.Text = "Số Uid cần tag/bài:";
			label13.Location = new System.Drawing.Point(176, 6);
			label13.Name = "label13";
			label13.Size = new System.Drawing.Size(29, 16);
			label13.TabIndex = 41;
			label13.Text = "đê\u0301n";
			label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label14.AutoSize = true;
			label14.Location = new System.Drawing.Point(244, 6);
			label14.Name = "label14";
			label14.Size = new System.Drawing.Size(26, 16);
			label14.TabIndex = 40;
			label14.Text = "Uid";
			plVanBan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plVanBan.Controls.Add(linkLabel1);
			plVanBan.Controls.Add(button3);
			plVanBan.Controls.Add(button2);
			plVanBan.Controls.Add(btnDown);
			plVanBan.Controls.Add(button4);
			plVanBan.Controls.Add(btnUp);
			plVanBan.Controls.Add(rbNganCachKyTu);
			plVanBan.Controls.Add(rbNganCachMoiDong);
			plVanBan.Controls.Add(label9);
			plVanBan.Controls.Add(txtNoiDung);
			plVanBan.Controls.Add(label8);
			plVanBan.Controls.Add(lblStatus);
			plVanBan.Location = new System.Drawing.Point(47, 159);
			plVanBan.Name = "plVanBan";
			plVanBan.Size = new System.Drawing.Size(278, 276);
			plVanBan.TabIndex = 33;
			button3.Cursor = System.Windows.Forms.Cursors.Help;
			button3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button3.Location = new System.Drawing.Point(225, 298);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(21, 23);
			button3.TabIndex = 96;
			button3.Text = "?";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.Cursor = System.Windows.Forms.Cursors.Help;
			button2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button2.Location = new System.Drawing.Point(247, 249);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(23, 23);
			button2.TabIndex = 95;
			button2.Text = "?";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click_1);
			btnDown.BackgroundImage = maxcare.Properties.Resources.icons8_expand_arrow_24px;
			btnDown.Cursor = System.Windows.Forms.Cursors.Hand;
			btnDown.Location = new System.Drawing.Point(221, -1);
			btnDown.Name = "btnDown";
			btnDown.Size = new System.Drawing.Size(25, 25);
			btnDown.TabIndex = 38;
			btnDown.UseSelectable = true;
			btnDown.Click += new System.EventHandler(btnDown_Click);
			button4.Cursor = System.Windows.Forms.Cursors.Help;
			button4.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button4.Location = new System.Drawing.Point(225, 275);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(21, 23);
			button4.TabIndex = 97;
			button4.Text = "?";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			btnUp.BackgroundImage = maxcare.Properties.Resources.icons8_collapse_arrow_24px;
			btnUp.Cursor = System.Windows.Forms.Cursors.Hand;
			btnUp.Location = new System.Drawing.Point(252, -1);
			btnUp.Name = "btnUp";
			btnUp.Size = new System.Drawing.Size(25, 25);
			btnUp.TabIndex = 39;
			btnUp.UseSelectable = true;
			btnUp.Click += new System.EventHandler(btnUp_Click);
			rbNganCachKyTu.AutoSize = true;
			rbNganCachKyTu.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNganCachKyTu.Location = new System.Drawing.Point(69, 298);
			rbNganCachKyTu.Name = "rbNganCachKyTu";
			rbNganCachKyTu.Size = new System.Drawing.Size(160, 20);
			rbNganCachKyTu.TabIndex = 37;
			rbNganCachKyTu.Text = "Nội dung có nhiều dòng";
			rbNganCachKyTu.UseVisualStyleBackColor = true;
			rbNganCachKyTu.CheckedChanged += new System.EventHandler(rbNganCachKyTu_CheckedChanged);
			rbNganCachMoiDong.AutoSize = true;
			rbNganCachMoiDong.Checked = true;
			rbNganCachMoiDong.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNganCachMoiDong.Location = new System.Drawing.Point(69, 277);
			rbNganCachMoiDong.Name = "rbNganCachMoiDong";
			rbNganCachMoiDong.Size = new System.Drawing.Size(156, 20);
			rbNganCachMoiDong.TabIndex = 36;
			rbNganCachMoiDong.TabStop = true;
			rbNganCachMoiDong.Text = "Nội dung chỉ có 1 dòng";
			rbNganCachMoiDong.UseVisualStyleBackColor = true;
			rbNganCachMoiDong.CheckedChanged += new System.EventHandler(rbNganCachMoiDong_CheckedChanged);
			label9.AutoSize = true;
			label9.Location = new System.Drawing.Point(4, 277);
			label9.Name = "label9";
			label9.Size = new System.Drawing.Size(65, 16);
			label9.TabIndex = 35;
			label9.Text = "Tùy chọn:";
			txtNoiDung.Location = new System.Drawing.Point(7, 24);
			txtNoiDung.Name = "txtNoiDung";
			txtNoiDung.Size = new System.Drawing.Size(263, 225);
			txtNoiDung.TabIndex = 34;
			txtNoiDung.Text = "";
			txtNoiDung.WordWrap = false;
			txtNoiDung.TextChanged += new System.EventHandler(txtNoiDung_TextChanged);
			label8.AutoSize = true;
			label8.Location = new System.Drawing.Point(4, 252);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(144, 16);
			label8.TabIndex = 0;
			label8.Text = "(Spin nội dung {a|b|c})";
			lblStatus.AutoSize = true;
			lblStatus.Location = new System.Drawing.Point(3, 5);
			lblStatus.Name = "lblStatus";
			lblStatus.Size = new System.Drawing.Size(146, 16);
			lblStatus.TabIndex = 0;
			lblStatus.Text = "Danh sa\u0301ch nô\u0323i dung (0):";
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(245, 544);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 3;
			btnAdd.Text = "Thêm";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(btnAdd_Click);
			plVideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plVideo.Controls.Add(nudSoLuongVideoTo);
			plVideo.Controls.Add(nudSoLuongVideoFrom);
			plVideo.Controls.Add(label5);
			plVideo.Controls.Add(label6);
			plVideo.Controls.Add(label22);
			plVideo.Controls.Add(txtPathVideo);
			plVideo.Controls.Add(label7);
			plVideo.Location = new System.Drawing.Point(369, 181);
			plVideo.Name = "plVideo";
			plVideo.Size = new System.Drawing.Size(278, 58);
			plVideo.TabIndex = 33;
			nudSoLuongVideoTo.Location = new System.Drawing.Point(196, 30);
			nudSoLuongVideoTo.Maximum = new decimal(new int[4] { 99999, 0, 0, 0 });
			nudSoLuongVideoTo.Name = "nudSoLuongVideoTo";
			nudSoLuongVideoTo.Size = new System.Drawing.Size(45, 23);
			nudSoLuongVideoTo.TabIndex = 12;
			nudSoLuongVideoFrom.Location = new System.Drawing.Point(119, 30);
			nudSoLuongVideoFrom.Maximum = new decimal(new int[4] { 99999, 0, 0, 0 });
			nudSoLuongVideoFrom.Name = "nudSoLuongVideoFrom";
			nudSoLuongVideoFrom.Size = new System.Drawing.Size(45, 23);
			nudSoLuongVideoFrom.TabIndex = 13;
			label5.Location = new System.Drawing.Point(165, 32);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(29, 16);
			label5.TabIndex = 9;
			label5.Text = "đến";
			label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label6.AutoSize = true;
			label6.Location = new System.Drawing.Point(241, 33);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(38, 16);
			label6.TabIndex = 10;
			label6.Text = "video";
			label22.AutoSize = true;
			label22.Location = new System.Drawing.Point(3, 32);
			label22.Name = "label22";
			label22.Size = new System.Drawing.Size(120, 16);
			label22.TabIndex = 11;
			label22.Text = "Sô\u0301 lươ\u0323ng video/bài:";
			txtPathVideo.Location = new System.Drawing.Point(148, 2);
			txtPathVideo.Name = "txtPathVideo";
			txtPathVideo.Size = new System.Drawing.Size(126, 23);
			txtPathVideo.TabIndex = 1;
			label7.AutoSize = true;
			label7.Location = new System.Drawing.Point(3, 5);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(147, 16);
			label7.TabIndex = 0;
			label7.Text = "Đường dẫn folder video:";
			plAnh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plAnh.Controls.Add(nudSoLuongAnhTo);
			plAnh.Controls.Add(nudSoLuongAnhFrom);
			plAnh.Controls.Add(label2);
			plAnh.Controls.Add(label4);
			plAnh.Controls.Add(label21);
			plAnh.Controls.Add(txtPathAnh);
			plAnh.Controls.Add(label3);
			plAnh.Location = new System.Drawing.Point(47, 463);
			plAnh.Name = "plAnh";
			plAnh.Size = new System.Drawing.Size(278, 58);
			plAnh.TabIndex = 33;
			nudSoLuongAnhTo.Location = new System.Drawing.Point(196, 29);
			nudSoLuongAnhTo.Maximum = new decimal(new int[4] { 99999, 0, 0, 0 });
			nudSoLuongAnhTo.Name = "nudSoLuongAnhTo";
			nudSoLuongAnhTo.Size = new System.Drawing.Size(45, 23);
			nudSoLuongAnhTo.TabIndex = 7;
			nudSoLuongAnhFrom.Location = new System.Drawing.Point(119, 29);
			nudSoLuongAnhFrom.Maximum = new decimal(new int[4] { 99999, 0, 0, 0 });
			nudSoLuongAnhFrom.Name = "nudSoLuongAnhFrom";
			nudSoLuongAnhFrom.Size = new System.Drawing.Size(45, 23);
			nudSoLuongAnhFrom.TabIndex = 8;
			label2.Location = new System.Drawing.Point(167, 31);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(29, 16);
			label2.TabIndex = 4;
			label2.Text = "đến";
			label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(239, 31);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(29, 16);
			label4.TabIndex = 5;
			label4.Text = "a\u0309nh";
			label21.AutoSize = true;
			label21.Location = new System.Drawing.Point(3, 31);
			label21.Name = "label21";
			label21.Size = new System.Drawing.Size(111, 16);
			label21.TabIndex = 6;
			label21.Text = "Sô\u0301 lươ\u0323ng a\u0309nh/bài:";
			txtPathAnh.Location = new System.Drawing.Point(136, 2);
			txtPathAnh.Name = "txtPathAnh";
			txtPathAnh.Size = new System.Drawing.Size(138, 23);
			txtPathAnh.TabIndex = 1;
			txtPathAnh.TextChanged += new System.EventHandler(txtPathAnh_TextChanged);
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(3, 5);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(138, 16);
			label3.TabIndex = 0;
			label3.Text = "Đường dẫn folder ảnh:";
			ckbVideo.AutoSize = true;
			ckbVideo.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbVideo.Location = new System.Drawing.Point(355, 159);
			ckbVideo.Name = "ckbVideo";
			ckbVideo.Size = new System.Drawing.Size(59, 20);
			ckbVideo.TabIndex = 32;
			ckbVideo.Text = "Video";
			ckbVideo.UseVisualStyleBackColor = true;
			ckbVideo.CheckedChanged += new System.EventHandler(ckbVideo_CheckedChanged);
			ckbTag.AutoSize = true;
			ckbTag.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbTag.Location = new System.Drawing.Point(355, 242);
			ckbTag.Name = "ckbTag";
			ckbTag.Size = new System.Drawing.Size(140, 20);
			ckbTag.TabIndex = 32;
			ckbTag.Text = "Tag Uid vào bài viết";
			ckbTag.UseVisualStyleBackColor = true;
			ckbTag.CheckedChanged += new System.EventHandler(ckbTag_CheckedChanged);
			ckbUseBackground.AutoSize = true;
			ckbUseBackground.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbUseBackground.Location = new System.Drawing.Point(355, 135);
			ckbUseBackground.Name = "ckbUseBackground";
			ckbUseBackground.Size = new System.Drawing.Size(145, 20);
			ckbUseBackground.TabIndex = 32;
			ckbUseBackground.Text = "Sử dụng Background";
			ckbUseBackground.UseVisualStyleBackColor = true;
			ckbUseBackground.CheckedChanged += new System.EventHandler(ckbUseBackground_CheckedChanged);
			ckbAnh.AutoSize = true;
			ckbAnh.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAnh.Location = new System.Drawing.Point(33, 441);
			ckbAnh.Name = "ckbAnh";
			ckbAnh.Size = new System.Drawing.Size(49, 20);
			ckbAnh.TabIndex = 32;
			ckbAnh.Text = "A\u0309nh";
			ckbAnh.UseVisualStyleBackColor = true;
			ckbAnh.CheckedChanged += new System.EventHandler(ckbAnh_CheckedChanged);
			ckbVanBan.AutoSize = true;
			ckbVanBan.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbVanBan.Location = new System.Drawing.Point(33, 135);
			ckbVanBan.Name = "ckbVanBan";
			ckbVanBan.Size = new System.Drawing.Size(74, 20);
			ckbVanBan.TabIndex = 32;
			ckbVanBan.Text = "Văn ba\u0309n";
			ckbVanBan.UseVisualStyleBackColor = true;
			ckbVanBan.CheckedChanged += new System.EventHandler(ckbVanBan_CheckedChanged);
			txtTenHanhDong.Location = new System.Drawing.Point(151, 49);
			txtTenHanhDong.Name = "txtTenHanhDong";
			txtTenHanhDong.Size = new System.Drawing.Size(174, 23);
			txtTenHanhDong.TabIndex = 0;
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(30, 52);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(99, 16);
			label1.TabIndex = 31;
			label1.Text = "Tên ha\u0300nh đô\u0323ng:";
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(344, 544);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 4;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(btnCancel_Click);
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.DarkViolet;
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(1, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(680, 37);
			bunifuCards1.TabIndex = 28;
			linkLabel1.AutoSize = true;
			linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
			linkLabel1.Location = new System.Drawing.Point(165, 252);
			linkLabel1.Name = "linkLabel1";
			linkLabel1.Size = new System.Drawing.Size(82, 16);
			linkLabel1.TabIndex = 111;
			linkLabel1.TabStop = true;
			linkLabel1.Text = "Random icon";
			linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel1_LinkClicked);
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(683, 591);
			base.Controls.Add(panel1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fHDDangStatus";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình tương tác";
			base.Load += new System.EventHandler(FConfigInteract_Load);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudKhoangCachTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudKhoangCachFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongFrom).EndInit();
			plTag.ResumeLayout(false);
			plTag.PerformLayout();
			plUidTuNhap.ResumeLayout(false);
			plUidTuNhap.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudUidTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudUidFrom).EndInit();
			plVanBan.ResumeLayout(false);
			plVanBan.PerformLayout();
			plVideo.ResumeLayout(false);
			plVideo.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudSoLuongVideoTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongVideoFrom).EndInit();
			plAnh.ResumeLayout(false);
			plAnh.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudSoLuongAnhTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongAnhFrom).EndInit();
			bunifuCards1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
