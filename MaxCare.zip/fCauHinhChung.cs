using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.Properties;
using MCommon;
using MetroFramework.Controls;
using Newtonsoft.Json.Linq;

namespace maxcare
{
	public class fCauHinhChung : Form
	{
		private JSON_Settings settings;

		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Label label3;

		private NumericUpDown nudInteractThread;

		private Label label4;

		private Label label5;

		private NumericUpDown nudHideThread;

		private Label label6;

		private Label label9;

		private TextBox txbPathProfile;

		private Panel panel1;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private CheckBox ckbShowImageInteract;

		private ComboBox cbbHostpot;

		private Button button5;

		private Panel plNordVPN;

		private Label label14;

		private TextBox txtNordVPN;

		private Panel plDcom;

		private TextBox txtProfileNameDcom;

		private Button btnSSH;

		private Label label26;

		private Label label27;

		private RadioButton rbSSH;

		private RadioButton rbExpressVPN;

		private NumericUpDown nudChangeIpCount;

		private RadioButton rbNordVPN;

		private RadioButton rbHotspot;

		private RadioButton rbDcom;

		private RadioButton rbHma;

		private BunifuDragControl bunifuDragControl1;

		private ToolTip toolTip1;

		private Button btnCancel;

		private Button btnSave;

		private BunifuCards bunifuCards2;

		private Panel pnlHeader;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private Button button2;

		private Panel plTinsoft;

		private ComboBox cbbLocationTinsoft;

		private Label label7;

		private Label label1;

		private TextBox txtApiUser;

		private Label label8;

		private NumericUpDown nudLuongPerIPTinsoft;

		private RadioButton rbTinsoft;

		private Button button3;

		private ComboBox cbbRowChrome;

		private ComboBox cbbColumnChrome;

		private Label label10;

		private Label label11;

		private Panel panel2;

		private Label label12;

		private TextBox textBox1;

		private RadioButton radioButton5;

		private RadioButton radioButton4;

		private RadioButton radioButton3;

		private RadioButton radioButton2;

		private GroupBox grChrome;

		private Panel plXproxy;

		private RadioButton rbSock5Proxy;

		private RadioButton rbHttpProxy;

		private Label label16;

		private Label label17;

		private Label label13;

		private TextBox txtServiceURLXProxy;

		private RadioButton rbXproxy;

		private RichTextBox txtListProxy;

		private Label label18;

		private NumericUpDown nudLuongPerIPXProxy;

		private Panel plCheckDoiIP;

		private RadioButton rbProxy;

		private Button button4;

		private RadioButton rbChromium;

		private RadioButton rbChrome;

		private Label label15;

		private TextBox txtLinkToOtherBrowser;

		private Label label19;

		private Panel plLinkToOtherBrowser;

		private NumericUpDown nudDelayOpenChromeTo;

		private Label label21;

		private Label label20;

		private Label label22;

		private Button button6;

		private Panel plTMProxy;

		private RichTextBox txtApiKeyTMProxy;

		private Label label24;

		private Label label25;

		private NumericUpDown nudLuongPerIPTMProxy;

		private RadioButton rbTMProxy;

		private LinkLabel linkLabel1;

		private GroupBox groupBox1;

		private RadioButton rbPhanBietMauChu;

		private RadioButton rbPhanBietMauNen;

		private Label label23;

		private LinkLabel linkLabel3;

		private Panel plApiProxy;

		private Label lblCountApiProxy;

		private Label label28;

		private TextBox txtApiProxy;

		private Button button7;

		private Panel plApiUser;

		private RadioButton rbApiProxy;

		private RadioButton rbApiUser;

		private CheckBox ckbWaitDoneAllXproxy;

		private NumericUpDown nudDelayOpenChromeFrom;

		private Label label29;

		private CheckBox ckbWaitDoneAllTinsoft;

		private CheckBox ckbWaitDoneAllTMProxy;

		private NumericUpDown nudDelayCloseChromeFrom;

		private NumericUpDown nudDelayCloseChromeTo;

		private Label label32;

		private Label label31;

		private Label label2;

		private ComboBox cbbSizeChrome;

		private Label label34;

		private MetroButton btnDown;

		private MetroButton btnUp;

		private MetroButton AddFileAccount;

		private Panel plSizeChrome;

		private RadioButton rbTocDoGoNhanh;

		private RadioButton rbTocDoGoBinhThuong;

		private RadioButton rbTocDoGoCham;

		private Label label30;

		private Button button8;

		private Panel panel4;

		private NumericUpDown nudHeighChrome;

		private NumericUpDown nudWidthChrome;

		private CheckBox ckbAddChromeIntoForm;

		private Label label33;

		private Label label35;

		private Panel plAddChromeVaoFormView;

		private Button button9;

		private CheckBox ckbKhongCheckIP;

		private Panel plSapXepCuaSoChrome;

		private Panel plUsePortable;

		private Label lblFileZip;

		private CheckBox ckbUsePortable;

		private TextBox txtPathToPortableZip;

		private Panel panel3;

		private Button button1;

		private LinkLabel linkLabel2;

		private RadioButton rbNone;

		private TextBox txtUrlHilink;

		private RadioButton rbDcomHilink;

		private Label label36;

		private RadioButton rbDcomThuong;

		private Label label37;

		private NumericUpDown nudDelayCheckIP;

		private Label label38;

		private Panel plVitech;

		private RichTextBox txtListProxyVitech;

		private RadioButton radioButton9;

		private RadioButton radioButton10;

		private Label label40;

		private Label label41;

		private Label label42;

		private NumericUpDown nudLuongPerIPVitech;

		private Label label46;

		private TextBox txtApiVitech;

		private Panel plProxyv6;

		private RichTextBox txtListProxyv6;

		private RadioButton radioButton1;

		private RadioButton radioButton6;

		private Label label39;

		private Label label43;

		private Label label44;

		private NumericUpDown nudLuongPerIPProxyv6;

		private Label label45;

		private TextBox txtApiProxyv6;

		private RadioButton rbVitech;

		private RadioButton rbProxyv6;

		private Panel plShopLike;

		private RichTextBox txtApiShopLike;

		private Label label47;

		private Label label48;

		private NumericUpDown nudLuongPerIPShopLike;

		private RadioButton rbShopLike;

		private Panel panel5;

		private RichTextBox txtApiKeyMinProxy;

		private Label label49;

		private Label label50;

		private NumericUpDown nudLuongPerIPMinProxy;

		private RadioButton rbMinProxy;

		private MetroButton metroButton1;

		private Label label52;

		private Label label51;

		private NumericUpDown nudDelayResetXProxy;

		private Button button10;

		private MetroButton metroButton2;

		private MetroButton metroButton3;

		private Label label53;

		private RadioButton rbXproxyResetAllProxy;

		private RadioButton rbXproxyResetEachProxy;

		private Panel panel6;

		private Panel panel7;

		public fCauHinhChung()
		{
			InitializeComponent();
			settings = new JSON_Settings("configGeneral");
			ChangeLanguage();
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(groupBox2);
			Language.GetValue(label3);
			Language.GetValue(label6);
			Language.GetValue(label4);
			Language.GetValue(label5);
			Language.GetValue(label9);
			Language.GetValue(grChrome);
			Language.GetValue(ckbShowImageInteract);
			Language.GetValue(ckbAddChromeIntoForm);
			Language.GetValue(label10);
			Language.GetValue(label20);
			Language.GetValue(label29);
			Language.GetValue(label21);
			Language.GetValue(label2);
			Language.GetValue(label32);
			Language.GetValue(label31);
			Language.GetValue(label30);
			Language.GetValue(rbTocDoGoCham);
			Language.GetValue(rbTocDoGoBinhThuong);
			Language.GetValue(rbTocDoGoNhanh);
			Language.GetValue(linkLabel2);
			Language.GetValue(groupBox1);
			Language.GetValue(label23);
			Language.GetValue(rbPhanBietMauNen);
			Language.GetValue(rbPhanBietMauChu);
			Language.GetValue(groupBox3);
			Language.GetValue(ckbKhongCheckIP);
			Language.GetValue(label26);
			Language.GetValue(label27);
			Language.GetValue(button5);
			Language.GetValue(rbNone);
			Language.GetValue(rbProxy);
			Language.GetValue(rbHma);
			Language.GetValue(rbDcom);
			Language.GetValue(button4);
			Language.GetValue(rbTinsoft);
			Language.GetValue(linkLabel3);
			Language.GetValue(rbApiUser);
			Language.GetValue(ckbWaitDoneAllTinsoft);
			Language.GetValue(rbApiProxy);
			Language.GetValue(label7);
			Language.GetValue(label8);
			Language.GetValue(label16);
			Language.GetValue(label17);
			Language.GetValue(ckbWaitDoneAllXproxy);
			Language.GetValue(label18);
			Language.GetValue(linkLabel1);
			Language.GetValue(label24);
			Language.GetValue(ckbWaitDoneAllTMProxy);
			Language.GetValue(label25);
			Language.GetValue(btnSave);
			Language.GetValue(btnCancel);
		}

		private void LoadCbbLocation()
		{
			Dictionary<string, string> dataSource = TinsoftGetListLocation();
			cbbLocationTinsoft.DataSource = new BindingSource(dataSource, null);
			cbbLocationTinsoft.ValueMember = "Key";
			cbbLocationTinsoft.DisplayMember = "Value";
		}

		public Dictionary<string, string> TinsoftGetListLocation()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> listCountryTinsoft = SetupFolder.GetListCountryTinsoft();
			for (int i = 0; i < listCountryTinsoft.Count; i++)
			{
				string[] array = listCountryTinsoft[i].Split('|');
				dictionary.Add(array[0], array[1]);
			}
			return dictionary;
		}

		private void BtnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void FConfigGenneral_Load(object sender, EventArgs e)
		{
			LoadCbbLocation();
			LoadCbbSizeChrome();
			nudInteractThread.Value = settings.GetValueInt("nudInteractThread", 3);
			nudHideThread.Value = settings.GetValueInt("nudHideThread", 5);
			txbPathProfile.Text = ((settings.GetValue("txbPathProfile") == "") ? (Application.StartupPath + "\\profiles") : settings.GetValue("txbPathProfile"));
			if (!Directory.Exists(txbPathProfile.Text) || txbPathProfile.Text.Trim() == "profiles")
			{
				txbPathProfile.Text = Application.StartupPath + "\\profiles";
			}
			settings.Update("txbPathProfile", txbPathProfile.Text);
			ckbShowImageInteract.Checked = Convert.ToBoolean((settings.GetValue("ckbShowImageInteract") == "") ? "false" : settings.GetValue("ckbShowImageInteract"));
			ckbAddChromeIntoForm.Checked = settings.GetValueBool("ckbAddChromeIntoForm");
			nudWidthChrome.Value = settings.GetValueInt("nudWidthChrome", 320);
			nudHeighChrome.Value = settings.GetValueInt("nudHeighChrome", 480);
			nudDelayOpenChromeFrom.Value = settings.GetValueInt("nudDelayOpenChromeFrom", 1);
			nudDelayOpenChromeTo.Value = settings.GetValueInt("nudDelayOpenChromeTo", 1);
			nudDelayCloseChromeFrom.Value = settings.GetValueInt("nudDelayCloseChromeFrom");
			nudDelayCloseChromeTo.Value = settings.GetValueInt("nudDelayCloseChromeTo");
			cbbColumnChrome.Text = ((settings.GetValue("cbbColumnChrome") == "") ? "3" : settings.GetValue("cbbColumnChrome"));
			cbbRowChrome.Text = ((settings.GetValue("cbbRowChrome") == "") ? "2" : settings.GetValue("cbbRowChrome"));
			switch (settings.GetValueInt("typeBrowser"))
			{
			case 1:
				rbChromium.Checked = true;
				break;
			case 0:
				rbChrome.Checked = true;
				break;
			}
			txtLinkToOtherBrowser.Text = settings.GetValue("txtLinkToOtherBrowser");
			ckbUsePortable.Checked = settings.GetValueBool("ckbUsePortable");
			txtPathToPortableZip.Text = settings.GetValue("txtPathToPortableZip");
			cbbSizeChrome.SelectedValue = settings.GetValue("sizeChrome", "default").ToString();
			if (cbbSizeChrome.SelectedValue == null)
			{
				cbbSizeChrome.SelectedValue = "default";
			}
			switch (settings.GetValueInt("tocDoGoVanBan"))
			{
			case 0:
				rbTocDoGoCham.Checked = true;
				break;
			case 1:
				rbTocDoGoBinhThuong.Checked = true;
				break;
			case 2:
				rbTocDoGoNhanh.Checked = true;
				break;
			}
			ckbKhongCheckIP.Checked = settings.GetValueBool("ckbKhongCheckIP");
			nudChangeIpCount.Value = settings.GetValueInt("ip_nudChangeIpCount", 1);
			nudDelayCheckIP.Value = settings.GetValueInt("nudDelayCheckIP");
			switch (settings.GetValueInt("ip_iTypeChangeIp"))
			{
			case 0:
				rbNone.Checked = true;
				break;
			case 1:
				rbHma.Checked = true;
				break;
			case 2:
				rbDcom.Checked = true;
				break;
			case 3:
				rbSSH.Checked = true;
				break;
			case 4:
				rbExpressVPN.Checked = true;
				break;
			case 5:
				rbHotspot.Checked = true;
				break;
			case 6:
				rbNordVPN.Checked = true;
				break;
			case 7:
				rbTinsoft.Checked = true;
				break;
			case 8:
				rbXproxy.Checked = true;
				break;
			case 9:
				rbProxy.Checked = true;
				break;
			case 10:
				rbTMProxy.Checked = true;
				break;
			case 11:
				rbProxyv6.Checked = true;
				break;
			case 12:
				rbShopLike.Checked = true;
				break;
			case 13:
				rbMinProxy.Checked = true;
				break;
			}
			if (settings.GetValueInt("typeDcom") == 0)
			{
				rbDcomThuong.Checked = true;
			}
			else
			{
				rbDcomHilink.Checked = true;
			}
			txtProfileNameDcom.Text = settings.GetValue("ip_txtProfileNameDcom");
			txtUrlHilink.Text = settings.GetValue("txtUrlHilink", "http://192.168.1.1/html/home.html");
			txtNordVPN.Text = settings.GetValue("ip_txtNordVPN");
			cbbHostpot.SelectedIndex = settings.GetValueInt("ip_cbbHostpot");
			if (settings.GetValueInt("typeApiTinsoft") == 0)
			{
				rbApiUser.Checked = true;
			}
			else
			{
				rbApiProxy.Checked = true;
			}
			txtApiUser.Text = settings.GetValue("txtApiUser");
			txtApiProxy.Text = settings.GetValue("txtApiProxy");
			cbbLocationTinsoft.SelectedValue = ((settings.GetValue("cbbLocationTinsoft") == "") ? "0" : settings.GetValue("cbbLocationTinsoft"));
			nudLuongPerIPTinsoft.Value = settings.GetValueInt("nudLuongPerIPTinsoft");
			ckbWaitDoneAllTinsoft.Checked = settings.GetValueBool("ckbWaitDoneAllTinsoft");
			txtServiceURLXProxy.Text = settings.GetValue("txtServiceURLXProxy");
			if (settings.GetValueInt("typeProxy") == 0)
			{
				rbHttpProxy.Checked = true;
			}
			else
			{
				rbSock5Proxy.Checked = true;
			}
			txtListProxy.Text = settings.GetValue("txtListProxy");
			nudLuongPerIPXProxy.Value = settings.GetValueInt("nudLuongPerIPXProxy");
			nudDelayResetXProxy.Value = settings.GetValueInt("nudDelayResetXProxy", 5);
			ckbWaitDoneAllXproxy.Checked = settings.GetValueBool("ckbWaitDoneAllXproxy");
			if (settings.GetValueInt("typeRunXproxy") == 0)
			{
				rbXproxyResetEachProxy.Checked = true;
			}
			else
			{
				rbXproxyResetAllProxy.Checked = true;
			}
			txtApiKeyTMProxy.Text = settings.GetValue("txtApiKeyTMProxy");
			nudLuongPerIPTMProxy.Value = settings.GetValueInt("nudLuongPerIPTMProxy", 1);
			ckbWaitDoneAllTMProxy.Checked = settings.GetValueBool("ckbWaitDoneAllTMProxy");
			txtApiProxyv6.Text = settings.GetValue("txtApiProxyv6");
			txtListProxyv6.Text = settings.GetValue("txtListProxyv6");
			nudLuongPerIPProxyv6.Value = settings.GetValueInt("nudLuongPerIPProxyv6");
			txtApiShopLike.Text = settings.GetValue("txtApiShopLike");
			nudLuongPerIPShopLike.Value = settings.GetValueInt("nudLuongPerIPShopLike");
			txtApiKeyMinProxy.Text = settings.GetValue("txtApiKeyMinProxy");
			nudLuongPerIPMinProxy.Value = settings.GetValueInt("nudLuongPerIPMinProxy");
			if (settings.GetValueInt("typePhanBietMau") == 0)
			{
				rbPhanBietMauNen.Checked = true;
			}
			else
			{
				rbPhanBietMauChu.Checked = true;
			}
			CheckedChangedFull();
		}

		private void BtnSave_Click(object sender, EventArgs e)
		{
			try
			{
				settings.Update("nudInteractThread", nudInteractThread.Value);
				settings.Update("nudHideThread", nudHideThread.Value);
				settings.Update("txbPathProfile", txbPathProfile.Text);
				settings.Update("ckbShowImageInteract", ckbShowImageInteract.Checked);
				settings.Update("ckbAddChromeIntoForm", ckbAddChromeIntoForm.Checked);
				settings.Update("nudWidthChrome", nudWidthChrome.Value);
				settings.Update("nudHeighChrome", nudHeighChrome.Value);
				settings.Update("nudDelayOpenChromeFrom", nudDelayOpenChromeFrom.Value);
				settings.Update("nudDelayOpenChromeTo", nudDelayOpenChromeTo.Value);
				settings.Update("nudDelayCloseChromeFrom", nudDelayCloseChromeFrom.Value);
				settings.Update("nudDelayCloseChromeTo", nudDelayCloseChromeTo.Value);
				settings.Update("cbbColumnChrome", cbbColumnChrome.Text);
				settings.Update("cbbRowChrome", cbbRowChrome.Text);
				int num = 0;
				if (rbChromium.Checked)
				{
					num = 1;
				}
				settings.Update("typeBrowser", num);
				settings.Update("txtLinkToOtherBrowser", txtLinkToOtherBrowser.Text.Trim());
				settings.Update("ckbUsePortable", ckbUsePortable.Checked);
				settings.Update("txtPathToPortableZip", txtPathToPortableZip.Text.Trim());
				if (num != 0 && txtLinkToOtherBrowser.Text.Trim() == "")
				{
					string arg = "";
					switch (num)
					{
					case 1:
						arg = "Chromium";
						break;
					case 2:
						arg = "Cô\u0301c cô\u0301c";
						break;
					case 3:
						arg = "Slimjet";
						break;
					}
					MessageBoxHelper.ShowMessageBox(string.Format(Language.GetValue("Vui lo\u0300ng nhâ\u0323p đươ\u0300ng dâ\u0303n đê\u0301n file cha\u0323y cu\u0309a tri\u0300nh duyê\u0323t {0}!"), arg), 2);
					return;
				}
				if (cbbSizeChrome.Items.Count > 0 && cbbSizeChrome.SelectedValue.ToString() != "")
				{
					settings.Update("sizeChrome", cbbSizeChrome.SelectedValue.ToString());
				}
				if (rbTocDoGoCham.Checked)
				{
					settings.Update("tocDoGoVanBan", 0);
				}
				else if (rbTocDoGoBinhThuong.Checked)
				{
					settings.Update("tocDoGoVanBan", 1);
				}
				else
				{
					settings.Update("tocDoGoVanBan", 2);
				}
				settings.Update("ckbKhongCheckIP", ckbKhongCheckIP.Checked);
				settings.Update("ip_nudChangeIpCount", nudChangeIpCount.Value);
				settings.Update("nudDelayCheckIP", nudDelayCheckIP.Value);
				int num2 = 0;
				if (rbNone.Checked)
				{
					num2 = 0;
				}
				else if (rbHma.Checked)
				{
					num2 = 1;
				}
				else if (rbDcom.Checked)
				{
					num2 = 2;
				}
				else if (rbSSH.Checked)
				{
					num2 = 3;
				}
				else if (rbExpressVPN.Checked)
				{
					num2 = 4;
				}
				else if (rbHotspot.Checked)
				{
					num2 = 5;
				}
				else if (rbNordVPN.Checked)
				{
					num2 = 6;
				}
				else if (rbTinsoft.Checked)
				{
					num2 = 7;
				}
				else if (rbXproxy.Checked)
				{
					num2 = 8;
				}
				else if (rbProxy.Checked)
				{
					num2 = 9;
				}
				else if (rbTMProxy.Checked)
				{
					num2 = 10;
				}
				else if (rbProxyv6.Checked)
				{
					num2 = 11;
				}
				else if (rbShopLike.Checked)
				{
					num2 = 12;
				}
				else if (rbMinProxy.Checked)
				{
					num2 = 13;
				}
				settings.Update("ip_iTypeChangeIp", num2);
				if (rbDcomThuong.Checked)
				{
					settings.Update("typeDcom", 0);
				}
				else
				{
					settings.Update("typeDcom", 1);
				}
				settings.Update("txtUrlHilink", txtUrlHilink.Text);
				settings.Update("ip_txtProfileNameDcom", txtProfileNameDcom.Text);
				settings.Update("ip_txtNordVPN", txtNordVPN.Text);
				settings.Update("ip_cbbHostpot", cbbHostpot.SelectedIndex);
				if (rbApiUser.Checked)
				{
					settings.Update("typeApiTinsoft", 0);
				}
				else
				{
					settings.Update("typeApiTinsoft", 1);
				}
				settings.Update("txtApiUser", txtApiUser.Text);
				settings.Update("txtApiProxy", txtApiProxy.Text);
				settings.Update("cbbLocationTinsoft", cbbLocationTinsoft.SelectedValue);
				settings.Update("nudLuongPerIPTinsoft", nudLuongPerIPTinsoft.Value);
				settings.Update("ckbWaitDoneAllTinsoft", ckbWaitDoneAllTinsoft.Checked);
				settings.Update("txtServiceURLXProxy", txtServiceURLXProxy.Text);
				int num3 = 0;
				if (rbSock5Proxy.Checked)
				{
					num3 = 1;
				}
				settings.Update("typeProxy", num3);
				settings.Update("txtListProxy", txtListProxy.Text);
				settings.Update("nudLuongPerIPXProxy", nudLuongPerIPXProxy.Value);
				settings.Update("nudDelayResetXProxy", nudDelayResetXProxy.Value);
				settings.Update("ckbWaitDoneAllXproxy", ckbWaitDoneAllXproxy.Checked);
				if (rbXproxyResetEachProxy.Checked)
				{
					settings.Update("typeRunXproxy", 0);
				}
				else
				{
					settings.Update("typeRunXproxy", 1);
				}
				settings.Update("txtApiKeyTMProxy", txtApiKeyTMProxy.Text);
				settings.Update("nudLuongPerIPTMProxy", nudLuongPerIPTMProxy.Value);
				settings.Update("ckbWaitDoneAllTMProxy", ckbWaitDoneAllTMProxy.Checked);
				settings.Update("txtApiProxyv6", txtApiProxyv6.Text);
				settings.Update("txtListProxyv6", txtListProxyv6.Text);
				settings.Update("nudLuongPerIPProxyv6", nudLuongPerIPProxyv6.Value);
				settings.Update("txtApiShopLike", txtApiShopLike.Text);
				settings.Update("nudLuongPerIPShopLike", nudLuongPerIPShopLike.Value);
				settings.Update("txtApiKeyMinProxy", txtApiKeyMinProxy.Text);
				settings.Update("nudLuongPerIPMinProxy", nudLuongPerIPMinProxy.Value);
				if (rbPhanBietMauNen.Checked)
				{
					settings.Update("typePhanBietMau", 0);
				}
				else
				{
					settings.Update("typePhanBietMau", 1);
				}
				settings.Save();
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Lưu thành công, ba\u0323n co\u0301 muô\u0301n đo\u0301ng cư\u0309a sô\u0309?")) == DialogResult.Yes)
				{
					Close();
				}
			}
			catch
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Lỗi!"));
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			if (settings.GetValueInt("ip_iTypeChangeIp") == 0)
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng chọn loại đổi IP"), 3);
			}
			else if (MCommon.Common.ChangeIP(settings.GetValueInt("ip_iTypeChangeIp"), settings.GetValueInt("typeDcom"), settings.GetValue("ip_txtProfileNameDcom"), settings.GetValue("txtUrlHilink"), settings.GetValueInt("ip_cbbHostpot"), settings.GetValue("ip_txtNordVPN")))
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Đổi IP thành công!"));
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Đổi IP thất bại!"), 2);
			}
		}

		private void btnSSH_Click(object sender, EventArgs e)
		{
			Process.Start("changeip\\ssh.txt");
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (CommonChrome.GetUserAgentDefault() == "")
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng cập nhật chromedriver!"), 3);
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Phiên bản chromedriver khả dụng!"));
			}
		}

		private void rbTinsoft_CheckedChanged(object sender, EventArgs e)
		{
			plTinsoft.Enabled = rbTinsoft.Checked;
		}

		private void rbNordVPN_CheckedChanged(object sender, EventArgs e)
		{
			panel2.Enabled = rbNordVPN.Checked;
		}

		private void CheckedChangedFull()
		{
			rbTinsoft_CheckedChanged(null, null);
			rbNordVPN_CheckedChanged(null, null);
			rbDcom_CheckedChanged(null, null);
			rbXproxy_CheckedChanged(null, null);
			rbHma_CheckedChanged(null, null);
			rbChrome_CheckedChanged(null, null);
			rbTMProxy_CheckedChanged(null, null);
			rbApiUser_CheckedChanged(null, null);
			rbApiProxy_CheckedChanged(null, null);
			ckbAddChromeIntoForm_CheckedChanged(null, null);
			ckbUsePortable_CheckedChanged(null, null);
			rbDcomHilink_CheckedChanged(null, null);
			radioButton1_CheckedChanged(null, null);
			rbProxyv6_CheckedChanged(null, null);
			rbShopLike_CheckedChanged(null, null);
			rbMinProxy_CheckedChanged(null, null);
		}

		private void button3_Click(object sender, EventArgs e)
		{
			string api_user = txtApiUser.Text.Trim();
			List<string> listKey = TinsoftProxy.GetListKey(api_user);
			if (listKey.Count > 0)
			{
				MessageBoxHelper.ShowMessageBox(string.Format(Language.GetValue("Đang có {0} proxy khả dụng!"), listKey.Count));
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Không có proxy khả dụng!"), 2);
			}
		}

		private void rbDcom_CheckedChanged(object sender, EventArgs e)
		{
			plDcom.Enabled = rbDcom.Checked;
			CheckDoiIPEnable();
		}

		private void rbXproxy_CheckedChanged(object sender, EventArgs e)
		{
			plXproxy.Enabled = rbXproxy.Checked;
		}

		private void CheckDoiIPEnable()
		{
			plCheckDoiIP.Enabled = rbDcom.Checked || rbHma.Checked;
		}

		private void rbHma_CheckedChanged(object sender, EventArgs e)
		{
			CheckDoiIPEnable();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				ProcessStartInfo startInfo = new ProcessStartInfo("rasdial.exe")
				{
					UseShellExecute = false,
					RedirectStandardOutput = true,
					CreateNoWindow = true
				};
				Process process = Process.Start(startInfo);
				string text = process.StandardOutput.ReadToEnd();
				if (text.Split('\n').Length <= 3)
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng kết nối Dcom trước!"), 2);
					return;
				}
				txtProfileNameDcom.Text = text.Split('\n').ToList()[1];
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Lấy tên cấu hình Dcom thành công!"));
			}
			catch (Exception ex)
			{
				MCommon.Common.ExportError(null, ex, "change ip dcom");
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Có lỗi xảy ra, vui lòng thử lại sau!"), 2);
			}
		}

		private void ChangeVisibleBrowser()
		{
			if (rbChrome.Checked)
			{
				plLinkToOtherBrowser.Visible = false;
			}
			else
			{
				plLinkToOtherBrowser.Visible = true;
			}
		}

		private void rbChrome_CheckedChanged(object sender, EventArgs e)
		{
			ChangeVisibleBrowser();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			try
			{
				MCommon.Common.CreateFolder("data\\extension");
				Process.Start("data\\extension");
			}
			catch
			{
			}
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				btnUp.Visible = true;
				btnDown.Visible = true;
			}
			else if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Alt)
			{
				plSizeChrome.Visible = false;
			}
		}

		private void rbTMProxy_CheckedChanged(object sender, EventArgs e)
		{
			plTMProxy.Enabled = rbTMProxy.Checked;
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			try
			{
				Process.Start("https://youtu.be/eexEDCyPbR8");
			}
			catch
			{
			}
		}

		private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			try
			{
				Process.Start("https://www.youtube.com/watch?v=0t1IwKxkyKw");
			}
			catch
			{
			}
		}

		private void txtApiProxy_TextChanged(object sender, EventArgs e)
		{
			try
			{
				List<string> lst = txtApiProxy.Lines.ToList();
				lst = MCommon.Common.RemoveEmptyItems(lst);
				lblCountApiProxy.Text = "(" + lst.Count + ")";
			}
			catch
			{
			}
		}

		private void rbApiUser_CheckedChanged(object sender, EventArgs e)
		{
			plApiUser.Enabled = rbApiUser.Checked;
		}

		private void rbApiProxy_CheckedChanged(object sender, EventArgs e)
		{
			plApiProxy.Enabled = rbApiProxy.Checked;
		}

		private void button7_Click(object sender, EventArgs e)
		{
			List<string> list = new List<string>();
			List<string> lst = txtApiProxy.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			foreach (string item in lst)
			{
				if (TinsoftProxy.CheckApiProxy(item))
				{
					list.Add(item);
				}
			}
			txtApiProxy.Lines = list.ToArray();
			if (list.Count > 0)
			{
				MessageBoxHelper.ShowMessageBox(string.Format(Language.GetValue("Đang có {0} proxy khả dụng!"), list.Count));
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Không có proxy khả dụng!"), 2);
			}
		}

		private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			try
			{
				Process.Start("https://www.youtube.com/watch?v=XZTveKk-utY");
			}
			catch
			{
			}
		}

		private void plXproxy_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				ckbWaitDoneAllXproxy.Visible = true;
			}
		}

		private void plTinsoft_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				ckbWaitDoneAllTinsoft.Visible = true;
			}
		}

		private void plTMProxy_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				ckbWaitDoneAllTMProxy.Visible = true;
			}
		}

		private void btnDown_Click(object sender, EventArgs e)
		{
			grChrome.Height = 318;
		}

		private void btnUp_Click(object sender, EventArgs e)
		{
			grChrome.Height = 233;
		}

		private void AddFileAccount_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fThemSizeChrome());
			LoadCbbSizeChrome();
			JSON_Settings jSON_Settings = new JSON_Settings("configGeneral");
			cbbSizeChrome.SelectedValue = jSON_Settings.GetValue("sizeChrome", "default").ToString();
			if (cbbSizeChrome.SelectedValue == null)
			{
				cbbSizeChrome.SelectedValue = "default";
			}
		}

		private void LoadCbbSizeChrome()
		{
			JSON_Settings jSON_Settings = new JSON_Settings("configChrome");
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("default", "Mặc định");
			if (jSON_Settings.GetValue("sizeChrome") != "")
			{
				Dictionary<string, object> dictionary2 = JSON_Settings.ConvertToDictionary(JObject.Parse(jSON_Settings.GetValue("sizeChrome")));
				foreach (KeyValuePair<string, object> item in dictionary2)
				{
					dictionary.Add(item.Value.ToString(), item.Key + $" ({item.Value})");
				}
			}
			cbbSizeChrome.DataSource = new BindingSource(dictionary, null);
			cbbSizeChrome.ValueMember = "Key";
			cbbSizeChrome.DisplayMember = "Value";
		}

		private void button8_Click(object sender, EventArgs e)
		{
			List<string> list = new List<string>();
			List<string> lst = txtApiKeyTMProxy.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			foreach (string item in lst)
			{
				if (TMProxy.CheckApiProxy(item))
				{
					list.Add(item);
				}
			}
			txtApiKeyTMProxy.Lines = list.ToArray();
			if (list.Count > 0)
			{
				MessageBoxHelper.ShowMessageBox(string.Format(Language.GetValue("Đang có {0} proxy khả dụng!"), list.Count));
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Không có proxy khả dụng!"), 2);
			}
		}

		private void txtApiKeyTMProxy_TextChanged(object sender, EventArgs e)
		{
			try
			{
				List<string> lst = txtApiKeyTMProxy.Lines.ToList();
				lst = MCommon.Common.RemoveEmptyItems(lst);
				label24.Text = string.Format(Language.GetValue("Nhập API KEY ({0}):"), lst.Count.ToString());
			}
			catch
			{
			}
		}

		private void txtListProxy_TextChanged(object sender, EventArgs e)
		{
			try
			{
				List<string> lst = txtListProxy.Lines.ToList();
				lst = MCommon.Common.RemoveEmptyItems(lst);
				label17.Text = string.Format(Language.GetValue("Nhập Proxy ({0}):"), lst.Count.ToString());
			}
			catch
			{
			}
		}

		private void txbPathProfile_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Left && Control.ModifierKeys == Keys.Control)
			{
				Process.Start(txbPathProfile.Text.Trim());
			}
		}

		private void ckbAddChromeIntoForm_CheckedChanged(object sender, EventArgs e)
		{
			plAddChromeVaoFormView.Enabled = ckbAddChromeIntoForm.Checked;
			plSapXepCuaSoChrome.Enabled = !ckbAddChromeIntoForm.Checked;
		}

		private void button9_Click(object sender, EventArgs e)
		{
			txbPathProfile.Text = MCommon.Common.SelectFolder();
		}

		private void panel3_Paint(object sender, PaintEventArgs e)
		{
		}

		private void ckbUsePortable_CheckedChanged(object sender, EventArgs e)
		{
			lblFileZip.Enabled = ckbUsePortable.Checked;
			txtPathToPortableZip.Enabled = ckbUsePortable.Checked;
		}

		private void panel3_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Left && Control.ModifierKeys == Keys.Control)
			{
				plUsePortable.BringToFront();
			}
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			button4.Enabled = rbDcomThuong.Checked;
			txtProfileNameDcom.Enabled = rbDcomThuong.Checked;
		}

		private void rbDcomHilink_CheckedChanged(object sender, EventArgs e)
		{
			label36.Enabled = rbDcomHilink.Checked;
			txtUrlHilink.Enabled = rbDcomHilink.Checked;
		}

		private void rbNone_CheckedChanged(object sender, EventArgs e)
		{
			if (rbNone.Checked)
			{
				ckbKhongCheckIP.Checked = true;
			}
		}

		private void txtListProxyv6_TextChanged(object sender, EventArgs e)
		{
			List<string> lst = txtListProxyv6.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			label43.Text = string.Format(Language.GetValue("Nhập Proxy ({0}):"), lst.Count.ToString());
		}

		private void richTextBox1_TextChanged(object sender, EventArgs e)
		{
			List<string> lst = txtListProxyVitech.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			label41.Text = string.Format(Language.GetValue("Nhập Proxy ({0}):"), lst.Count.ToString());
		}

		private void rbProxyv6_CheckedChanged(object sender, EventArgs e)
		{
			plProxyv6.Enabled = rbProxyv6.Checked;
		}

		private void rbVitech_CheckedChanged(object sender, EventArgs e)
		{
			plVitech.Enabled = rbVitech.Checked;
		}

		private void rbShopLike_CheckedChanged(object sender, EventArgs e)
		{
			plShopLike.Enabled = rbShopLike.Checked;
		}

		private void txtApiProxyShopLike_TextChanged(object sender, EventArgs e)
		{
			List<string> lst = txtApiShopLike.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			label47.Text = string.Format(Language.GetValue("Nhập API KEY ({0}):"), lst.Count.ToString());
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void txbPathProfile_TextChanged(object sender, EventArgs e)
		{
		}

		private void rbMinProxy_CheckedChanged(object sender, EventArgs e)
		{
			panel5.Enabled = rbMinProxy.Checked;
		}

		private void txtApiKeyMinProxy_TextChanged(object sender, EventArgs e)
		{
			List<string> lst = txtApiKeyMinProxy.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			label49.Text = string.Format(Language.GetValue("Nhập API KEY ({0}):"), lst.Count.ToString());
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
			if (plXproxy.Height == 260)
			{
				plXproxy.Height = 170;
				(sender as Button).BackgroundImage = Resources.icons8_expand_arrow_24px;
			}
			else
			{
				plXproxy.Height = 260;
				(sender as Button).BackgroundImage = Resources.icons8_collapse_arrow_24px;
			}
		}

		private void button10_Click(object sender, EventArgs e)
		{
			List<string> list = new List<string>();
			List<string> lst = txtApiKeyMinProxy.Lines.ToList();
			lst = MCommon.Common.RemoveEmptyItems(lst);
			foreach (string item in lst)
			{
				if (MinProxy.CheckApiProxy(item))
				{
					list.Add(item);
				}
			}
			txtApiKeyMinProxy.Lines = list.ToArray();
			if (list.Count > 0)
			{
				MessageBoxHelper.ShowMessageBox(string.Format(Language.GetValue("Đang có {0} proxy khả dụng!"), list.Count));
			}
			else
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Không có proxy khả dụng!"), 2);
			}
		}

		private void metroButton2_Click(object sender, EventArgs e)
		{
			base.Size = new Size(1158, 930);
		}

		private void metroButton3_Click(object sender, EventArgs e)
		{
			base.Size = new Size(1158, 544);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fCauHinhChung));
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			label3 = new System.Windows.Forms.Label();
			nudInteractThread = new System.Windows.Forms.NumericUpDown();
			label4 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			nudHideThread = new System.Windows.Forms.NumericUpDown();
			label6 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			txbPathProfile = new System.Windows.Forms.TextBox();
			panel1 = new System.Windows.Forms.Panel();
			plVitech = new System.Windows.Forms.Panel();
			txtListProxyVitech = new System.Windows.Forms.RichTextBox();
			radioButton9 = new System.Windows.Forms.RadioButton();
			radioButton10 = new System.Windows.Forms.RadioButton();
			label40 = new System.Windows.Forms.Label();
			label41 = new System.Windows.Forms.Label();
			label42 = new System.Windows.Forms.Label();
			nudLuongPerIPVitech = new System.Windows.Forms.NumericUpDown();
			label46 = new System.Windows.Forms.Label();
			txtApiVitech = new System.Windows.Forms.TextBox();
			grChrome = new System.Windows.Forms.GroupBox();
			panel3 = new System.Windows.Forms.Panel();
			button1 = new System.Windows.Forms.Button();
			linkLabel2 = new System.Windows.Forms.LinkLabel();
			plSizeChrome = new System.Windows.Forms.Panel();
			rbTocDoGoNhanh = new System.Windows.Forms.RadioButton();
			rbTocDoGoBinhThuong = new System.Windows.Forms.RadioButton();
			rbTocDoGoCham = new System.Windows.Forms.RadioButton();
			label30 = new System.Windows.Forms.Label();
			plSapXepCuaSoChrome = new System.Windows.Forms.Panel();
			label10 = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			cbbColumnChrome = new System.Windows.Forms.ComboBox();
			cbbRowChrome = new System.Windows.Forms.ComboBox();
			plAddChromeVaoFormView = new System.Windows.Forms.Panel();
			nudWidthChrome = new System.Windows.Forms.NumericUpDown();
			label35 = new System.Windows.Forms.Label();
			label33 = new System.Windows.Forms.Label();
			nudHeighChrome = new System.Windows.Forms.NumericUpDown();
			AddFileAccount = new MetroFramework.Controls.MetroButton();
			btnDown = new MetroFramework.Controls.MetroButton();
			btnUp = new MetroFramework.Controls.MetroButton();
			nudDelayCloseChromeFrom = new System.Windows.Forms.NumericUpDown();
			nudDelayCloseChromeTo = new System.Windows.Forms.NumericUpDown();
			nudDelayOpenChromeFrom = new System.Windows.Forms.NumericUpDown();
			nudDelayOpenChromeTo = new System.Windows.Forms.NumericUpDown();
			plLinkToOtherBrowser = new System.Windows.Forms.Panel();
			label19 = new System.Windows.Forms.Label();
			txtLinkToOtherBrowser = new System.Windows.Forms.TextBox();
			rbChromium = new System.Windows.Forms.RadioButton();
			rbChrome = new System.Windows.Forms.RadioButton();
			label22 = new System.Windows.Forms.Label();
			label15 = new System.Windows.Forms.Label();
			ckbShowImageInteract = new System.Windows.Forms.CheckBox();
			ckbAddChromeIntoForm = new System.Windows.Forms.CheckBox();
			label32 = new System.Windows.Forms.Label();
			cbbSizeChrome = new System.Windows.Forms.ComboBox();
			label31 = new System.Windows.Forms.Label();
			label29 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label21 = new System.Windows.Forms.Label();
			label20 = new System.Windows.Forms.Label();
			label34 = new System.Windows.Forms.Label();
			button6 = new System.Windows.Forms.Button();
			plUsePortable = new System.Windows.Forms.Panel();
			txtPathToPortableZip = new System.Windows.Forms.TextBox();
			lblFileZip = new System.Windows.Forms.Label();
			ckbUsePortable = new System.Windows.Forms.CheckBox();
			cbbHostpot = new System.Windows.Forms.ComboBox();
			rbVitech = new System.Windows.Forms.RadioButton();
			bunifuCards2 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			button2 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			btnCancel = new System.Windows.Forms.Button();
			panel2 = new System.Windows.Forms.Panel();
			label12 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			btnSave = new System.Windows.Forms.Button();
			plNordVPN = new System.Windows.Forms.Panel();
			label14 = new System.Windows.Forms.Label();
			txtNordVPN = new System.Windows.Forms.TextBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			panel4 = new System.Windows.Forms.Panel();
			rbPhanBietMauNen = new System.Windows.Forms.RadioButton();
			rbPhanBietMauChu = new System.Windows.Forms.RadioButton();
			label23 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button9 = new System.Windows.Forms.Button();
			btnSSH = new System.Windows.Forms.Button();
			radioButton4 = new System.Windows.Forms.RadioButton();
			rbHotspot = new System.Windows.Forms.RadioButton();
			radioButton5 = new System.Windows.Forms.RadioButton();
			rbNordVPN = new System.Windows.Forms.RadioButton();
			radioButton2 = new System.Windows.Forms.RadioButton();
			rbSSH = new System.Windows.Forms.RadioButton();
			radioButton3 = new System.Windows.Forms.RadioButton();
			rbExpressVPN = new System.Windows.Forms.RadioButton();
			groupBox3 = new System.Windows.Forms.GroupBox();
			metroButton2 = new MetroFramework.Controls.MetroButton();
			metroButton3 = new MetroFramework.Controls.MetroButton();
			panel5 = new System.Windows.Forms.Panel();
			button10 = new System.Windows.Forms.Button();
			txtApiKeyMinProxy = new System.Windows.Forms.RichTextBox();
			label49 = new System.Windows.Forms.Label();
			label50 = new System.Windows.Forms.Label();
			nudLuongPerIPMinProxy = new System.Windows.Forms.NumericUpDown();
			plShopLike = new System.Windows.Forms.Panel();
			txtApiShopLike = new System.Windows.Forms.RichTextBox();
			label47 = new System.Windows.Forms.Label();
			label48 = new System.Windows.Forms.Label();
			nudLuongPerIPShopLike = new System.Windows.Forms.NumericUpDown();
			rbMinProxy = new System.Windows.Forms.RadioButton();
			plXproxy = new System.Windows.Forms.Panel();
			label53 = new System.Windows.Forms.Label();
			rbXproxyResetAllProxy = new System.Windows.Forms.RadioButton();
			rbXproxyResetEachProxy = new System.Windows.Forms.RadioButton();
			ckbWaitDoneAllXproxy = new System.Windows.Forms.CheckBox();
			txtListProxy = new System.Windows.Forms.RichTextBox();
			rbSock5Proxy = new System.Windows.Forms.RadioButton();
			rbHttpProxy = new System.Windows.Forms.RadioButton();
			label16 = new System.Windows.Forms.Label();
			metroButton1 = new MetroFramework.Controls.MetroButton();
			label17 = new System.Windows.Forms.Label();
			label52 = new System.Windows.Forms.Label();
			label51 = new System.Windows.Forms.Label();
			label18 = new System.Windows.Forms.Label();
			nudDelayResetXProxy = new System.Windows.Forms.NumericUpDown();
			nudLuongPerIPXProxy = new System.Windows.Forms.NumericUpDown();
			label13 = new System.Windows.Forms.Label();
			txtServiceURLXProxy = new System.Windows.Forms.TextBox();
			rbShopLike = new System.Windows.Forms.RadioButton();
			plProxyv6 = new System.Windows.Forms.Panel();
			txtListProxyv6 = new System.Windows.Forms.RichTextBox();
			radioButton1 = new System.Windows.Forms.RadioButton();
			radioButton6 = new System.Windows.Forms.RadioButton();
			label39 = new System.Windows.Forms.Label();
			label43 = new System.Windows.Forms.Label();
			label44 = new System.Windows.Forms.Label();
			nudLuongPerIPProxyv6 = new System.Windows.Forms.NumericUpDown();
			label45 = new System.Windows.Forms.Label();
			txtApiProxyv6 = new System.Windows.Forms.TextBox();
			rbProxyv6 = new System.Windows.Forms.RadioButton();
			label37 = new System.Windows.Forms.Label();
			nudDelayCheckIP = new System.Windows.Forms.NumericUpDown();
			linkLabel3 = new System.Windows.Forms.LinkLabel();
			label38 = new System.Windows.Forms.Label();
			linkLabel1 = new System.Windows.Forms.LinkLabel();
			plTMProxy = new System.Windows.Forms.Panel();
			ckbWaitDoneAllTMProxy = new System.Windows.Forms.CheckBox();
			txtApiKeyTMProxy = new System.Windows.Forms.RichTextBox();
			label24 = new System.Windows.Forms.Label();
			button8 = new System.Windows.Forms.Button();
			label25 = new System.Windows.Forms.Label();
			nudLuongPerIPTMProxy = new System.Windows.Forms.NumericUpDown();
			plCheckDoiIP = new System.Windows.Forms.Panel();
			button5 = new System.Windows.Forms.Button();
			label26 = new System.Windows.Forms.Label();
			nudChangeIpCount = new System.Windows.Forms.NumericUpDown();
			label27 = new System.Windows.Forms.Label();
			plTinsoft = new System.Windows.Forms.Panel();
			ckbWaitDoneAllTinsoft = new System.Windows.Forms.CheckBox();
			plApiProxy = new System.Windows.Forms.Panel();
			lblCountApiProxy = new System.Windows.Forms.Label();
			label28 = new System.Windows.Forms.Label();
			txtApiProxy = new System.Windows.Forms.TextBox();
			button7 = new System.Windows.Forms.Button();
			plApiUser = new System.Windows.Forms.Panel();
			label1 = new System.Windows.Forms.Label();
			txtApiUser = new System.Windows.Forms.TextBox();
			button3 = new System.Windows.Forms.Button();
			cbbLocationTinsoft = new System.Windows.Forms.ComboBox();
			rbApiProxy = new System.Windows.Forms.RadioButton();
			rbApiUser = new System.Windows.Forms.RadioButton();
			label7 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			nudLuongPerIPTinsoft = new System.Windows.Forms.NumericUpDown();
			rbTMProxy = new System.Windows.Forms.RadioButton();
			plDcom = new System.Windows.Forms.Panel();
			button4 = new System.Windows.Forms.Button();
			txtUrlHilink = new System.Windows.Forms.TextBox();
			txtProfileNameDcom = new System.Windows.Forms.TextBox();
			rbDcomHilink = new System.Windows.Forms.RadioButton();
			label36 = new System.Windows.Forms.Label();
			rbDcomThuong = new System.Windows.Forms.RadioButton();
			rbDcom = new System.Windows.Forms.RadioButton();
			rbTinsoft = new System.Windows.Forms.RadioButton();
			rbProxy = new System.Windows.Forms.RadioButton();
			rbNone = new System.Windows.Forms.RadioButton();
			rbXproxy = new System.Windows.Forms.RadioButton();
			rbHma = new System.Windows.Forms.RadioButton();
			ckbKhongCheckIP = new System.Windows.Forms.CheckBox();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			panel6 = new System.Windows.Forms.Panel();
			panel7 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)nudInteractThread).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudHideThread).BeginInit();
			panel1.SuspendLayout();
			plVitech.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPVitech).BeginInit();
			grChrome.SuspendLayout();
			panel3.SuspendLayout();
			plSizeChrome.SuspendLayout();
			plSapXepCuaSoChrome.SuspendLayout();
			plAddChromeVaoFormView.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudWidthChrome).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudHeighChrome).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCloseChromeFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCloseChromeTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayOpenChromeFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayOpenChromeTo).BeginInit();
			plLinkToOtherBrowser.SuspendLayout();
			plUsePortable.SuspendLayout();
			bunifuCards2.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel2.SuspendLayout();
			plNordVPN.SuspendLayout();
			groupBox1.SuspendLayout();
			panel4.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			panel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPMinProxy).BeginInit();
			plShopLike.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPShopLike).BeginInit();
			plXproxy.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudDelayResetXProxy).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPXProxy).BeginInit();
			plProxyv6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPProxyv6).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCheckIP).BeginInit();
			plTMProxy.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPTMProxy).BeginInit();
			plCheckDoiIP.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudChangeIpCount).BeginInit();
			plTinsoft.SuspendLayout();
			plApiProxy.SuspendLayout();
			plApiUser.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPTinsoft).BeginInit();
			plDcom.SuspendLayout();
			panel7.SuspendLayout();
			SuspendLayout();
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 5;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.SaddleBrown;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(575, 38);
			bunifuCards1.TabIndex = 12;
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(32, 27);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(158, 16);
			label3.TabIndex = 23;
			label3.Text = "Số luồng chạy tri\u0300nh duyê\u0323t:";
			nudInteractThread.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			nudInteractThread.Location = new System.Drawing.Point(207, 25);
			nudInteractThread.Maximum = new decimal(new int[4] { 1410065407, 2, 0, 0 });
			nudInteractThread.Name = "nudInteractThread";
			nudInteractThread.Size = new System.Drawing.Size(89, 23);
			nudInteractThread.TabIndex = 24;
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label4.Location = new System.Drawing.Point(299, 27);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(42, 16);
			label4.TabIndex = 25;
			label4.Text = "Luồng";
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label5.Location = new System.Drawing.Point(299, 55);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(42, 16);
			label5.TabIndex = 28;
			label5.Text = "Luồng";
			nudHideThread.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			nudHideThread.Location = new System.Drawing.Point(207, 53);
			nudHideThread.Maximum = new decimal(new int[4] { 1410065407, 2, 0, 0 });
			nudHideThread.Name = "nudHideThread";
			nudHideThread.Size = new System.Drawing.Size(89, 23);
			nudHideThread.TabIndex = 27;
			label6.AutoSize = true;
			label6.Cursor = System.Windows.Forms.Cursors.Help;
			label6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label6.Location = new System.Drawing.Point(32, 55);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(131, 16);
			label6.TabIndex = 26;
			label6.Text = "Số luồng chạy ẩn (?):";
			toolTip1.SetToolTip(label6, "La\u0300 sô\u0301 luô\u0300ng khi cha\u0323y ca\u0301c chư\u0301c năng không liên quan gi\u0300 đê\u0301n tri\u0300nh duyê\u0323t.\r\nVi\u0301 du\u0323 như: Check wall, Check Avatar,...\r\n(Khuyê\u0301n ca\u0301o nên đê\u0309 10 luô\u0300ng)");
			label9.AutoSize = true;
			label9.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label9.Location = new System.Drawing.Point(32, 84);
			label9.Name = "label9";
			label9.Size = new System.Drawing.Size(153, 16);
			label9.TabIndex = 33;
			label9.Text = "Đường dẫn folder profile:";
			txbPathProfile.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			txbPathProfile.Location = new System.Drawing.Point(207, 81);
			txbPathProfile.Name = "txbPathProfile";
			txbPathProfile.Size = new System.Drawing.Size(358, 23);
			txbPathProfile.TabIndex = 32;
			txbPathProfile.Click += new System.EventHandler(txbPathProfile_Click);
			txbPathProfile.TextChanged += new System.EventHandler(txbPathProfile_TextChanged);
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(plVitech);
			panel1.Controls.Add(grChrome);
			panel1.Controls.Add(cbbHostpot);
			panel1.Controls.Add(rbVitech);
			panel1.Controls.Add(bunifuCards2);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(panel2);
			panel1.Controls.Add(btnSave);
			panel1.Controls.Add(plNordVPN);
			panel1.Controls.Add(groupBox1);
			panel1.Controls.Add(groupBox2);
			panel1.Controls.Add(btnSSH);
			panel1.Controls.Add(radioButton4);
			panel1.Controls.Add(rbHotspot);
			panel1.Controls.Add(radioButton5);
			panel1.Controls.Add(rbNordVPN);
			panel1.Controls.Add(radioButton2);
			panel1.Controls.Add(rbSSH);
			panel1.Controls.Add(radioButton3);
			panel1.Controls.Add(rbExpressVPN);
			panel1.Controls.Add(groupBox3);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(1158, 544);
			panel1.TabIndex = 37;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			plVitech.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plVitech.Controls.Add(txtListProxyVitech);
			plVitech.Controls.Add(radioButton9);
			plVitech.Controls.Add(radioButton10);
			plVitech.Controls.Add(label40);
			plVitech.Controls.Add(label41);
			plVitech.Controls.Add(label42);
			plVitech.Controls.Add(nudLuongPerIPVitech);
			plVitech.Controls.Add(label46);
			plVitech.Controls.Add(txtApiVitech);
			plVitech.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plVitech.Location = new System.Drawing.Point(11, 736);
			plVitech.Name = "plVitech";
			plVitech.Size = new System.Drawing.Size(266, 170);
			plVitech.TabIndex = 151;
			plVitech.Visible = false;
			txtListProxyVitech.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtListProxyVitech.Location = new System.Drawing.Point(6, 71);
			txtListProxyVitech.Name = "txtListProxyVitech";
			txtListProxyVitech.Size = new System.Drawing.Size(255, 68);
			txtListProxyVitech.TabIndex = 144;
			txtListProxyVitech.Text = "";
			txtListProxyVitech.WordWrap = false;
			txtListProxyVitech.TextChanged += new System.EventHandler(richTextBox1_TextChanged);
			radioButton9.AutoSize = true;
			radioButton9.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton9.Enabled = false;
			radioButton9.Location = new System.Drawing.Point(137, 28);
			radioButton9.Name = "radioButton9";
			radioButton9.Size = new System.Drawing.Size(60, 20);
			radioButton9.TabIndex = 82;
			radioButton9.Text = "Sock5";
			radioButton9.UseVisualStyleBackColor = true;
			radioButton10.AutoSize = true;
			radioButton10.Checked = true;
			radioButton10.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton10.Location = new System.Drawing.Point(74, 28);
			radioButton10.Name = "radioButton10";
			radioButton10.Size = new System.Drawing.Size(49, 20);
			radioButton10.TabIndex = 82;
			radioButton10.TabStop = true;
			radioButton10.Text = "Http";
			radioButton10.UseVisualStyleBackColor = true;
			label40.AutoSize = true;
			label40.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label40.Location = new System.Drawing.Point(3, 28);
			label40.Name = "label40";
			label40.Size = new System.Drawing.Size(71, 16);
			label40.TabIndex = 79;
			label40.Text = "Loại Proxy:";
			label41.AutoSize = true;
			label41.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label41.Location = new System.Drawing.Point(3, 50);
			label41.Name = "label41";
			label41.Size = new System.Drawing.Size(98, 16);
			label41.TabIndex = 79;
			label41.Text = "Nhập Proxy (0):";
			label42.AutoSize = true;
			label42.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label42.Location = new System.Drawing.Point(5, 143);
			label42.Name = "label42";
			label42.Size = new System.Drawing.Size(79, 16);
			label42.TabIndex = 139;
			label42.Text = "Số luồng/IP:";
			nudLuongPerIPVitech.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPVitech.Location = new System.Drawing.Point(90, 142);
			nudLuongPerIPVitech.Name = "nudLuongPerIPVitech";
			nudLuongPerIPVitech.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPVitech.TabIndex = 140;
			nudLuongPerIPVitech.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label46.AutoSize = true;
			label46.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label46.Location = new System.Drawing.Point(3, 5);
			label46.Name = "label46";
			label46.Size = new System.Drawing.Size(56, 16);
			label46.TabIndex = 79;
			label46.Text = "API Key:";
			txtApiVitech.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtApiVitech.ForeColor = System.Drawing.Color.Black;
			txtApiVitech.Location = new System.Drawing.Point(74, 2);
			txtApiVitech.Name = "txtApiVitech";
			txtApiVitech.Size = new System.Drawing.Size(187, 23);
			txtApiVitech.TabIndex = 81;
			grChrome.Controls.Add(panel3);
			grChrome.Controls.Add(plSizeChrome);
			grChrome.Controls.Add(plSapXepCuaSoChrome);
			grChrome.Controls.Add(plAddChromeVaoFormView);
			grChrome.Controls.Add(AddFileAccount);
			grChrome.Controls.Add(btnDown);
			grChrome.Controls.Add(btnUp);
			grChrome.Controls.Add(nudDelayCloseChromeFrom);
			grChrome.Controls.Add(nudDelayCloseChromeTo);
			grChrome.Controls.Add(nudDelayOpenChromeFrom);
			grChrome.Controls.Add(nudDelayOpenChromeTo);
			grChrome.Controls.Add(plLinkToOtherBrowser);
			grChrome.Controls.Add(rbChromium);
			grChrome.Controls.Add(rbChrome);
			grChrome.Controls.Add(label22);
			grChrome.Controls.Add(label15);
			grChrome.Controls.Add(ckbShowImageInteract);
			grChrome.Controls.Add(ckbAddChromeIntoForm);
			grChrome.Controls.Add(label32);
			grChrome.Controls.Add(cbbSizeChrome);
			grChrome.Controls.Add(label31);
			grChrome.Controls.Add(label29);
			grChrome.Controls.Add(label2);
			grChrome.Controls.Add(label21);
			grChrome.Controls.Add(label20);
			grChrome.Controls.Add(label34);
			grChrome.Controls.Add(button6);
			grChrome.Controls.Add(plUsePortable);
			grChrome.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			grChrome.Location = new System.Drawing.Point(7, 156);
			grChrome.Name = "grChrome";
			grChrome.Size = new System.Drawing.Size(568, 233);
			grChrome.TabIndex = 38;
			grChrome.TabStop = false;
			grChrome.Text = "Cấu hình chrome";
			panel3.Controls.Add(button1);
			panel3.Controls.Add(linkLabel2);
			panel3.Location = new System.Drawing.Point(32, 200);
			panel3.Name = "panel3";
			panel3.Size = new System.Drawing.Size(530, 25);
			panel3.TabIndex = 156;
			panel3.Click += new System.EventHandler(panel3_Click);
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Location = new System.Drawing.Point(0, -1);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(134, 27);
			button1.TabIndex = 143;
			button1.Text = "Check Chromedriver";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			linkLabel2.AutoSize = true;
			linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
			linkLabel2.Location = new System.Drawing.Point(191, 4);
			linkLabel2.Name = "linkLabel2";
			linkLabel2.Size = new System.Drawing.Size(222, 16);
			linkLabel2.TabIndex = 147;
			linkLabel2.TabStop = true;
			linkLabel2.Text = "Hươ\u0301ng dâ\u0303n câ\u0323p nhâ\u0323t ChromeDriver(?)";
			linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel2_LinkClicked);
			plSizeChrome.Controls.Add(rbTocDoGoNhanh);
			plSizeChrome.Controls.Add(rbTocDoGoBinhThuong);
			plSizeChrome.Controls.Add(rbTocDoGoCham);
			plSizeChrome.Controls.Add(label30);
			plSizeChrome.Location = new System.Drawing.Point(32, 169);
			plSizeChrome.Name = "plSizeChrome";
			plSizeChrome.Size = new System.Drawing.Size(463, 25);
			plSizeChrome.TabIndex = 155;
			rbTocDoGoNhanh.AutoSize = true;
			rbTocDoGoNhanh.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTocDoGoNhanh.Location = new System.Drawing.Point(378, 2);
			rbTocDoGoNhanh.Name = "rbTocDoGoNhanh";
			rbTocDoGoNhanh.Size = new System.Drawing.Size(62, 20);
			rbTocDoGoNhanh.TabIndex = 34;
			rbTocDoGoNhanh.Text = "Nhanh";
			rbTocDoGoNhanh.UseVisualStyleBackColor = true;
			rbTocDoGoBinhThuong.AutoSize = true;
			rbTocDoGoBinhThuong.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTocDoGoBinhThuong.Location = new System.Drawing.Point(268, 2);
			rbTocDoGoBinhThuong.Name = "rbTocDoGoBinhThuong";
			rbTocDoGoBinhThuong.Size = new System.Drawing.Size(94, 20);
			rbTocDoGoBinhThuong.TabIndex = 34;
			rbTocDoGoBinhThuong.Text = "Bình thường";
			rbTocDoGoBinhThuong.UseVisualStyleBackColor = true;
			rbTocDoGoCham.AutoSize = true;
			rbTocDoGoCham.Checked = true;
			rbTocDoGoCham.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTocDoGoCham.Location = new System.Drawing.Point(193, 2);
			rbTocDoGoCham.Name = "rbTocDoGoCham";
			rbTocDoGoCham.Size = new System.Drawing.Size(59, 20);
			rbTocDoGoCham.TabIndex = 34;
			rbTocDoGoCham.TabStop = true;
			rbTocDoGoCham.Text = "Chậm";
			rbTocDoGoCham.UseVisualStyleBackColor = true;
			label30.AutoSize = true;
			label30.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label30.Location = new System.Drawing.Point(-3, 4);
			label30.Name = "label30";
			label30.Size = new System.Drawing.Size(174, 16);
			label30.TabIndex = 33;
			label30.Text = "Tùy chỉnh tốc độ gõ văn bản:";
			plSapXepCuaSoChrome.Controls.Add(label10);
			plSapXepCuaSoChrome.Controls.Add(label11);
			plSapXepCuaSoChrome.Controls.Add(cbbColumnChrome);
			plSapXepCuaSoChrome.Controls.Add(cbbRowChrome);
			plSapXepCuaSoChrome.Location = new System.Drawing.Point(26, 77);
			plSapXepCuaSoChrome.Name = "plSapXepCuaSoChrome";
			plSapXepCuaSoChrome.Size = new System.Drawing.Size(358, 29);
			plSapXepCuaSoChrome.TabIndex = 157;
			label10.AutoSize = true;
			label10.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label10.Location = new System.Drawing.Point(3, 5);
			label10.Name = "label10";
			label10.Size = new System.Drawing.Size(148, 16);
			label10.TabIndex = 33;
			label10.Text = "Sắp xếp cửa sổ chrome:";
			label11.AutoSize = true;
			label11.Font = new System.Drawing.Font("Tahoma", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label11.Location = new System.Drawing.Point(245, 2);
			label11.Name = "label11";
			label11.Size = new System.Drawing.Size(23, 23);
			label11.TabIndex = 33;
			label11.Text = "X";
			cbbColumnChrome.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbColumnChrome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbColumnChrome.FormattingEnabled = true;
			cbbColumnChrome.Items.AddRange(new object[10] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
			cbbColumnChrome.Location = new System.Drawing.Point(200, 2);
			cbbColumnChrome.Name = "cbbColumnChrome";
			cbbColumnChrome.Size = new System.Drawing.Size(41, 24);
			cbbColumnChrome.TabIndex = 145;
			cbbRowChrome.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbRowChrome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbRowChrome.FormattingEnabled = true;
			cbbRowChrome.Items.AddRange(new object[5] { "1", "2", "3", "4", "5" });
			cbbRowChrome.Location = new System.Drawing.Point(272, 2);
			cbbRowChrome.Name = "cbbRowChrome";
			cbbRowChrome.Size = new System.Drawing.Size(41, 24);
			cbbRowChrome.TabIndex = 145;
			plAddChromeVaoFormView.Controls.Add(nudWidthChrome);
			plAddChromeVaoFormView.Controls.Add(label35);
			plAddChromeVaoFormView.Controls.Add(label33);
			plAddChromeVaoFormView.Controls.Add(nudHeighChrome);
			plAddChromeVaoFormView.Location = new System.Drawing.Point(219, 48);
			plAddChromeVaoFormView.Name = "plAddChromeVaoFormView";
			plAddChromeVaoFormView.Size = new System.Drawing.Size(175, 27);
			plAddChromeVaoFormView.TabIndex = 156;
			nudWidthChrome.Location = new System.Drawing.Point(41, 2);
			nudWidthChrome.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudWidthChrome.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudWidthChrome.Name = "nudWidthChrome";
			nudWidthChrome.Size = new System.Drawing.Size(53, 23);
			nudWidthChrome.TabIndex = 151;
			nudWidthChrome.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label35.AutoSize = true;
			label35.Font = new System.Drawing.Font("Tahoma", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label35.Location = new System.Drawing.Point(95, 2);
			label35.Name = "label35";
			label35.Size = new System.Drawing.Size(23, 23);
			label35.TabIndex = 33;
			label35.Text = "X";
			label33.AutoSize = true;
			label33.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label33.Location = new System.Drawing.Point(3, 4);
			label33.Name = "label33";
			label33.Size = new System.Drawing.Size(37, 16);
			label33.TabIndex = 33;
			label33.Text = "Size:";
			nudHeighChrome.Location = new System.Drawing.Point(118, 2);
			nudHeighChrome.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudHeighChrome.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudHeighChrome.Name = "nudHeighChrome";
			nudHeighChrome.Size = new System.Drawing.Size(53, 23);
			nudHeighChrome.TabIndex = 151;
			nudHeighChrome.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			AddFileAccount.BackgroundImage = maxcare.Properties.Resources.icons8_plus_math_25px;
			AddFileAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			AddFileAccount.Cursor = System.Windows.Forms.Cursors.Hand;
			AddFileAccount.Location = new System.Drawing.Point(415, 169);
			AddFileAccount.Name = "AddFileAccount";
			AddFileAccount.Size = new System.Drawing.Size(25, 25);
			AddFileAccount.TabIndex = 154;
			AddFileAccount.UseSelectable = true;
			AddFileAccount.Click += new System.EventHandler(AddFileAccount_Click);
			btnDown.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			btnDown.BackgroundImage = maxcare.Properties.Resources.icons8_expand_arrow_24px;
			btnDown.Cursor = System.Windows.Forms.Cursors.Hand;
			btnDown.Location = new System.Drawing.Point(512, 8);
			btnDown.Name = "btnDown";
			btnDown.Size = new System.Drawing.Size(25, 25);
			btnDown.TabIndex = 152;
			btnDown.UseSelectable = true;
			btnDown.Visible = false;
			btnDown.Click += new System.EventHandler(btnDown_Click);
			btnUp.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			btnUp.BackgroundImage = maxcare.Properties.Resources.icons8_collapse_arrow_24px;
			btnUp.Cursor = System.Windows.Forms.Cursors.Hand;
			btnUp.Location = new System.Drawing.Point(543, 8);
			btnUp.Name = "btnUp";
			btnUp.Size = new System.Drawing.Size(25, 25);
			btnUp.TabIndex = 153;
			btnUp.UseSelectable = true;
			btnUp.Visible = false;
			btnUp.Click += new System.EventHandler(btnUp_Click);
			nudDelayCloseChromeFrom.Location = new System.Drawing.Point(226, 140);
			nudDelayCloseChromeFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayCloseChromeFrom.Name = "nudDelayCloseChromeFrom";
			nudDelayCloseChromeFrom.Size = new System.Drawing.Size(41, 23);
			nudDelayCloseChromeFrom.TabIndex = 151;
			nudDelayCloseChromeTo.Location = new System.Drawing.Point(298, 140);
			nudDelayCloseChromeTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayCloseChromeTo.Name = "nudDelayCloseChromeTo";
			nudDelayCloseChromeTo.Size = new System.Drawing.Size(41, 23);
			nudDelayCloseChromeTo.TabIndex = 151;
			nudDelayOpenChromeFrom.Location = new System.Drawing.Point(226, 111);
			nudDelayOpenChromeFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayOpenChromeFrom.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudDelayOpenChromeFrom.Name = "nudDelayOpenChromeFrom";
			nudDelayOpenChromeFrom.Size = new System.Drawing.Size(41, 23);
			nudDelayOpenChromeFrom.TabIndex = 151;
			nudDelayOpenChromeFrom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudDelayOpenChromeTo.Location = new System.Drawing.Point(298, 111);
			nudDelayOpenChromeTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayOpenChromeTo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudDelayOpenChromeTo.Name = "nudDelayOpenChromeTo";
			nudDelayOpenChromeTo.Size = new System.Drawing.Size(41, 23);
			nudDelayOpenChromeTo.TabIndex = 151;
			nudDelayOpenChromeTo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			plLinkToOtherBrowser.Controls.Add(label19);
			plLinkToOtherBrowser.Controls.Add(txtLinkToOtherBrowser);
			plLinkToOtherBrowser.Location = new System.Drawing.Point(186, 287);
			plLinkToOtherBrowser.Name = "plLinkToOtherBrowser";
			plLinkToOtherBrowser.Size = new System.Drawing.Size(348, 26);
			plLinkToOtherBrowser.TabIndex = 150;
			label19.AutoSize = true;
			label19.Location = new System.Drawing.Point(3, 4);
			label19.Name = "label19";
			label19.Size = new System.Drawing.Size(76, 16);
			label19.TabIndex = 148;
			label19.Text = "Đươ\u0300ng dâ\u0303n:";
			txtLinkToOtherBrowser.Location = new System.Drawing.Point(83, 1);
			txtLinkToOtherBrowser.Name = "txtLinkToOtherBrowser";
			txtLinkToOtherBrowser.Size = new System.Drawing.Size(256, 23);
			txtLinkToOtherBrowser.TabIndex = 149;
			rbChromium.AutoSize = true;
			rbChromium.Cursor = System.Windows.Forms.Cursors.Hand;
			rbChromium.Location = new System.Drawing.Point(268, 265);
			rbChromium.Name = "rbChromium";
			rbChromium.Size = new System.Drawing.Size(266, 20);
			rbChromium.TabIndex = 147;
			rbChromium.Text = "Kha\u0301c (Chromium, Brave, Cốc cốc, Slimjet)";
			rbChromium.UseVisualStyleBackColor = true;
			rbChromium.CheckedChanged += new System.EventHandler(rbChrome_CheckedChanged);
			rbChrome.AutoSize = true;
			rbChrome.Checked = true;
			rbChrome.Cursor = System.Windows.Forms.Cursors.Hand;
			rbChrome.Location = new System.Drawing.Point(191, 265);
			rbChrome.Name = "rbChrome";
			rbChrome.Size = new System.Drawing.Size(71, 20);
			rbChrome.TabIndex = 147;
			rbChrome.TabStop = true;
			rbChrome.Text = "Chrome";
			rbChrome.UseVisualStyleBackColor = true;
			rbChrome.CheckedChanged += new System.EventHandler(rbChrome_CheckedChanged);
			label22.AutoSize = true;
			label22.Location = new System.Drawing.Point(29, 238);
			label22.Name = "label22";
			label22.Size = new System.Drawing.Size(135, 16);
			label22.TabIndex = 146;
			label22.Text = "Nhập Extension (.crx):";
			label15.AutoSize = true;
			label15.Location = new System.Drawing.Point(29, 269);
			label15.Name = "label15";
			label15.Size = new System.Drawing.Size(107, 16);
			label15.TabIndex = 146;
			label15.Text = "Cho\u0323n tri\u0300nh duyê\u0323t:";
			ckbShowImageInteract.AutoSize = true;
			ckbShowImageInteract.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbShowImageInteract.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbShowImageInteract.Location = new System.Drawing.Point(32, 22);
			ckbShowImageInteract.Name = "ckbShowImageInteract";
			ckbShowImageInteract.Size = new System.Drawing.Size(184, 20);
			ckbShowImageInteract.TabIndex = 112;
			ckbShowImageInteract.Text = "Hiê\u0323n a\u0309nh khi mơ\u0309 tri\u0300nh duyê\u0323t";
			ckbShowImageInteract.UseVisualStyleBackColor = true;
			ckbAddChromeIntoForm.AutoSize = true;
			ckbAddChromeIntoForm.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAddChromeIntoForm.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAddChromeIntoForm.Location = new System.Drawing.Point(32, 50);
			ckbAddChromeIntoForm.Name = "ckbAddChromeIntoForm";
			ckbAddChromeIntoForm.Size = new System.Drawing.Size(188, 20);
			ckbAddChromeIntoForm.TabIndex = 112;
			ckbAddChromeIntoForm.Text = "Add Chrome vào Form View";
			ckbAddChromeIntoForm.UseVisualStyleBackColor = true;
			ckbAddChromeIntoForm.CheckedChanged += new System.EventHandler(ckbAddChromeIntoForm_CheckedChanged);
			label32.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label32.Location = new System.Drawing.Point(269, 142);
			label32.Name = "label32";
			label32.Size = new System.Drawing.Size(29, 16);
			label32.TabIndex = 33;
			label32.Text = "đê\u0301n";
			label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			cbbSizeChrome.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbSizeChrome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbSizeChrome.DropDownWidth = 200;
			cbbSizeChrome.FormattingEnabled = true;
			cbbSizeChrome.Location = new System.Drawing.Point(226, 169);
			cbbSizeChrome.Name = "cbbSizeChrome";
			cbbSizeChrome.Size = new System.Drawing.Size(183, 24);
			cbbSizeChrome.TabIndex = 145;
			label31.AutoSize = true;
			label31.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label31.Location = new System.Drawing.Point(341, 142);
			label31.Name = "label31";
			label31.Size = new System.Drawing.Size(31, 16);
			label31.TabIndex = 33;
			label31.Text = "giây";
			label29.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label29.Location = new System.Drawing.Point(269, 113);
			label29.Name = "label29";
			label29.Size = new System.Drawing.Size(29, 16);
			label29.TabIndex = 33;
			label29.Text = "đê\u0301n";
			label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(29, 142);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(123, 16);
			label2.TabIndex = 33;
			label2.Text = "Delay đóng chrome:";
			label21.AutoSize = true;
			label21.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label21.Location = new System.Drawing.Point(341, 113);
			label21.Name = "label21";
			label21.Size = new System.Drawing.Size(31, 16);
			label21.TabIndex = 33;
			label21.Text = "giây";
			label20.AutoSize = true;
			label20.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label20.Location = new System.Drawing.Point(29, 113);
			label20.Name = "label20";
			label20.Size = new System.Drawing.Size(113, 16);
			label20.TabIndex = 33;
			label20.Text = "Delay mơ\u0309 chrome:";
			label34.AutoSize = true;
			label34.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label34.Location = new System.Drawing.Point(31, 167);
			label34.Name = "label34";
			label34.Size = new System.Drawing.Size(161, 16);
			label34.TabIndex = 33;
			label34.Text = "Kích thước cửa số chrome:";
			button6.Cursor = System.Windows.Forms.Cursors.Hand;
			button6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button6.ForeColor = System.Drawing.Color.Black;
			button6.Location = new System.Drawing.Point(190, 233);
			button6.Name = "button6";
			button6.Size = new System.Drawing.Size(63, 27);
			button6.TabIndex = 143;
			button6.Text = "Nhập";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			plUsePortable.Controls.Add(txtPathToPortableZip);
			plUsePortable.Controls.Add(lblFileZip);
			plUsePortable.Controls.Add(ckbUsePortable);
			plUsePortable.Location = new System.Drawing.Point(32, 200);
			plUsePortable.Name = "plUsePortable";
			plUsePortable.Size = new System.Drawing.Size(530, 25);
			plUsePortable.TabIndex = 155;
			plUsePortable.Paint += new System.Windows.Forms.PaintEventHandler(panel3_Paint);
			txtPathToPortableZip.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			txtPathToPortableZip.Location = new System.Drawing.Point(194, 1);
			txtPathToPortableZip.Name = "txtPathToPortableZip";
			txtPathToPortableZip.Size = new System.Drawing.Size(333, 23);
			txtPathToPortableZip.TabIndex = 32;
			txtPathToPortableZip.Click += new System.EventHandler(txbPathProfile_Click);
			lblFileZip.AutoSize = true;
			lblFileZip.Location = new System.Drawing.Point(139, 4);
			lblFileZip.Name = "lblFileZip";
			lblFileZip.Size = new System.Drawing.Size(53, 16);
			lblFileZip.TabIndex = 113;
			lblFileZip.Text = "File zip:";
			ckbUsePortable.AutoSize = true;
			ckbUsePortable.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbUsePortable.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbUsePortable.Location = new System.Drawing.Point(0, 3);
			ckbUsePortable.Name = "ckbUsePortable";
			ckbUsePortable.Size = new System.Drawing.Size(126, 20);
			ckbUsePortable.TabIndex = 112;
			ckbUsePortable.Text = "Sử dụng Portable";
			ckbUsePortable.UseVisualStyleBackColor = true;
			ckbUsePortable.CheckedChanged += new System.EventHandler(ckbUsePortable_CheckedChanged);
			cbbHostpot.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbHostpot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbHostpot.Enabled = false;
			cbbHostpot.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			cbbHostpot.ForeColor = System.Drawing.Color.Black;
			cbbHostpot.FormattingEnabled = true;
			cbbHostpot.Items.AddRange(new object[2] { "Chi\u0309 trong quô\u0301c gia đang cho\u0323n", "Toa\u0300n bô\u0323 quô\u0301c gia" });
			cbbHostpot.Location = new System.Drawing.Point(1177, 563);
			cbbHostpot.Name = "cbbHostpot";
			cbbHostpot.Size = new System.Drawing.Size(229, 24);
			cbbHostpot.TabIndex = 144;
			rbVitech.AutoSize = true;
			rbVitech.Cursor = System.Windows.Forms.Cursors.Hand;
			rbVitech.Enabled = false;
			rbVitech.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbVitech.Location = new System.Drawing.Point(11, 712);
			rbVitech.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbVitech.Name = "rbVitech";
			rbVitech.Size = new System.Drawing.Size(146, 20);
			rbVitech.TabIndex = 150;
			rbVitech.Text = "VitechCheap(Sắp có)";
			rbVitech.UseVisualStyleBackColor = true;
			rbVitech.Visible = false;
			rbVitech.CheckedChanged += new System.EventHandler(rbVitech_CheckedChanged);
			bunifuCards2.BackColor = System.Drawing.Color.White;
			bunifuCards2.BorderRadius = 0;
			bunifuCards2.BottomSahddow = true;
			bunifuCards2.color = System.Drawing.Color.SaddleBrown;
			bunifuCards2.Controls.Add(pnlHeader);
			bunifuCards2.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards2.LeftSahddow = false;
			bunifuCards2.Location = new System.Drawing.Point(0, 0);
			bunifuCards2.Name = "bunifuCards2";
			bunifuCards2.RightSahddow = true;
			bunifuCards2.ShadowDepth = 20;
			bunifuCards2.Size = new System.Drawing.Size(1156, 37);
			bunifuCards2.TabIndex = 40;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button2);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(1156, 31);
			pnlHeader.TabIndex = 9;
			button2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.FlatAppearance.BorderSize = 0;
			button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button2.ForeColor = System.Drawing.Color.White;
			button2.Image = (System.Drawing.Image)resources.GetObject("button2.Image");
			button2.Location = new System.Drawing.Point(1125, 1);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(30, 30);
			button2.TabIndex = 77;
			button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(BtnCancel_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(1156, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Câ\u0301u hi\u0300nh chung";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(583, 502);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 20;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(BtnCancel_Click);
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel2.Controls.Add(label12);
			panel2.Controls.Add(textBox1);
			panel2.Enabled = false;
			panel2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			panel2.Location = new System.Drawing.Point(1176, 475);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(232, 30);
			panel2.TabIndex = 142;
			label12.AutoSize = true;
			label12.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label12.Location = new System.Drawing.Point(3, 5);
			label12.Name = "label12";
			label12.Size = new System.Drawing.Size(76, 16);
			label12.TabIndex = 82;
			label12.Text = "Đường dẫn:";
			textBox1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			textBox1.ForeColor = System.Drawing.Color.Black;
			textBox1.Location = new System.Drawing.Point(87, 2);
			textBox1.Name = "textBox1";
			textBox1.Size = new System.Drawing.Size(142, 23);
			textBox1.TabIndex = 83;
			btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnSave.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
			btnSave.FlatAppearance.BorderSize = 0;
			btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnSave.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnSave.ForeColor = System.Drawing.Color.White;
			btnSave.Location = new System.Drawing.Point(483, 502);
			btnSave.Name = "btnSave";
			btnSave.Size = new System.Drawing.Size(92, 29);
			btnSave.TabIndex = 19;
			btnSave.Text = "Lưu";
			btnSave.UseVisualStyleBackColor = false;
			btnSave.Click += new System.EventHandler(BtnSave_Click);
			plNordVPN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plNordVPN.Controls.Add(label14);
			plNordVPN.Controls.Add(txtNordVPN);
			plNordVPN.Enabled = false;
			plNordVPN.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plNordVPN.Location = new System.Drawing.Point(1176, 475);
			plNordVPN.Name = "plNordVPN";
			plNordVPN.Size = new System.Drawing.Size(232, 30);
			plNordVPN.TabIndex = 142;
			label14.AutoSize = true;
			label14.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label14.Location = new System.Drawing.Point(3, 5);
			label14.Name = "label14";
			label14.Size = new System.Drawing.Size(76, 16);
			label14.TabIndex = 82;
			label14.Text = "Đường dẫn:";
			txtNordVPN.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtNordVPN.ForeColor = System.Drawing.Color.Black;
			txtNordVPN.Location = new System.Drawing.Point(87, 2);
			txtNordVPN.Name = "txtNordVPN";
			txtNordVPN.Size = new System.Drawing.Size(142, 23);
			txtNordVPN.TabIndex = 83;
			groupBox1.Controls.Add(panel6);
			groupBox1.Controls.Add(panel4);
			groupBox1.Controls.Add(label23);
			groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			groupBox1.Location = new System.Drawing.Point(7, 395);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(568, 55);
			groupBox1.TabIndex = 38;
			groupBox1.TabStop = false;
			groupBox1.Text = "Cấu hình khác";
			panel4.Controls.Add(rbPhanBietMauNen);
			panel4.Controls.Add(rbPhanBietMauChu);
			panel4.Location = new System.Drawing.Point(253, 20);
			panel4.Name = "panel4";
			panel4.Size = new System.Drawing.Size(309, 24);
			panel4.TabIndex = 156;
			rbPhanBietMauNen.AutoSize = true;
			rbPhanBietMauNen.Checked = true;
			rbPhanBietMauNen.Cursor = System.Windows.Forms.Cursors.Hand;
			rbPhanBietMauNen.Location = new System.Drawing.Point(3, 3);
			rbPhanBietMauNen.Name = "rbPhanBietMauNen";
			rbPhanBietMauNen.Size = new System.Drawing.Size(131, 20);
			rbPhanBietMauNen.TabIndex = 34;
			rbPhanBietMauNen.TabStop = true;
			rbPhanBietMauNen.Text = "Đổi màu nền dòng";
			rbPhanBietMauNen.UseVisualStyleBackColor = true;
			rbPhanBietMauChu.AutoSize = true;
			rbPhanBietMauChu.Cursor = System.Windows.Forms.Cursors.Hand;
			rbPhanBietMauChu.Location = new System.Drawing.Point(176, 2);
			rbPhanBietMauChu.Name = "rbPhanBietMauChu";
			rbPhanBietMauChu.Size = new System.Drawing.Size(99, 20);
			rbPhanBietMauChu.TabIndex = 34;
			rbPhanBietMauChu.Text = "Đổi màu chữ";
			rbPhanBietMauChu.UseVisualStyleBackColor = true;
			label23.AutoSize = true;
			label23.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label23.Location = new System.Drawing.Point(29, 24);
			label23.Name = "label23";
			label23.Size = new System.Drawing.Size(224, 16);
			label23.TabIndex = 33;
			label23.Text = "Phân biệt màu [Tình trạng tài khoản]:";
			groupBox2.Controls.Add(label5);
			groupBox2.Controls.Add(nudHideThread);
			groupBox2.Controls.Add(label6);
			groupBox2.Controls.Add(label9);
			groupBox2.Controls.Add(txbPathProfile);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(nudInteractThread);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(button9);
			groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			groupBox2.Location = new System.Drawing.Point(7, 39);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(568, 111);
			groupBox2.TabIndex = 38;
			groupBox2.TabStop = false;
			groupBox2.Text = "Cấu hình chung";
			button9.Cursor = System.Windows.Forms.Cursors.Hand;
			button9.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button9.ForeColor = System.Drawing.Color.Black;
			button9.Location = new System.Drawing.Point(508, 80);
			button9.Name = "button9";
			button9.Size = new System.Drawing.Size(54, 25);
			button9.TabIndex = 143;
			button9.Text = "Cho\u0323n";
			button9.UseVisualStyleBackColor = true;
			button9.Click += new System.EventHandler(button9_Click);
			btnSSH.Cursor = System.Windows.Forms.Cursors.Hand;
			btnSSH.Enabled = false;
			btnSSH.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			btnSSH.ForeColor = System.Drawing.Color.Black;
			btnSSH.Location = new System.Drawing.Point(1263, 508);
			btnSSH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			btnSSH.Name = "btnSSH";
			btnSSH.Size = new System.Drawing.Size(106, 26);
			btnSSH.TabIndex = 130;
			btnSSH.Text = "Nhập IP SSH";
			btnSSH.UseVisualStyleBackColor = true;
			btnSSH.Click += new System.EventHandler(btnSSH_Click);
			radioButton4.AutoSize = true;
			radioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton4.Enabled = false;
			radioButton4.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			radioButton4.Location = new System.Drawing.Point(1162, 426);
			radioButton4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			radioButton4.Name = "radioButton4";
			radioButton4.Size = new System.Drawing.Size(131, 20);
			radioButton4.TabIndex = 133;
			radioButton4.Text = "Đổi IP ExpressVPN";
			radioButton4.UseVisualStyleBackColor = true;
			rbHotspot.AutoSize = true;
			rbHotspot.Enabled = false;
			rbHotspot.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbHotspot.Location = new System.Drawing.Point(1162, 539);
			rbHotspot.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbHotspot.Name = "rbHotspot";
			rbHotspot.Size = new System.Drawing.Size(146, 20);
			rbHotspot.TabIndex = 135;
			rbHotspot.Text = "Đổi IP Hotspot Shield";
			rbHotspot.UseVisualStyleBackColor = true;
			radioButton5.AutoSize = true;
			radioButton5.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton5.Enabled = false;
			radioButton5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			radioButton5.Location = new System.Drawing.Point(1162, 511);
			radioButton5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			radioButton5.Name = "radioButton5";
			radioButton5.Size = new System.Drawing.Size(88, 20);
			radioButton5.TabIndex = 132;
			radioButton5.Text = "Đổi IP SSH";
			radioButton5.UseVisualStyleBackColor = true;
			rbNordVPN.AutoSize = true;
			rbNordVPN.Enabled = false;
			rbNordVPN.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbNordVPN.Location = new System.Drawing.Point(1162, 451);
			rbNordVPN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbNordVPN.Name = "rbNordVPN";
			rbNordVPN.Size = new System.Drawing.Size(114, 20);
			rbNordVPN.TabIndex = 134;
			rbNordVPN.Text = "Đổi IP NordVPN";
			rbNordVPN.UseVisualStyleBackColor = true;
			rbNordVPN.CheckedChanged += new System.EventHandler(rbNordVPN_CheckedChanged);
			radioButton2.AutoSize = true;
			radioButton2.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton2.Enabled = false;
			radioButton2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			radioButton2.Location = new System.Drawing.Point(1162, 539);
			radioButton2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			radioButton2.Name = "radioButton2";
			radioButton2.Size = new System.Drawing.Size(146, 20);
			radioButton2.TabIndex = 135;
			radioButton2.Text = "Đổi IP Hotspot Shield";
			radioButton2.UseVisualStyleBackColor = true;
			rbSSH.AutoSize = true;
			rbSSH.Enabled = false;
			rbSSH.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbSSH.Location = new System.Drawing.Point(1162, 511);
			rbSSH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbSSH.Name = "rbSSH";
			rbSSH.Size = new System.Drawing.Size(88, 20);
			rbSSH.TabIndex = 132;
			rbSSH.Text = "Đổi IP SSH";
			rbSSH.UseVisualStyleBackColor = true;
			radioButton3.AutoSize = true;
			radioButton3.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton3.Enabled = false;
			radioButton3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			radioButton3.Location = new System.Drawing.Point(1162, 451);
			radioButton3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			radioButton3.Name = "radioButton3";
			radioButton3.Size = new System.Drawing.Size(114, 20);
			radioButton3.TabIndex = 134;
			radioButton3.Text = "Đổi IP NordVPN";
			radioButton3.UseVisualStyleBackColor = true;
			radioButton3.CheckedChanged += new System.EventHandler(rbNordVPN_CheckedChanged);
			rbExpressVPN.AutoSize = true;
			rbExpressVPN.Enabled = false;
			rbExpressVPN.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbExpressVPN.Location = new System.Drawing.Point(1162, 426);
			rbExpressVPN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbExpressVPN.Name = "rbExpressVPN";
			rbExpressVPN.Size = new System.Drawing.Size(131, 20);
			rbExpressVPN.TabIndex = 133;
			rbExpressVPN.Text = "Đổi IP ExpressVPN";
			rbExpressVPN.UseVisualStyleBackColor = true;
			groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			groupBox3.Controls.Add(metroButton2);
			groupBox3.Controls.Add(metroButton3);
			groupBox3.Controls.Add(panel5);
			groupBox3.Controls.Add(plShopLike);
			groupBox3.Controls.Add(rbMinProxy);
			groupBox3.Controls.Add(plXproxy);
			groupBox3.Controls.Add(rbShopLike);
			groupBox3.Controls.Add(plProxyv6);
			groupBox3.Controls.Add(rbProxyv6);
			groupBox3.Controls.Add(label37);
			groupBox3.Controls.Add(nudDelayCheckIP);
			groupBox3.Controls.Add(linkLabel3);
			groupBox3.Controls.Add(label38);
			groupBox3.Controls.Add(linkLabel1);
			groupBox3.Controls.Add(plTMProxy);
			groupBox3.Controls.Add(plCheckDoiIP);
			groupBox3.Controls.Add(plTinsoft);
			groupBox3.Controls.Add(rbTMProxy);
			groupBox3.Controls.Add(plDcom);
			groupBox3.Controls.Add(rbDcom);
			groupBox3.Controls.Add(rbTinsoft);
			groupBox3.Controls.Add(rbProxy);
			groupBox3.Controls.Add(rbNone);
			groupBox3.Controls.Add(rbXproxy);
			groupBox3.Controls.Add(rbHma);
			groupBox3.Controls.Add(ckbKhongCheckIP);
			groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			groupBox3.Location = new System.Drawing.Point(580, 38);
			groupBox3.Name = "groupBox3";
			groupBox3.Size = new System.Drawing.Size(568, 452);
			groupBox3.TabIndex = 39;
			groupBox3.TabStop = false;
			groupBox3.Text = "Cấu hình đổi IP";
			metroButton2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			metroButton2.BackgroundImage = maxcare.Properties.Resources.icons8_expand_arrow_24px;
			metroButton2.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton2.Location = new System.Drawing.Point(512, 8);
			metroButton2.Name = "metroButton2";
			metroButton2.Size = new System.Drawing.Size(25, 25);
			metroButton2.TabIndex = 154;
			metroButton2.UseSelectable = true;
			metroButton2.Click += new System.EventHandler(metroButton2_Click);
			metroButton3.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			metroButton3.BackgroundImage = maxcare.Properties.Resources.icons8_collapse_arrow_24px;
			metroButton3.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton3.Location = new System.Drawing.Point(543, 8);
			metroButton3.Name = "metroButton3";
			metroButton3.Size = new System.Drawing.Size(25, 25);
			metroButton3.TabIndex = 155;
			metroButton3.UseSelectable = true;
			metroButton3.Click += new System.EventHandler(metroButton3_Click);
			panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel5.Controls.Add(button10);
			panel5.Controls.Add(txtApiKeyMinProxy);
			panel5.Controls.Add(label49);
			panel5.Controls.Add(label50);
			panel5.Controls.Add(nudLuongPerIPMinProxy);
			panel5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			panel5.Location = new System.Drawing.Point(25, 266);
			panel5.Name = "panel5";
			panel5.Size = new System.Drawing.Size(264, 178);
			panel5.TabIndex = 153;
			button10.Cursor = System.Windows.Forms.Cursors.Hand;
			button10.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button10.ForeColor = System.Drawing.Color.Black;
			button10.Location = new System.Drawing.Point(159, 147);
			button10.Name = "button10";
			button10.Size = new System.Drawing.Size(52, 27);
			button10.TabIndex = 145;
			button10.Text = "Check";
			button10.UseVisualStyleBackColor = true;
			button10.Click += new System.EventHandler(button10_Click);
			txtApiKeyMinProxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtApiKeyMinProxy.Location = new System.Drawing.Point(6, 23);
			txtApiKeyMinProxy.Name = "txtApiKeyMinProxy";
			txtApiKeyMinProxy.Size = new System.Drawing.Size(253, 118);
			txtApiKeyMinProxy.TabIndex = 144;
			txtApiKeyMinProxy.Text = "";
			txtApiKeyMinProxy.WordWrap = false;
			txtApiKeyMinProxy.TextChanged += new System.EventHandler(txtApiKeyMinProxy_TextChanged);
			label49.AutoSize = true;
			label49.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label49.Location = new System.Drawing.Point(3, 2);
			label49.Name = "label49";
			label49.Size = new System.Drawing.Size(111, 16);
			label49.TabIndex = 79;
			label49.Text = "Nhập API KEY (0):";
			label50.AutoSize = true;
			label50.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label50.Location = new System.Drawing.Point(3, 150);
			label50.Name = "label50";
			label50.Size = new System.Drawing.Size(79, 16);
			label50.TabIndex = 139;
			label50.Text = "Số luồng/IP:";
			nudLuongPerIPMinProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPMinProxy.Location = new System.Drawing.Point(88, 149);
			nudLuongPerIPMinProxy.Name = "nudLuongPerIPMinProxy";
			nudLuongPerIPMinProxy.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPMinProxy.TabIndex = 140;
			nudLuongPerIPMinProxy.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			plShopLike.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plShopLike.Controls.Add(txtApiShopLike);
			plShopLike.Controls.Add(label47);
			plShopLike.Controls.Add(label48);
			plShopLike.Controls.Add(nudLuongPerIPShopLike);
			plShopLike.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plShopLike.Location = new System.Drawing.Point(22, 674);
			plShopLike.Name = "plShopLike";
			plShopLike.Size = new System.Drawing.Size(266, 154);
			plShopLike.TabIndex = 153;
			txtApiShopLike.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtApiShopLike.Location = new System.Drawing.Point(6, 21);
			txtApiShopLike.Name = "txtApiShopLike";
			txtApiShopLike.Size = new System.Drawing.Size(255, 93);
			txtApiShopLike.TabIndex = 144;
			txtApiShopLike.Text = "";
			txtApiShopLike.WordWrap = false;
			txtApiShopLike.TextChanged += new System.EventHandler(txtApiProxyShopLike_TextChanged);
			label47.AutoSize = true;
			label47.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label47.Location = new System.Drawing.Point(3, 2);
			label47.Name = "label47";
			label47.Size = new System.Drawing.Size(111, 16);
			label47.TabIndex = 79;
			label47.Text = "Nhập API KEY (0):";
			label48.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label48.AutoSize = true;
			label48.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label48.Location = new System.Drawing.Point(3, 127);
			label48.Name = "label48";
			label48.Size = new System.Drawing.Size(79, 16);
			label48.TabIndex = 139;
			label48.Text = "Số luồng/IP:";
			nudLuongPerIPShopLike.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			nudLuongPerIPShopLike.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPShopLike.Location = new System.Drawing.Point(88, 124);
			nudLuongPerIPShopLike.Name = "nudLuongPerIPShopLike";
			nudLuongPerIPShopLike.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPShopLike.TabIndex = 140;
			nudLuongPerIPShopLike.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			rbMinProxy.AutoSize = true;
			rbMinProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbMinProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbMinProxy.Location = new System.Drawing.Point(26, 243);
			rbMinProxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbMinProxy.Name = "rbMinProxy";
			rbMinProxy.Size = new System.Drawing.Size(94, 20);
			rbMinProxy.TabIndex = 152;
			rbMinProxy.Text = "MinProxy.vn";
			rbMinProxy.UseVisualStyleBackColor = true;
			rbMinProxy.CheckedChanged += new System.EventHandler(rbMinProxy_CheckedChanged);
			plXproxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plXproxy.Controls.Add(panel7);
			plXproxy.Controls.Add(ckbWaitDoneAllXproxy);
			plXproxy.Controls.Add(txtListProxy);
			plXproxy.Controls.Add(rbSock5Proxy);
			plXproxy.Controls.Add(rbHttpProxy);
			plXproxy.Controls.Add(label16);
			plXproxy.Controls.Add(metroButton1);
			plXproxy.Controls.Add(label17);
			plXproxy.Controls.Add(label52);
			plXproxy.Controls.Add(label51);
			plXproxy.Controls.Add(label18);
			plXproxy.Controls.Add(nudDelayResetXProxy);
			plXproxy.Controls.Add(nudLuongPerIPXProxy);
			plXproxy.Controls.Add(label13);
			plXproxy.Controls.Add(txtServiceURLXProxy);
			plXproxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plXproxy.Location = new System.Drawing.Point(322, 85);
			plXproxy.Name = "plXproxy";
			plXproxy.Size = new System.Drawing.Size(240, 171);
			plXproxy.TabIndex = 142;
			plXproxy.Click += new System.EventHandler(plXproxy_Click);
			label53.AutoSize = true;
			label53.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label53.Location = new System.Drawing.Point(1, 6);
			label53.Name = "label53";
			label53.Size = new System.Drawing.Size(83, 16);
			label53.TabIndex = 155;
			label53.Text = "Chế độ chạy:";
			rbXproxyResetAllProxy.AutoSize = true;
			rbXproxyResetAllProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbXproxyResetAllProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbXproxyResetAllProxy.Location = new System.Drawing.Point(90, 29);
			rbXproxyResetAllProxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbXproxyResetAllProxy.Name = "rbXproxyResetAllProxy";
			rbXproxyResetAllProxy.Size = new System.Drawing.Size(129, 20);
			rbXproxyResetAllProxy.TabIndex = 153;
			rbXproxyResetAllProxy.Text = "Reset tất cả proxy";
			rbXproxyResetAllProxy.UseVisualStyleBackColor = true;
			rbXproxyResetEachProxy.AutoSize = true;
			rbXproxyResetEachProxy.Checked = true;
			rbXproxyResetEachProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbXproxyResetEachProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbXproxyResetEachProxy.Location = new System.Drawing.Point(90, 7);
			rbXproxyResetEachProxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbXproxyResetEachProxy.Name = "rbXproxyResetEachProxy";
			rbXproxyResetEachProxy.Size = new System.Drawing.Size(123, 20);
			rbXproxyResetEachProxy.TabIndex = 154;
			rbXproxyResetEachProxy.TabStop = true;
			rbXproxyResetEachProxy.Text = "Reset từng proxy";
			rbXproxyResetEachProxy.UseVisualStyleBackColor = true;
			ckbWaitDoneAllXproxy.AutoSize = true;
			ckbWaitDoneAllXproxy.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbWaitDoneAllXproxy.Location = new System.Drawing.Point(108, 49);
			ckbWaitDoneAllXproxy.Name = "ckbWaitDoneAllXproxy";
			ckbWaitDoneAllXproxy.Size = new System.Drawing.Size(129, 20);
			ckbWaitDoneAllXproxy.TabIndex = 145;
			ckbWaitDoneAllXproxy.Text = "Đợi chạy xong hết";
			ckbWaitDoneAllXproxy.UseVisualStyleBackColor = true;
			ckbWaitDoneAllXproxy.Visible = false;
			txtListProxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtListProxy.Location = new System.Drawing.Point(6, 71);
			txtListProxy.Name = "txtListProxy";
			txtListProxy.Size = new System.Drawing.Size(229, 68);
			txtListProxy.TabIndex = 144;
			txtListProxy.Text = "";
			txtListProxy.WordWrap = false;
			txtListProxy.TextChanged += new System.EventHandler(txtListProxy_TextChanged);
			rbSock5Proxy.AutoSize = true;
			rbSock5Proxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbSock5Proxy.Location = new System.Drawing.Point(153, 28);
			rbSock5Proxy.Name = "rbSock5Proxy";
			rbSock5Proxy.Size = new System.Drawing.Size(60, 20);
			rbSock5Proxy.TabIndex = 82;
			rbSock5Proxy.Text = "Sock5";
			rbSock5Proxy.UseVisualStyleBackColor = true;
			rbHttpProxy.AutoSize = true;
			rbHttpProxy.Checked = true;
			rbHttpProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbHttpProxy.Location = new System.Drawing.Point(90, 28);
			rbHttpProxy.Name = "rbHttpProxy";
			rbHttpProxy.Size = new System.Drawing.Size(49, 20);
			rbHttpProxy.TabIndex = 82;
			rbHttpProxy.TabStop = true;
			rbHttpProxy.Text = "Http";
			rbHttpProxy.UseVisualStyleBackColor = true;
			label16.AutoSize = true;
			label16.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label16.Location = new System.Drawing.Point(3, 28);
			label16.Name = "label16";
			label16.Size = new System.Drawing.Size(71, 16);
			label16.TabIndex = 79;
			label16.Text = "Loại Proxy:";
			metroButton1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			metroButton1.BackgroundImage = maxcare.Properties.Resources.icons8_expand_arrow_24px;
			metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton1.Location = new System.Drawing.Point(209, 141);
			metroButton1.Name = "metroButton1";
			metroButton1.Size = new System.Drawing.Size(25, 25);
			metroButton1.TabIndex = 152;
			metroButton1.UseSelectable = true;
			metroButton1.Click += new System.EventHandler(metroButton1_Click);
			label17.AutoSize = true;
			label17.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label17.Location = new System.Drawing.Point(3, 50);
			label17.Name = "label17";
			label17.Size = new System.Drawing.Size(98, 16);
			label17.TabIndex = 79;
			label17.Text = "Nhập Proxy (0):";
			label52.AutoSize = true;
			label52.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label52.Location = new System.Drawing.Point(199, 174);
			label52.Name = "label52";
			label52.Size = new System.Drawing.Size(33, 16);
			label52.TabIndex = 139;
			label52.Text = "phút";
			label51.AutoSize = true;
			label51.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label51.Location = new System.Drawing.Point(5, 172);
			label51.Name = "label51";
			label51.Size = new System.Drawing.Size(139, 16);
			label51.TabIndex = 139;
			label51.Text = "Chờ reset proxy tối đa:";
			label18.AutoSize = true;
			label18.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label18.Location = new System.Drawing.Point(5, 143);
			label18.Name = "label18";
			label18.Size = new System.Drawing.Size(79, 16);
			label18.TabIndex = 139;
			label18.Text = "Số luồng/IP:";
			nudDelayResetXProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudDelayResetXProxy.Location = new System.Drawing.Point(144, 170);
			nudDelayResetXProxy.Name = "nudDelayResetXProxy";
			nudDelayResetXProxy.Size = new System.Drawing.Size(50, 23);
			nudDelayResetXProxy.TabIndex = 140;
			nudDelayResetXProxy.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudLuongPerIPXProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPXProxy.Location = new System.Drawing.Point(90, 142);
			nudLuongPerIPXProxy.Name = "nudLuongPerIPXProxy";
			nudLuongPerIPXProxy.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPXProxy.TabIndex = 140;
			nudLuongPerIPXProxy.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label13.AutoSize = true;
			label13.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label13.Location = new System.Drawing.Point(3, 5);
			label13.Name = "label13";
			label13.Size = new System.Drawing.Size(81, 16);
			label13.TabIndex = 79;
			label13.Text = "Service URL:";
			txtServiceURLXProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtServiceURLXProxy.ForeColor = System.Drawing.Color.Black;
			txtServiceURLXProxy.Location = new System.Drawing.Point(90, 2);
			txtServiceURLXProxy.Name = "txtServiceURLXProxy";
			txtServiceURLXProxy.Size = new System.Drawing.Size(145, 23);
			txtServiceURLXProxy.TabIndex = 81;
			rbShopLike.AutoSize = true;
			rbShopLike.Cursor = System.Windows.Forms.Cursors.Hand;
			rbShopLike.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbShopLike.Location = new System.Drawing.Point(23, 650);
			rbShopLike.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbShopLike.Name = "rbShopLike";
			rbShopLike.Size = new System.Drawing.Size(166, 20);
			rbShopLike.TabIndex = 152;
			rbShopLike.Text = "http://proxy.shoplike.vn/";
			rbShopLike.UseVisualStyleBackColor = true;
			rbShopLike.CheckedChanged += new System.EventHandler(rbShopLike_CheckedChanged);
			plProxyv6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plProxyv6.Controls.Add(txtListProxyv6);
			plProxyv6.Controls.Add(radioButton1);
			plProxyv6.Controls.Add(radioButton6);
			plProxyv6.Controls.Add(label39);
			plProxyv6.Controls.Add(label43);
			plProxyv6.Controls.Add(label44);
			plProxyv6.Controls.Add(nudLuongPerIPProxyv6);
			plProxyv6.Controls.Add(label45);
			plProxyv6.Controls.Add(txtApiProxyv6);
			plProxyv6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plProxyv6.Location = new System.Drawing.Point(325, 484);
			plProxyv6.Name = "plProxyv6";
			plProxyv6.Size = new System.Drawing.Size(240, 170);
			plProxyv6.TabIndex = 151;
			txtListProxyv6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtListProxyv6.Location = new System.Drawing.Point(6, 71);
			txtListProxyv6.Name = "txtListProxyv6";
			txtListProxyv6.Size = new System.Drawing.Size(229, 68);
			txtListProxyv6.TabIndex = 144;
			txtListProxyv6.Text = "";
			txtListProxyv6.WordWrap = false;
			txtListProxyv6.TextChanged += new System.EventHandler(txtListProxyv6_TextChanged);
			radioButton1.AutoSize = true;
			radioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton1.Enabled = false;
			radioButton1.Location = new System.Drawing.Point(138, 28);
			radioButton1.Name = "radioButton1";
			radioButton1.Size = new System.Drawing.Size(60, 20);
			radioButton1.TabIndex = 82;
			radioButton1.Text = "Sock5";
			radioButton1.UseVisualStyleBackColor = true;
			radioButton6.AutoSize = true;
			radioButton6.Checked = true;
			radioButton6.Cursor = System.Windows.Forms.Cursors.Hand;
			radioButton6.Location = new System.Drawing.Point(75, 28);
			radioButton6.Name = "radioButton6";
			radioButton6.Size = new System.Drawing.Size(49, 20);
			radioButton6.TabIndex = 82;
			radioButton6.TabStop = true;
			radioButton6.Text = "Http";
			radioButton6.UseVisualStyleBackColor = true;
			label39.AutoSize = true;
			label39.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label39.Location = new System.Drawing.Point(3, 28);
			label39.Name = "label39";
			label39.Size = new System.Drawing.Size(71, 16);
			label39.TabIndex = 79;
			label39.Text = "Loại Proxy:";
			label43.AutoSize = true;
			label43.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label43.Location = new System.Drawing.Point(3, 50);
			label43.Name = "label43";
			label43.Size = new System.Drawing.Size(98, 16);
			label43.TabIndex = 79;
			label43.Text = "Nhập Proxy (0):";
			label44.AutoSize = true;
			label44.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label44.Location = new System.Drawing.Point(5, 143);
			label44.Name = "label44";
			label44.Size = new System.Drawing.Size(79, 16);
			label44.TabIndex = 139;
			label44.Text = "Số luồng/IP:";
			nudLuongPerIPProxyv6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPProxyv6.Location = new System.Drawing.Point(90, 142);
			nudLuongPerIPProxyv6.Name = "nudLuongPerIPProxyv6";
			nudLuongPerIPProxyv6.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPProxyv6.TabIndex = 140;
			nudLuongPerIPProxyv6.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label45.AutoSize = true;
			label45.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label45.Location = new System.Drawing.Point(3, 5);
			label45.Name = "label45";
			label45.Size = new System.Drawing.Size(56, 16);
			label45.TabIndex = 79;
			label45.Text = "API Key:";
			txtApiProxyv6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtApiProxyv6.ForeColor = System.Drawing.Color.Black;
			txtApiProxyv6.Location = new System.Drawing.Point(75, 2);
			txtApiProxyv6.Name = "txtApiProxyv6";
			txtApiProxyv6.Size = new System.Drawing.Size(160, 23);
			txtApiProxyv6.TabIndex = 81;
			rbProxyv6.AutoSize = true;
			rbProxyv6.Cursor = System.Windows.Forms.Cursors.Hand;
			rbProxyv6.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbProxyv6.Location = new System.Drawing.Point(325, 461);
			rbProxyv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbProxyv6.Name = "rbProxyv6";
			rbProxyv6.Size = new System.Drawing.Size(92, 20);
			rbProxyv6.TabIndex = 150;
			rbProxyv6.Text = "Proxyv6.net";
			rbProxyv6.UseVisualStyleBackColor = true;
			rbProxyv6.CheckedChanged += new System.EventHandler(rbProxyv6_CheckedChanged);
			label37.AutoSize = true;
			label37.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label37.Location = new System.Drawing.Point(29, 53);
			label37.Name = "label37";
			label37.Size = new System.Drawing.Size(162, 16);
			label37.TabIndex = 139;
			label37.Text = "Delay Check IP sau khi đô\u0309i:";
			nudDelayCheckIP.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudDelayCheckIP.Location = new System.Drawing.Point(193, 51);
			nudDelayCheckIP.Maximum = new decimal(new int[4] { 99999999, 0, 0, 0 });
			nudDelayCheckIP.Name = "nudDelayCheckIP";
			nudDelayCheckIP.Size = new System.Drawing.Size(46, 23);
			nudDelayCheckIP.TabIndex = 140;
			linkLabel3.AutoSize = true;
			linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
			linkLabel3.Location = new System.Drawing.Point(197, 453);
			linkLabel3.Name = "linkLabel3";
			linkLabel3.Size = new System.Drawing.Size(86, 16);
			linkLabel3.TabIndex = 147;
			linkLabel3.TabStop = true;
			linkLabel3.Text = "Hươ\u0301ng dâ\u0303n(?)";
			linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel3_LinkClicked);
			label38.AutoSize = true;
			label38.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label38.Location = new System.Drawing.Point(241, 53);
			label38.Name = "label38";
			label38.Size = new System.Drawing.Size(31, 16);
			label38.TabIndex = 141;
			label38.Text = "giây";
			linkLabel1.AutoSize = true;
			linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
			linkLabel1.Location = new System.Drawing.Point(481, 259);
			linkLabel1.Name = "linkLabel1";
			linkLabel1.Size = new System.Drawing.Size(86, 16);
			linkLabel1.TabIndex = 147;
			linkLabel1.TabStop = true;
			linkLabel1.Text = "Hươ\u0301ng dâ\u0303n(?)";
			linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel1_LinkClicked);
			plTMProxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plTMProxy.Controls.Add(ckbWaitDoneAllTMProxy);
			plTMProxy.Controls.Add(txtApiKeyTMProxy);
			plTMProxy.Controls.Add(label24);
			plTMProxy.Controls.Add(button8);
			plTMProxy.Controls.Add(label25);
			plTMProxy.Controls.Add(nudLuongPerIPTMProxy);
			plTMProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plTMProxy.Location = new System.Drawing.Point(322, 280);
			plTMProxy.Name = "plTMProxy";
			plTMProxy.Size = new System.Drawing.Size(240, 164);
			plTMProxy.TabIndex = 146;
			plTMProxy.Click += new System.EventHandler(plTMProxy_Click);
			ckbWaitDoneAllTMProxy.AutoSize = true;
			ckbWaitDoneAllTMProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbWaitDoneAllTMProxy.Location = new System.Drawing.Point(115, 1);
			ckbWaitDoneAllTMProxy.Name = "ckbWaitDoneAllTMProxy";
			ckbWaitDoneAllTMProxy.Size = new System.Drawing.Size(129, 20);
			ckbWaitDoneAllTMProxy.TabIndex = 145;
			ckbWaitDoneAllTMProxy.Text = "Đợi chạy xong hết";
			ckbWaitDoneAllTMProxy.UseVisualStyleBackColor = true;
			ckbWaitDoneAllTMProxy.Visible = false;
			txtApiKeyTMProxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtApiKeyTMProxy.Location = new System.Drawing.Point(6, 23);
			txtApiKeyTMProxy.Name = "txtApiKeyTMProxy";
			txtApiKeyTMProxy.Size = new System.Drawing.Size(226, 101);
			txtApiKeyTMProxy.TabIndex = 144;
			txtApiKeyTMProxy.Text = "";
			txtApiKeyTMProxy.WordWrap = false;
			txtApiKeyTMProxy.TextChanged += new System.EventHandler(txtApiKeyTMProxy_TextChanged);
			label24.AutoSize = true;
			label24.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label24.Location = new System.Drawing.Point(3, 2);
			label24.Name = "label24";
			label24.Size = new System.Drawing.Size(111, 16);
			label24.TabIndex = 79;
			label24.Text = "Nhập API KEY (0):";
			button8.Cursor = System.Windows.Forms.Cursors.Hand;
			button8.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button8.ForeColor = System.Drawing.Color.Black;
			button8.Location = new System.Drawing.Point(171, 127);
			button8.Name = "button8";
			button8.Size = new System.Drawing.Size(52, 27);
			button8.TabIndex = 143;
			button8.Text = "Check";
			button8.UseVisualStyleBackColor = true;
			button8.Click += new System.EventHandler(button8_Click);
			label25.AutoSize = true;
			label25.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label25.Location = new System.Drawing.Point(5, 131);
			label25.Name = "label25";
			label25.Size = new System.Drawing.Size(79, 16);
			label25.TabIndex = 139;
			label25.Text = "Số luồng/IP:";
			nudLuongPerIPTMProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPTMProxy.Location = new System.Drawing.Point(90, 130);
			nudLuongPerIPTMProxy.Name = "nudLuongPerIPTMProxy";
			nudLuongPerIPTMProxy.Size = new System.Drawing.Size(67, 23);
			nudLuongPerIPTMProxy.TabIndex = 140;
			nudLuongPerIPTMProxy.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			plCheckDoiIP.Controls.Add(button5);
			plCheckDoiIP.Controls.Add(label26);
			plCheckDoiIP.Controls.Add(nudChangeIpCount);
			plCheckDoiIP.Controls.Add(label27);
			plCheckDoiIP.Location = new System.Drawing.Point(26, 78);
			plCheckDoiIP.Name = "plCheckDoiIP";
			plCheckDoiIP.Size = new System.Drawing.Size(270, 27);
			plCheckDoiIP.TabIndex = 146;
			button5.Cursor = System.Windows.Forms.Cursors.Hand;
			button5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button5.ForeColor = System.Drawing.Color.Black;
			button5.Location = new System.Drawing.Point(193, 0);
			button5.Name = "button5";
			button5.Size = new System.Drawing.Size(77, 27);
			button5.TabIndex = 143;
			button5.Text = "Test";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			label26.AutoSize = true;
			label26.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label26.Location = new System.Drawing.Point(3, 5);
			label26.Name = "label26";
			label26.Size = new System.Drawing.Size(101, 16);
			label26.TabIndex = 139;
			label26.Text = "Thay đổi IP sau:";
			nudChangeIpCount.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudChangeIpCount.Location = new System.Drawing.Point(106, 3);
			nudChangeIpCount.Name = "nudChangeIpCount";
			nudChangeIpCount.Size = new System.Drawing.Size(46, 23);
			nudChangeIpCount.TabIndex = 140;
			nudChangeIpCount.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label27.AutoSize = true;
			label27.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label27.Location = new System.Drawing.Point(154, 5);
			label27.Name = "label27";
			label27.Size = new System.Drawing.Size(30, 16);
			label27.TabIndex = 141;
			label27.Text = "lượt";
			plTinsoft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plTinsoft.Controls.Add(ckbWaitDoneAllTinsoft);
			plTinsoft.Controls.Add(plApiProxy);
			plTinsoft.Controls.Add(plApiUser);
			plTinsoft.Controls.Add(cbbLocationTinsoft);
			plTinsoft.Controls.Add(rbApiProxy);
			plTinsoft.Controls.Add(rbApiUser);
			plTinsoft.Controls.Add(label7);
			plTinsoft.Controls.Add(label8);
			plTinsoft.Controls.Add(nudLuongPerIPTinsoft);
			plTinsoft.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plTinsoft.Location = new System.Drawing.Point(23, 474);
			plTinsoft.Name = "plTinsoft";
			plTinsoft.Size = new System.Drawing.Size(266, 170);
			plTinsoft.TabIndex = 142;
			plTinsoft.Click += new System.EventHandler(plTinsoft_Click);
			ckbWaitDoneAllTinsoft.AutoSize = true;
			ckbWaitDoneAllTinsoft.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbWaitDoneAllTinsoft.Location = new System.Drawing.Point(132, 3);
			ckbWaitDoneAllTinsoft.Name = "ckbWaitDoneAllTinsoft";
			ckbWaitDoneAllTinsoft.Size = new System.Drawing.Size(129, 20);
			ckbWaitDoneAllTinsoft.TabIndex = 145;
			ckbWaitDoneAllTinsoft.Text = "Đợi chạy xong hết";
			ckbWaitDoneAllTinsoft.UseVisualStyleBackColor = true;
			ckbWaitDoneAllTinsoft.Visible = false;
			plApiProxy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plApiProxy.Controls.Add(lblCountApiProxy);
			plApiProxy.Controls.Add(label28);
			plApiProxy.Controls.Add(txtApiProxy);
			plApiProxy.Controls.Add(button7);
			plApiProxy.Location = new System.Drawing.Point(6, 77);
			plApiProxy.Name = "plApiProxy";
			plApiProxy.Size = new System.Drawing.Size(257, 58);
			plApiProxy.TabIndex = 35;
			lblCountApiProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			lblCountApiProxy.Location = new System.Drawing.Point(1, 24);
			lblCountApiProxy.Name = "lblCountApiProxy";
			lblCountApiProxy.Size = new System.Drawing.Size(32, 16);
			lblCountApiProxy.TabIndex = 82;
			lblCountApiProxy.Text = "(0)";
			lblCountApiProxy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label28.AutoSize = true;
			label28.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label28.Location = new System.Drawing.Point(1, 5);
			label28.Name = "label28";
			label28.Size = new System.Drawing.Size(32, 16);
			label28.TabIndex = 82;
			label28.Text = "API:";
			txtApiProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtApiProxy.ForeColor = System.Drawing.Color.Black;
			txtApiProxy.Location = new System.Drawing.Point(35, 2);
			txtApiProxy.Multiline = true;
			txtApiProxy.Name = "txtApiProxy";
			txtApiProxy.Size = new System.Drawing.Size(165, 51);
			txtApiProxy.TabIndex = 83;
			txtApiProxy.WordWrap = false;
			txtApiProxy.TextChanged += new System.EventHandler(txtApiProxy_TextChanged);
			button7.Cursor = System.Windows.Forms.Cursors.Hand;
			button7.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button7.ForeColor = System.Drawing.Color.Black;
			button7.Location = new System.Drawing.Point(203, 1);
			button7.Name = "button7";
			button7.Size = new System.Drawing.Size(52, 27);
			button7.TabIndex = 143;
			button7.Text = "Check";
			button7.UseVisualStyleBackColor = true;
			button7.Click += new System.EventHandler(button7_Click);
			plApiUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plApiUser.Controls.Add(label1);
			plApiUser.Controls.Add(txtApiUser);
			plApiUser.Controls.Add(button3);
			plApiUser.Location = new System.Drawing.Point(6, 24);
			plApiUser.Name = "plApiUser";
			plApiUser.Size = new System.Drawing.Size(257, 29);
			plApiUser.TabIndex = 35;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label1.Location = new System.Drawing.Point(1, 5);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(32, 16);
			label1.TabIndex = 82;
			label1.Text = "API:";
			txtApiUser.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtApiUser.ForeColor = System.Drawing.Color.Black;
			txtApiUser.Location = new System.Drawing.Point(35, 2);
			txtApiUser.Name = "txtApiUser";
			txtApiUser.Size = new System.Drawing.Size(165, 23);
			txtApiUser.TabIndex = 83;
			button3.Cursor = System.Windows.Forms.Cursors.Hand;
			button3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button3.ForeColor = System.Drawing.Color.Black;
			button3.Location = new System.Drawing.Point(203, 0);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(52, 27);
			button3.TabIndex = 143;
			button3.Text = "Check";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			cbbLocationTinsoft.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbLocationTinsoft.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbLocationTinsoft.DropDownWidth = 120;
			cbbLocationTinsoft.FormattingEnabled = true;
			cbbLocationTinsoft.Location = new System.Drawing.Point(61, 139);
			cbbLocationTinsoft.Name = "cbbLocationTinsoft";
			cbbLocationTinsoft.Size = new System.Drawing.Size(67, 24);
			cbbLocationTinsoft.TabIndex = 84;
			rbApiProxy.AutoSize = true;
			rbApiProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbApiProxy.Location = new System.Drawing.Point(3, 56);
			rbApiProxy.Name = "rbApiProxy";
			rbApiProxy.Size = new System.Drawing.Size(136, 20);
			rbApiProxy.TabIndex = 34;
			rbApiProxy.Text = "Sử dụng Api Proxy:";
			rbApiProxy.UseVisualStyleBackColor = true;
			rbApiProxy.CheckedChanged += new System.EventHandler(rbApiProxy_CheckedChanged);
			rbApiUser.AutoSize = true;
			rbApiUser.Checked = true;
			rbApiUser.Cursor = System.Windows.Forms.Cursors.Hand;
			rbApiUser.Location = new System.Drawing.Point(3, 3);
			rbApiUser.Name = "rbApiUser";
			rbApiUser.Size = new System.Drawing.Size(131, 20);
			rbApiUser.TabIndex = 34;
			rbApiUser.TabStop = true;
			rbApiUser.Text = "Sử dụng Api User:";
			rbApiUser.UseVisualStyleBackColor = true;
			rbApiUser.CheckedChanged += new System.EventHandler(rbApiUser_CheckedChanged);
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label7.Location = new System.Drawing.Point(3, 142);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(60, 16);
			label7.TabIndex = 82;
			label7.Text = "Location:";
			label8.AutoSize = true;
			label8.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label8.Location = new System.Drawing.Point(134, 142);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(79, 16);
			label8.TabIndex = 139;
			label8.Text = "Số luồng/IP:";
			toolTip1.SetToolTip(label8, "Là số tài khoản cùng chạy trên 1 Proxy (hay 1 IP)");
			nudLuongPerIPTinsoft.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			nudLuongPerIPTinsoft.Location = new System.Drawing.Point(216, 140);
			nudLuongPerIPTinsoft.Name = "nudLuongPerIPTinsoft";
			nudLuongPerIPTinsoft.Size = new System.Drawing.Size(46, 23);
			nudLuongPerIPTinsoft.TabIndex = 140;
			nudLuongPerIPTinsoft.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			rbTMProxy.AutoSize = true;
			rbTMProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTMProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbTMProxy.Location = new System.Drawing.Point(322, 257);
			rbTMProxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbTMProxy.Name = "rbTMProxy";
			rbTMProxy.Size = new System.Drawing.Size(148, 20);
			rbTMProxy.TabIndex = 145;
			rbTMProxy.Text = "https://tmproxy.com/";
			rbTMProxy.UseVisualStyleBackColor = true;
			rbTMProxy.CheckedChanged += new System.EventHandler(rbTMProxy_CheckedChanged);
			plDcom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDcom.Controls.Add(button4);
			plDcom.Controls.Add(txtUrlHilink);
			plDcom.Controls.Add(txtProfileNameDcom);
			plDcom.Controls.Add(rbDcomHilink);
			plDcom.Controls.Add(label36);
			plDcom.Controls.Add(rbDcomThuong);
			plDcom.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			plDcom.Location = new System.Drawing.Point(26, 182);
			plDcom.Name = "plDcom";
			plDcom.Size = new System.Drawing.Size(265, 57);
			plDcom.TabIndex = 131;
			button4.Cursor = System.Windows.Forms.Cursors.Hand;
			button4.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			button4.ForeColor = System.Drawing.Color.Black;
			button4.Location = new System.Drawing.Point(72, 1);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(93, 25);
			button4.TabIndex = 143;
			button4.Text = "Lâ\u0301y tên Dcom";
			toolTip1.SetToolTip(button4, "Lâ\u0301y tên dcom");
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			txtUrlHilink.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtUrlHilink.ForeColor = System.Drawing.Color.Black;
			txtUrlHilink.Location = new System.Drawing.Point(171, 30);
			txtUrlHilink.Name = "txtUrlHilink";
			txtUrlHilink.Size = new System.Drawing.Size(91, 23);
			txtUrlHilink.TabIndex = 81;
			txtProfileNameDcom.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			txtProfileNameDcom.ForeColor = System.Drawing.Color.Black;
			txtProfileNameDcom.Location = new System.Drawing.Point(171, 2);
			txtProfileNameDcom.Name = "txtProfileNameDcom";
			txtProfileNameDcom.Size = new System.Drawing.Size(91, 23);
			txtProfileNameDcom.TabIndex = 81;
			rbDcomHilink.AutoSize = true;
			rbDcomHilink.Cursor = System.Windows.Forms.Cursors.Hand;
			rbDcomHilink.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbDcomHilink.Location = new System.Drawing.Point(5, 31);
			rbDcomHilink.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbDcomHilink.Name = "rbDcomHilink";
			rbDcomHilink.Size = new System.Drawing.Size(56, 20);
			rbDcomHilink.TabIndex = 136;
			rbDcomHilink.Text = "Hilink";
			rbDcomHilink.UseVisualStyleBackColor = true;
			rbDcomHilink.CheckedChanged += new System.EventHandler(rbDcomHilink_CheckedChanged);
			label36.AutoSize = true;
			label36.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			label36.Location = new System.Drawing.Point(69, 33);
			label36.Name = "label36";
			label36.Size = new System.Drawing.Size(102, 16);
			label36.TabIndex = 79;
			label36.Text = "Đươ\u0300ng dâ\u0303n URL:";
			rbDcomThuong.AutoSize = true;
			rbDcomThuong.Cursor = System.Windows.Forms.Cursors.Hand;
			rbDcomThuong.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbDcomThuong.Location = new System.Drawing.Point(5, 3);
			rbDcomThuong.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbDcomThuong.Name = "rbDcomThuong";
			rbDcomThuong.Size = new System.Drawing.Size(70, 20);
			rbDcomThuong.TabIndex = 136;
			rbDcomThuong.Text = "Thươ\u0300ng";
			rbDcomThuong.UseVisualStyleBackColor = true;
			rbDcomThuong.CheckedChanged += new System.EventHandler(radioButton1_CheckedChanged);
			rbDcom.AutoSize = true;
			rbDcom.Cursor = System.Windows.Forms.Cursors.Hand;
			rbDcom.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbDcom.Location = new System.Drawing.Point(32, 157);
			rbDcom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbDcom.Name = "rbDcom";
			rbDcom.Size = new System.Drawing.Size(96, 20);
			rbDcom.TabIndex = 137;
			rbDcom.Text = "Đổi IP Dcom";
			rbDcom.UseVisualStyleBackColor = true;
			rbDcom.CheckedChanged += new System.EventHandler(rbDcom_CheckedChanged);
			rbTinsoft.AutoSize = true;
			rbTinsoft.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTinsoft.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbTinsoft.Location = new System.Drawing.Point(23, 451);
			rbTinsoft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbTinsoft.Name = "rbTinsoft";
			rbTinsoft.Size = new System.Drawing.Size(168, 20);
			rbTinsoft.TabIndex = 134;
			rbTinsoft.Text = "https://tinsoftproxy.com/";
			rbTinsoft.UseVisualStyleBackColor = true;
			rbTinsoft.CheckedChanged += new System.EventHandler(rbTinsoft_CheckedChanged);
			rbProxy.AutoSize = true;
			rbProxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbProxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbProxy.Location = new System.Drawing.Point(32, 132);
			rbProxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbProxy.Name = "rbProxy";
			rbProxy.Size = new System.Drawing.Size(109, 20);
			rbProxy.TabIndex = 136;
			rbProxy.Text = "Sử dụng Proxy";
			rbProxy.UseVisualStyleBackColor = true;
			rbNone.AutoSize = true;
			rbNone.Checked = true;
			rbNone.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNone.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbNone.Location = new System.Drawing.Point(32, 108);
			rbNone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbNone.Name = "rbNone";
			rbNone.Size = new System.Drawing.Size(97, 20);
			rbNone.TabIndex = 136;
			rbNone.TabStop = true;
			rbNone.Text = "Không đổi IP";
			rbNone.UseVisualStyleBackColor = true;
			rbNone.CheckedChanged += new System.EventHandler(rbNone_CheckedChanged);
			rbXproxy.AutoSize = true;
			rbXproxy.Cursor = System.Windows.Forms.Cursors.Hand;
			rbXproxy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbXproxy.Location = new System.Drawing.Point(322, 60);
			rbXproxy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbXproxy.Name = "rbXproxy";
			rbXproxy.Size = new System.Drawing.Size(224, 20);
			rbXproxy.TabIndex = 138;
			rbXproxy.Text = "Xproxy, Mobi, OBC, Eager, S Proxy";
			rbXproxy.UseVisualStyleBackColor = true;
			rbXproxy.CheckedChanged += new System.EventHandler(rbXproxy_CheckedChanged);
			rbHma.AutoSize = true;
			rbHma.Cursor = System.Windows.Forms.Cursors.Hand;
			rbHma.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 163);
			rbHma.Location = new System.Drawing.Point(208, 153);
			rbHma.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbHma.Name = "rbHma";
			rbHma.Size = new System.Drawing.Size(90, 20);
			rbHma.TabIndex = 138;
			rbHma.Text = "Đổi IP HMA";
			rbHma.UseVisualStyleBackColor = true;
			rbHma.CheckedChanged += new System.EventHandler(rbHma_CheckedChanged);
			ckbKhongCheckIP.AutoSize = true;
			ckbKhongCheckIP.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbKhongCheckIP.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbKhongCheckIP.Location = new System.Drawing.Point(30, 26);
			ckbKhongCheckIP.Name = "ckbKhongCheckIP";
			ckbKhongCheckIP.Size = new System.Drawing.Size(199, 20);
			ckbKhongCheckIP.TabIndex = 112;
			ckbKhongCheckIP.Text = "Không Check IP trước khi chạy";
			ckbKhongCheckIP.UseVisualStyleBackColor = true;
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 200;
			toolTip1.ReshowDelay = 40;
			panel6.Location = new System.Drawing.Point(94, 94);
			panel6.Name = "panel6";
			panel6.Size = new System.Drawing.Size(200, 49);
			panel6.TabIndex = 152;
			panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel7.Controls.Add(label53);
			panel7.Controls.Add(rbXproxyResetAllProxy);
			panel7.Controls.Add(rbXproxyResetEachProxy);
			panel7.Location = new System.Drawing.Point(6, 198);
			panel7.Name = "panel7";
			panel7.Size = new System.Drawing.Size(223, 55);
			panel7.TabIndex = 152;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1158, 544);
			base.Controls.Add(panel1);
			base.Controls.Add(bunifuCards1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "fCauHinhChung";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình chung";
			base.Load += new System.EventHandler(FConfigGenneral_Load);
			((System.ComponentModel.ISupportInitialize)nudInteractThread).EndInit();
			((System.ComponentModel.ISupportInitialize)nudHideThread).EndInit();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			plVitech.ResumeLayout(false);
			plVitech.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPVitech).EndInit();
			grChrome.ResumeLayout(false);
			grChrome.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			plSizeChrome.ResumeLayout(false);
			plSizeChrome.PerformLayout();
			plSapXepCuaSoChrome.ResumeLayout(false);
			plSapXepCuaSoChrome.PerformLayout();
			plAddChromeVaoFormView.ResumeLayout(false);
			plAddChromeVaoFormView.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudWidthChrome).EndInit();
			((System.ComponentModel.ISupportInitialize)nudHeighChrome).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCloseChromeFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCloseChromeTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayOpenChromeFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayOpenChromeTo).EndInit();
			plLinkToOtherBrowser.ResumeLayout(false);
			plLinkToOtherBrowser.PerformLayout();
			plUsePortable.ResumeLayout(false);
			plUsePortable.PerformLayout();
			bunifuCards2.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			plNordVPN.ResumeLayout(false);
			plNordVPN.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			panel5.ResumeLayout(false);
			panel5.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPMinProxy).EndInit();
			plShopLike.ResumeLayout(false);
			plShopLike.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPShopLike).EndInit();
			plXproxy.ResumeLayout(false);
			plXproxy.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudDelayResetXProxy).EndInit();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPXProxy).EndInit();
			plProxyv6.ResumeLayout(false);
			plProxyv6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPProxyv6).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayCheckIP).EndInit();
			plTMProxy.ResumeLayout(false);
			plTMProxy.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPTMProxy).EndInit();
			plCheckDoiIP.ResumeLayout(false);
			plCheckDoiIP.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudChangeIpCount).EndInit();
			plTinsoft.ResumeLayout(false);
			plTinsoft.PerformLayout();
			plApiProxy.ResumeLayout(false);
			plApiProxy.PerformLayout();
			plApiUser.ResumeLayout(false);
			plApiUser.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudLuongPerIPTinsoft).EndInit();
			plDcom.ResumeLayout(false);
			plDcom.PerformLayout();
			panel7.ResumeLayout(false);
			panel7.PerformLayout();
			ResumeLayout(false);
		}
	}
}
