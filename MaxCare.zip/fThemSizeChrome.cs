using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.Properties;
using MCommon;
using Newtonsoft.Json.Linq;

namespace maxcare
{
	public class fThemSizeChrome : Form
	{
		private Random rd = new Random();

		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Panel panel1;

		private BunifuDragControl bunifuDragControl1;

		private ToolTip toolTip1;

		private BunifuCards bunifuCards2;

		private Panel pnlHeader;

		private Button button2;

		private PictureBox pictureBox1;

		private Button btnMinimize;

		private BunifuCustomLabel lblTitle;

		private Button btnSave;

		private GroupBox grDanhSach;

		private GroupBox grChiTiet;

		public DataGridView dtgvDanhSach;

		private Button btnAdd;

		private Button btnHuy;

		private TextBox txtTen;

		private Label label2;

		private Label label1;

		private NumericUpDown nudHeight;

		private NumericUpDown nudWidth;

		private Label label11;

		private Label label3;

		private DataGridViewTextBoxColumn cSTT;

		private DataGridViewTextBoxColumn cName;

		private DataGridViewTextBoxColumn cSize;

		private DataGridViewTextBoxColumn cPixelRatio;

		private DataGridViewButtonColumn cSua;

		private DataGridViewButtonColumn cXoa;

		private TextBox txtPixelRatio;

		public fThemSizeChrome()
		{
			InitializeComponent();
			ChangeLanguage();
		}

		private void ChangeLanguage()
		{
			Language.GetValue(lblTitle);
			Language.GetValue(grDanhSach);
			Language.GetValue(label1);
			foreach (DataGridViewColumn column in dtgvDanhSach.Columns)
			{
				Language.GetValue(column);
			}
			Language.GetValue(btnAdd);
			Language.GetValue(label2);
			Language.GetValue(label3);
			Language.GetValue(btnSave);
			Language.GetValue(btnHuy);
		}

		private void FConfigGenneral_Load(object sender, EventArgs e)
		{
			LoadDsFile();
		}

		private void LoadContentFileFromDtgv(int row)
		{
			try
			{
				txtTen.Text = DatagridviewHelper.GetStatusDataGridView(dtgvDanhSach, row, "cName");
				string statusDataGridView = DatagridviewHelper.GetStatusDataGridView(dtgvDanhSach, row, "cSize");
				txtPixelRatio.Text = ((DatagridviewHelper.GetStatusDataGridView(dtgvDanhSach, row, "cPixelRatio") == "") ? "0" : DatagridviewHelper.GetStatusDataGridView(dtgvDanhSach, row, "cPixelRatio"));
				nudWidth.Value = Convert.ToInt32(statusDataGridView.Split('x')[0]);
				nudHeight.Value = Convert.ToInt32(statusDataGridView.Split('x')[1]);
			}
			catch
			{
			}
		}

		private void LoadDsFile()
		{
			int num = -1;
			switch (dtgvDanhSach.RowCount)
			{
			default:
				num = dtgvDanhSach.SelectedRows[0].Index;
				break;
			case 1:
				num = 0;
				break;
			case 0:
				break;
			}
			dtgvDanhSach.Rows.Clear();
			JSON_Settings jSON_Settings = new JSON_Settings("configChrome");
			if (!(jSON_Settings.GetValue("sizeChrome") != ""))
			{
				return;
			}
			Dictionary<string, object> dictionary = JSON_Settings.ConvertToDictionary(JObject.Parse(jSON_Settings.GetValue("sizeChrome")));
			foreach (KeyValuePair<string, object> item in dictionary)
			{
				if (item.Value.ToString().Split('x').Length == 3)
				{
					dtgvDanhSach.Rows.Add(dtgvDanhSach.RowCount + 1, item.Key, item.Value.ToString().Substring(0, item.Value.ToString().LastIndexOf('x')), item.Value.ToString().Split('x')[2], "Sư\u0309a", "Xo\u0301a");
				}
				else
				{
					dtgvDanhSach.Rows.Add(dtgvDanhSach.RowCount + 1, item.Key, item.Value.ToString().Substring(0, item.Value.ToString().LastIndexOf('x')), "", "Sư\u0309a", "Xo\u0301a");
				}
			}
			if (num == -1 && dtgvDanhSach.RowCount > 0)
			{
				num = 0;
			}
			else if (num + 1 > dtgvDanhSach.RowCount)
			{
				num = dtgvDanhSach.RowCount - 1;
			}
			if (num == -1)
			{
				txtTen.Text = "";
				nudWidth.Value = 0m;
				nudHeight.Value = 0m;
			}
			else
			{
				MCommon.Common.ClearSelectedOnDatagridview(dtgvDanhSach);
				dtgvDanhSach.Rows[num].Selected = true;
				LoadContentFileFromDtgv(num);
			}
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void rControl(int type)
		{
			switch (type)
			{
			case 1:
				grDanhSach.Enabled = false;
				grChiTiet.Enabled = true;
				txtTen.Clear();
				txtTen.Focus();
				nudWidth.Value = 0m;
				nudHeight.Value = 0m;
				break;
			case 2:
				grDanhSach.Enabled = true;
				grChiTiet.Enabled = false;
				break;
			case 3:
				grDanhSach.Enabled = false;
				grChiTiet.Enabled = true;
				break;
			}
		}

		private void BtnAdd_Click(object sender, EventArgs e)
		{
			rControl(1);
		}

		private void dtgvDanhSach_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
		{
			string name = dtgvDanhSach.Columns[e.ColumnIndex].Name;
			if (name != "cSua" && name != "cXoa")
			{
				dtgvDanhSach.Cursor = Cursors.Default;
			}
			else if (e.RowIndex < dtgvDanhSach.RowCount)
			{
				dtgvDanhSach.Cursor = Cursors.Hand;
			}
		}

		private void dtgvDanhSach_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			DataGridView dataGridView = (DataGridView)sender;
			if (!(dataGridView.Columns[e.ColumnIndex] is DataGridViewButtonColumn) || e.RowIndex < 0)
			{
				return;
			}
			string name = dataGridView.Columns[e.ColumnIndex].Name;
			string text = name;
			if (!(text == "cSua"))
			{
				if (text == "cXoa" && MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Bạn có muốn xóa?")) == DialogResult.Yes)
				{
					JSON_Settings jSON_Settings = new JSON_Settings(new JSON_Settings("configChrome").GetValue("sizeChrome"), isJsonString: true);
					jSON_Settings.Remove(DatagridviewHelper.GetStatusDataGridView(dtgvDanhSach, dtgvDanhSach.CurrentRow.Index, "cName"));
					JSON_Settings jSON_Settings2 = new JSON_Settings("configChrome");
					jSON_Settings2.Update("sizeChrome", jSON_Settings.GetFullString());
					jSON_Settings2.Save();
					LoadDsFile();
				}
			}
			else
			{
				rControl(3);
			}
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			try
			{
				if (txtTen.Text.Trim() == "")
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng điền tên thiết bị!"), 3);
				}
				else if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Bạn có muốn lưu lại?")) == DialogResult.Yes)
				{
					JSON_Settings jSON_Settings = new JSON_Settings(new JSON_Settings("configChrome").GetValue("sizeChrome"), isJsonString: true);
					jSON_Settings.Update(txtTen.Text.Trim(), nudWidth.Value + "x" + nudHeight.Value + "x" + txtPixelRatio.Text.Trim());
					JSON_Settings jSON_Settings2 = new JSON_Settings("configChrome");
					jSON_Settings2.Update("sizeChrome", jSON_Settings.GetFullString());
					jSON_Settings2.Save();
					LoadDsFile();
					rControl(2);
				}
			}
			catch
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Đã có lỗi xảy ra, vui lòng thử lại sau!"), 2);
			}
		}

		private void btnHuy_Click(object sender, EventArgs e)
		{
			try
			{
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Bạn có muốn hủy?")) == DialogResult.Yes)
				{
					rControl(2);
				}
			}
			catch
			{
			}
		}

		private void dtgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			LoadContentFileFromDtgv(dtgvDanhSach.CurrentRow.Index);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel1 = new System.Windows.Forms.Panel();
			grDanhSach = new System.Windows.Forms.GroupBox();
			dtgvDanhSach = new System.Windows.Forms.DataGridView();
			cSTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cPixelRatio = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cSua = new System.Windows.Forms.DataGridViewButtonColumn();
			cXoa = new System.Windows.Forms.DataGridViewButtonColumn();
			btnAdd = new System.Windows.Forms.Button();
			grChiTiet = new System.Windows.Forms.GroupBox();
			nudHeight = new System.Windows.Forms.NumericUpDown();
			nudWidth = new System.Windows.Forms.NumericUpDown();
			label11 = new System.Windows.Forms.Label();
			txtTen = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			btnHuy = new System.Windows.Forms.Button();
			btnSave = new System.Windows.Forms.Button();
			bunifuCards2 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			button2 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			btnMinimize = new System.Windows.Forms.Button();
			lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			txtPixelRatio = new System.Windows.Forms.TextBox();
			panel1.SuspendLayout();
			grDanhSach.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dtgvDanhSach).BeginInit();
			grChiTiet.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudHeight).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudWidth).BeginInit();
			bunifuCards2.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 5;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.SaddleBrown;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(415, 47);
			bunifuCards1.TabIndex = 12;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(grDanhSach);
			panel1.Controls.Add(grChiTiet);
			panel1.Controls.Add(bunifuCards2);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(744, 388);
			panel1.TabIndex = 37;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			grDanhSach.Controls.Add(dtgvDanhSach);
			grDanhSach.Controls.Add(btnAdd);
			grDanhSach.Location = new System.Drawing.Point(3, 43);
			grDanhSach.Name = "grDanhSach";
			grDanhSach.Size = new System.Drawing.Size(473, 339);
			grDanhSach.TabIndex = 50;
			grDanhSach.TabStop = false;
			grDanhSach.Text = "Danh sách Kích thước Chrome";
			dtgvDanhSach.AllowUserToAddRows = false;
			dtgvDanhSach.AllowUserToDeleteRows = false;
			dtgvDanhSach.AllowUserToResizeRows = false;
			dtgvDanhSach.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			dtgvDanhSach.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.Color.Teal;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dtgvDanhSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dtgvDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dtgvDanhSach.Columns.AddRange(cSTT, cName, cSize, cPixelRatio, cSua, cXoa);
			dtgvDanhSach.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dtgvDanhSach.Location = new System.Drawing.Point(6, 22);
			dtgvDanhSach.Name = "dtgvDanhSach";
			dtgvDanhSach.RowHeadersVisible = false;
			dtgvDanhSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dtgvDanhSach.Size = new System.Drawing.Size(461, 277);
			dtgvDanhSach.TabIndex = 76;
			dtgvDanhSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(dtgvDanhSach_CellClick);
			dtgvDanhSach.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dtgvDanhSach_CellContentClick);
			dtgvDanhSach.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dtgvDanhSach_CellMouseEnter);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			cSTT.DefaultCellStyle = dataGridViewCellStyle2;
			cSTT.HeaderText = "STT";
			cSTT.Name = "cSTT";
			cSTT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cSTT.Width = 40;
			cName.HeaderText = "Tên";
			cName.Name = "cName";
			cName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cSize.HeaderText = "Kích thước";
			cSize.Name = "cSize";
			cSize.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			cSize.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cSize.Width = 80;
			cPixelRatio.HeaderText = "Pixel Ratio";
			cPixelRatio.Name = "cPixelRatio";
			cPixelRatio.Width = 90;
			cSua.HeaderText = "Sư\u0309a";
			cSua.Name = "cSua";
			cSua.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			cSua.Width = 71;
			cXoa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			cXoa.HeaderText = "Xo\u0301a";
			cXoa.Name = "cXoa";
			cXoa.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			btnAdd.BackColor = System.Drawing.Color.Green;
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(375, 303);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 45;
			btnAdd.Text = "Thêm";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(BtnAdd_Click);
			grChiTiet.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			grChiTiet.Controls.Add(nudHeight);
			grChiTiet.Controls.Add(nudWidth);
			grChiTiet.Controls.Add(label11);
			grChiTiet.Controls.Add(txtPixelRatio);
			grChiTiet.Controls.Add(txtTen);
			grChiTiet.Controls.Add(label3);
			grChiTiet.Controls.Add(label2);
			grChiTiet.Controls.Add(label1);
			grChiTiet.Controls.Add(btnHuy);
			grChiTiet.Controls.Add(btnSave);
			grChiTiet.Enabled = false;
			grChiTiet.Location = new System.Drawing.Point(482, 44);
			grChiTiet.Name = "grChiTiet";
			grChiTiet.Size = new System.Drawing.Size(256, 177);
			grChiTiet.TabIndex = 50;
			grChiTiet.TabStop = false;
			grChiTiet.Text = "Chi tiê\u0301t";
			nudHeight.Location = new System.Drawing.Point(181, 64);
			nudHeight.Maximum = new decimal(new int[4] { 276447231, 23283, 0, 0 });
			nudHeight.Name = "nudHeight";
			nudHeight.Size = new System.Drawing.Size(59, 23);
			nudHeight.TabIndex = 49;
			nudWidth.Location = new System.Drawing.Point(95, 64);
			nudWidth.Maximum = new decimal(new int[4] { 276447231, 23283, 0, 0 });
			nudWidth.Name = "nudWidth";
			nudWidth.Size = new System.Drawing.Size(59, 23);
			nudWidth.TabIndex = 49;
			label11.AutoSize = true;
			label11.Font = new System.Drawing.Font("Tahoma", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label11.Location = new System.Drawing.Point(156, 64);
			label11.Name = "label11";
			label11.Size = new System.Drawing.Size(23, 23);
			label11.TabIndex = 48;
			label11.Text = "X";
			txtTen.Location = new System.Drawing.Point(95, 29);
			txtTen.Name = "txtTen";
			txtTen.Size = new System.Drawing.Size(145, 23);
			txtTen.TabIndex = 47;
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(17, 99);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(72, 16);
			label3.TabIndex = 46;
			label3.Text = "Pixel Ratio:";
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(17, 66);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(72, 16);
			label2.TabIndex = 46;
			label2.Text = "Kích thước:";
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(17, 32);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(35, 16);
			label1.TabIndex = 46;
			label1.Text = "Tên:";
			btnHuy.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnHuy.BackColor = System.Drawing.Color.FromArgb(128, 64, 0);
			btnHuy.Cursor = System.Windows.Forms.Cursors.Hand;
			btnHuy.FlatAppearance.BorderSize = 0;
			btnHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnHuy.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnHuy.ForeColor = System.Drawing.Color.White;
			btnHuy.Location = new System.Drawing.Point(148, 136);
			btnHuy.Name = "btnHuy";
			btnHuy.Size = new System.Drawing.Size(92, 29);
			btnHuy.TabIndex = 45;
			btnHuy.Text = "Hủy";
			btnHuy.UseVisualStyleBackColor = false;
			btnHuy.Click += new System.EventHandler(btnHuy_Click);
			btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnSave.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
			btnSave.FlatAppearance.BorderSize = 0;
			btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnSave.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnSave.ForeColor = System.Drawing.Color.White;
			btnSave.Location = new System.Drawing.Point(47, 136);
			btnSave.Name = "btnSave";
			btnSave.Size = new System.Drawing.Size(92, 29);
			btnSave.TabIndex = 45;
			btnSave.Text = "Lưu";
			btnSave.UseVisualStyleBackColor = false;
			btnSave.Click += new System.EventHandler(btnSave_Click);
			bunifuCards2.BackColor = System.Drawing.Color.White;
			bunifuCards2.BorderRadius = 0;
			bunifuCards2.BottomSahddow = true;
			bunifuCards2.color = System.Drawing.Color.SaddleBrown;
			bunifuCards2.Controls.Add(pnlHeader);
			bunifuCards2.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards2.LeftSahddow = false;
			bunifuCards2.Location = new System.Drawing.Point(0, 0);
			bunifuCards2.Name = "bunifuCards2";
			bunifuCards2.RightSahddow = true;
			bunifuCards2.ShadowDepth = 20;
			bunifuCards2.Size = new System.Drawing.Size(742, 37);
			bunifuCards2.TabIndex = 43;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button2);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(lblTitle);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(742, 31);
			pnlHeader.TabIndex = 9;
			button2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.FlatAppearance.BorderSize = 0;
			button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button2.ForeColor = System.Drawing.Color.White;
			button2.Image = maxcare.Properties.Resources.btnMinimize_Image;
			button2.Location = new System.Drawing.Point(711, 1);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(30, 30);
			button2.TabIndex = 77;
			button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Location = new System.Drawing.Point(899, 1);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(30, 30);
			btnMinimize.TabIndex = 9;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			lblTitle.BackColor = System.Drawing.Color.Transparent;
			lblTitle.Cursor = System.Windows.Forms.Cursors.SizeAll;
			lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
			lblTitle.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			lblTitle.ForeColor = System.Drawing.Color.Black;
			lblTitle.Location = new System.Drawing.Point(0, 0);
			lblTitle.Name = "lblTitle";
			lblTitle.Size = new System.Drawing.Size(742, 31);
			lblTitle.TabIndex = 12;
			lblTitle.Text = "Danh sách Kích thước Chrome";
			lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = lblTitle;
			bunifuDragControl1.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 200;
			toolTip1.ReshowDelay = 40;
			txtPixelRatio.Location = new System.Drawing.Point(95, 96);
			txtPixelRatio.Name = "txtPixelRatio";
			txtPixelRatio.Size = new System.Drawing.Size(59, 23);
			txtPixelRatio.TabIndex = 47;
			txtPixelRatio.Text = "3";
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(744, 388);
			base.Controls.Add(panel1);
			base.Controls.Add(bunifuCards1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fThemSizeChrome";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình chung";
			base.Load += new System.EventHandler(FConfigGenneral_Load);
			panel1.ResumeLayout(false);
			grDanhSach.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dtgvDanhSach).EndInit();
			grChiTiet.ResumeLayout(false);
			grChiTiet.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudHeight).EndInit();
			((System.ComponentModel.ISupportInitialize)nudWidth).EndInit();
			bunifuCards2.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
		}
	}
}
