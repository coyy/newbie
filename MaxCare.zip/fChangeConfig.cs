using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using MCommon;
using MetroFramework;
using MetroFramework.Controls;

namespace maxcare
{
	public class fChangeConfig : Form
	{
		private JSON_Settings settings;

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private MetroContextMenu ctmsAcc;

		private ToolStripMenuItem chọnLiveToolStripMenuItem;

		private ToolStripMenuItem liveToolStripMenuItem;

		private ToolStripMenuItem dieToolStripMenuItem;

		private ToolStripMenuItem checkpointToolStripMenuItem;

		private ToolStripMenuItem changePasswordToolStripMenuItem;

		private ToolStripMenuItem mởTrìnhDuyệtToolStripMenuItem;

		private ToolStripMenuItem copyToolStripMenuItem;

		private ToolStripMenuItem tokenToolStripMenuItem;

		private ToolStripMenuItem cookieToolStripMenuItem;

		private ToolStripMenuItem uidPassToolStripMenuItem;

		private ToolStripMenuItem uidPassTokenCookieToolStripMenuItem;

		private ToolStripMenuItem xóaTàiKhoảnToolStripMenuItem;

		private ToolStripMenuItem danhSáchChọnToolStripMenuItem;

		private ToolStripMenuItem danhSáchKhôngChọnToolStripMenuItem;

		private ToolStripMenuItem chuyểnThưMụcToolStripMenuItem;

		private ToolStripMenuItem checkCookieToolStripMenuItem;

		private ToolStripMenuItem backupToolStripMenuItem;

		private ToolStripMenuItem tấtCảToolStripMenuItem;

		private ToolStripMenuItem bỏChọnTấtCảToolStripMenuItem;

		private ToolStripMenuItem uidToolStripMenuItem;

		private ToolStripMenuItem passToolStripMenuItem;

		private ToolStripMenuItem thêmVàoThưMụcToolStripMenuItem;

		private ToolStripMenuItem giữNguyênỞThưMụcCũToolStripMenuItem;

		private ToolStripMenuItem mnsCutAccount;

		private ToolStripMenuItem đăngNhậpProfileToolStripMenuItem;

		private ToolStripMenuItem cookieToolStripMenuItem1;

		private ToolStripMenuItem uidPassToolStripMenuItem1;

		private ToolStripMenuItem đăngNhậpTrìnhDuyệtMớiToolStripMenuItem;

		private ToolStripMenuItem cookieToolStripMenuItem2;

		private ToolStripMenuItem uidPassToolStripMenuItem2;

		private ToolStripMenuItem kiểmTraCookieToolStripMenuItem;

		private ToolStripMenuItem kiểmTraTokenToolStripMenuItem;

		private ToolStripMenuItem tảiLạiDanhSáchToolStripMenuItem;

		private ToolStripMenuItem kiểmTraTàiKhoảnToolStripMenuItem;

		private ToolStripMenuItem cậpNhậtDữLiệuToolStripMenuItem;

		private ToolStripMenuItem mậtKhẩuToolStripMenuItem1;

		private ToolStripMenuItem nhậpDữLiệuToolStripMenuItem;

		private ToolStripMenuItem tokenToolStripMenuItem2;

		private ToolStripMenuItem tựĐộngLấyToolStripMenuItem1;

		private ToolStripMenuItem tokenBussinessToolStripMenuItem;

		private ToolStripMenuItem tokenInstagramToolStripMenuItem1;

		private ToolStripMenuItem tokenIosToolStripMenuItem;

		private ToolStripMenuItem tokenAndroidToolStripMenuItem1;

		private ToolStripMenuItem nhậpDữLiệuToolStripMenuItem2;

		private ToolStripMenuItem cookieToolStripMenuItem3;

		private ToolStripMenuItem tựĐộngLấyToolStripMenuItem;

		private ToolStripMenuItem nhậpDữLiệuToolStripMenuItem1;

		private ToolStripMenuItem mởCheckpointToolStripMenuItem;

		private ToolStripMenuItem backupTokenToolStripMenuItem;

		private ToolStripMenuItem backupCookieToolStripMenuItem;

		private ToolStripMenuItem backupCookieTrungGianToolStripMenuItem;

		private ToolStripMenuItem chứcNăngToolStripMenuItem1;

		private GroupBox groupBox3;

		private GroupBox groupBox5;

		private Label label10;

		private NumericUpDown nudThread;

		private Label label11;

		private Label label4;

		private Label label12;

		private ToolTip toolTip1;

		private Panel panel2;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private PictureBox pictureBox1;

		private Button btnMinimize;

		private BunifuCustomLabel bunifuCustomLabel1;

		private Panel plDoiMatKhau;

		private Button btnNhapPass;

		private Panel plDoiAnhBia;

		private RadioButton rdAnhNguoiDungDat;

		private RadioButton rdAnhNgheThuat;

		private Button btnCapNhatThongTin;

		private CheckBox ckbThemMoTa;

		private Button btnThemMoTa;

		private CheckBox ckbDoiPass;

		private CheckBox ckbCapNhatThongTin;

		private CheckBox ckbDoiTen;

		private CheckBox ckbDoiAnhBia;

		private CheckBox ckbDoiAvatar;

		private Panel plDoiTen;

		private Panel plTenTuDat;

		private Button button8;

		private Button button7;

		private Button button6;

		private RadioButton rdTenTuDat;

		private RadioButton rdTenRandom;

		private Panel plTenNgauNhien;

		private RadioButton rdTenRandomNgoai;

		private RadioButton rdTenRandomViet;

		private CheckBox ckbDoiNgonNgu;

		private ComboBox cbbNgonNgu;

		private CheckBox ckbAddPhone;

		private TextBox txtPhone;

		private RadioButton rdPassRandom;

		private RadioButton rdPassTuNhap;

		private Panel pl2fa;

		private RadioButton rdTat2fa;

		private RadioButton rdBat2fa;

		private CheckBox ckb2fa;

		private MetroTextBox txtPathAvatar;

		private Panel panel1;

		private NumericUpDown nudNamFrom;

		private NumericUpDown nudNamTo;

		private NumericUpDown nudThangTo;

		private NumericUpDown nudNgayTo;

		private NumericUpDown nudThangFrom;

		private NumericUpDown nudNgayFrom;

		private Label label13;

		private Label label7;

		private Label label3;

		private Label label9;

		private Label label6;

		private Label label2;

		private Label label8;

		private Label label5;

		private Label label1;

		private CheckBox ckbDoiNgaySinh;

		private MetroTextBox txtPathCover;

		private Button button4;

		private Button button3;

		private Button button9;

		private Button button5;

		private Panel panel3;

		private Panel plDoiMail;

		private Button btnNhapHotmail;

		private CheckBox ckbAddMail;

		private CheckBox ckbLogOut;

		private Panel plXoaMail;

		private Panel plXoaMailLinkHacked;

		private Label lblNewPass1;

		private CheckBox ckbPassRandomXoaMail;

		private Button btnNhapPassXoaMail;

		private RadioButton rdXoaTrucTiep;

		private RadioButton rdXoaLinkHacked;

		private CheckBox ckbXoaMail;

		private MetroButton metroButton1;

		private Button btnCancel;

		private Button btnAdd;

		private CheckBox ckbAutoDeleteFile;

		private CheckBox ckbXoaSdt;

		private Label label14;

		private Panel panel4;

		private RadioButton rbLoginUidPass;

		private RadioButton rbLoginCookie;

		private CheckBox ckbCreateProfile;

		private Label label15;

		private CheckBox ckbCloseChrome;

		private Button button1;

		private CheckBox ckbVerify;

		private CheckBox ckbChangePassLinkHacked;

		private CheckBox ckbMailVip;

		private Panel plAvatar;

		private CheckBox ckbAvatarThuTu;

		private Label label16;

		private CheckBox ckbCoverThuTu;

		private Panel panel5;

		private RadioButton rbNu;

		private RadioButton rbNam;

		private CheckBox ckbGioiTinh;

		private Panel panel7;

		private RadioButton rbLoginWWW;

		private RadioButton rbLoginMFB;

		private Label label17;

		private CheckBox ckbXoaMailCu2;

		private CheckBox ckbAnMailAll;

		private CheckBox ckbAnMailMoi;

		private CheckBox ckbXoaMailCu;

		private CheckBox ckbXoaThietBiTinCay;

		private CheckBox ckbAddMailLinkHacked;

		private Panel plPassMailHacked;

		private Label label18;

		private CheckBox ckbRandomPassMailHacked;

		private MetroTextBox txtPassMailHacked;

		private Button button2;

		public fChangeConfig()
		{
			InitializeComponent();
			Load_cbbNgonNgu();
			settings = new JSON_Settings("configChange");
			LoadSettings();
			CheckedChangedFull();
			ChangeLanguage();
		}

		private void Load_cbbNgonNgu()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> listCountryCountryCode = SetupFolder.GetListCountryCountryCode();
			for (int i = 0; i < listCountryCountryCode.Count; i++)
			{
				string[] array = listCountryCountryCode[i].Split('|');
				dictionary.Add(array[0], array[1]);
			}
			cbbNgonNgu.DataSource = new BindingSource(dictionary, null);
			cbbNgonNgu.ValueMember = "Key";
			cbbNgonNgu.DisplayMember = "Value";
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(groupBox5);
			Language.GetValue(label10);
			Language.GetValue(label11);
			Language.GetValue(label14);
			Language.GetValue(label12);
			Language.GetValue(metroButton1);
			Language.GetValue(ckbCreateProfile);
			Language.GetValue(groupBox3);
			Language.GetValue(ckbDoiNgonNgu);
			Language.GetValue(ckbAddPhone);
			Language.GetValue(ckbDoiAvatar);
			Language.GetValue(ckbDoiAnhBia);
			Language.GetValue(ckbAutoDeleteFile);
			Language.GetValue(rdAnhNguoiDungDat);
			Language.GetValue(rdAnhNgheThuat);
			Language.GetValue(ckbThemMoTa);
			Language.GetValue(btnThemMoTa);
			Language.GetValue(ckbDoiNgaySinh);
			Language.GetValue(label1);
			Language.GetValue(label2);
			Language.GetValue(label3);
			Language.GetValue(label5);
			Language.GetValue(label6);
			Language.GetValue(label7);
			Language.GetValue(label8);
			Language.GetValue(label9);
			Language.GetValue(label13);
			Language.GetValue(ckbCapNhatThongTin);
			Language.GetValue(btnCapNhatThongTin);
			Language.GetValue(button3);
			Language.GetValue(button4);
			Language.GetValue(button5);
			Language.GetValue(button9);
			Language.GetValue(ckbAddMail);
			Language.GetValue(btnNhapHotmail);
			Language.GetValue(ckbAnMailMoi);
			Language.GetValue(ckbXoaMailCu);
			Language.GetValue(ckbDoiTen);
			Language.GetValue(rdTenTuDat);
			Language.GetValue(button6);
			Language.GetValue(button7);
			Language.GetValue(button8);
			Language.GetValue(rdTenRandom);
			Language.GetValue(rdTenRandomViet);
			Language.GetValue(rdTenRandomNgoai);
			Language.GetValue(ckb2fa);
			Language.GetValue(rdBat2fa);
			Language.GetValue(rdTat2fa);
			Language.GetValue(ckbDoiPass);
			Language.GetValue(rdPassTuNhap);
			Language.GetValue(btnNhapPass);
			Language.GetValue(rdPassRandom);
			Language.GetValue(ckbXoaSdt);
			Language.GetValue(ckbLogOut);
			Language.GetValue(btnAdd);
			Language.GetValue(btnCancel);
		}

		private void LoadSettings()
		{
			nudThread.Value = settings.GetValueInt("change_nudThread", 3);
			ckbVerify.Checked = settings.GetValueBool("change_ckbVerify");
			ckbDoiNgonNgu.Checked = settings.GetValueBool("change_ckbDoiNgonNgu");
			cbbNgonNgu.SelectedValue = settings.GetValue("change_cbbNgonNgu", "vi_VN");
			ckbAddPhone.Checked = settings.GetValueBool("change_ckbAddPhone");
			txtPhone.Text = settings.GetValue("change_txtPhone", "09xxxxxxxx");
			txtPathAvatar.Text = settings.GetValue("change_txtPathAvatar");
			txtPathCover.Text = settings.GetValue("change_txtPathCover");
			ckbDoiAvatar.Checked = settings.GetValueBool("change_ckbDoiAvatar");
			ckbAvatarThuTu.Checked = settings.GetValueBool("change_ckbAvatarThuTu");
			ckbDoiAnhBia.Checked = settings.GetValueBool("change_ckbDoiAnhBia");
			if (settings.GetValueInt("change_typeUpCover") == 0)
			{
				rdAnhNguoiDungDat.Checked = true;
			}
			else
			{
				rdAnhNgheThuat.Checked = true;
			}
			ckbCoverThuTu.Checked = settings.GetValueBool("change_ckbCoverThuTu");
			ckbThemMoTa.Checked = settings.GetValueBool("change_ckbThemMoTa");
			ckbCapNhatThongTin.Checked = settings.GetValueBool("change_ckbCapNhatThongTin");
			ckbDoiNgaySinh.Checked = settings.GetValueBool("change_ckbDoiNgaySinh");
			nudNgayFrom.Value = settings.GetValueInt("change_nudNgayFrom", 1);
			nudNgayTo.Value = settings.GetValueInt("change_nudNgayTo", 30);
			nudThangFrom.Value = settings.GetValueInt("change_nudThangFrom", 1);
			nudThangTo.Value = settings.GetValueInt("change_nudThangTo", 12);
			nudNamFrom.Value = settings.GetValueInt("change_nudNamFrom", 1980);
			nudNamTo.Value = settings.GetValueInt("change_nudNamTo", 2000);
			ckbGioiTinh.Checked = settings.GetValueBool("change_ckbGioiTinh");
			switch (settings.GetValueInt("change_typeGioiTinh"))
			{
			case 0:
				rbNu.Checked = true;
				break;
			case 1:
				rbNam.Checked = true;
				break;
			}
			ckbDoiTen.Checked = settings.GetValueBool("change_ckbDoiTen");
			if (settings.GetValueInt("change_typeDatTen") == 0)
			{
				rdTenTuDat.Checked = true;
			}
			else
			{
				rdTenRandom.Checked = true;
			}
			if (settings.GetValueInt("change_typeTenRandom") == 0)
			{
				rdTenRandomViet.Checked = true;
			}
			else
			{
				rdTenRandomNgoai.Checked = true;
			}
			ckbDoiPass.Checked = settings.GetValueBool("change_ckbDoiPass");
			if (settings.GetValueInt("change_typeDoiPass") == 0)
			{
				rdPassTuNhap.Checked = true;
			}
			else
			{
				rdPassRandom.Checked = true;
			}
			ckbChangePassLinkHacked.Checked = settings.GetValueBool("change_ckbDoiPassUseLinkHacked");
			ckb2fa.Checked = settings.GetValueBool("change_ckb2fa");
			if (settings.GetValueInt("change_type2fa") == 0)
			{
				rdBat2fa.Checked = true;
			}
			else
			{
				rdTat2fa.Checked = true;
			}
			ckbAddMail.Checked = settings.GetValueBool("ckbAddMail");
			ckbMailVip.Checked = settings.GetValueBool("ckbMailVip");
			ckbXoaMailCu.Checked = settings.GetValueBool("ckbXoaMailCu");
			ckbAnMailMoi.Checked = settings.GetValueBool("ckbAnMailMoi");
			ckbCloseChrome.Checked = settings.GetValueBool("ckbCloseChrome");
			ckbAddMailLinkHacked.Checked = settings.GetValueBool("ckbAddMailLinkHacked");
			txtPassMailHacked.Text = settings.GetValue("txtPassMailHacked");
			ckbRandomPassMailHacked.Checked = settings.GetValueBool("ckbRandomPassMailHacked");
			ckbAnMailAll.Checked = settings.GetValueBool("ckbAnMailAll");
			ckbXoaMailCu2.Checked = settings.GetValueBool("ckbXoaMailCu2");
			ckbLogOut.Checked = settings.GetValueBool("ckbLogOut");
			ckbXoaSdt.Checked = settings.GetValueBool("ckbXoaSdt");
			ckbXoaMail.Checked = settings.GetValueBool("ckbXoaMail");
			int valueInt = settings.GetValueInt("xoaMail");
			if (valueInt == 1)
			{
				rdXoaLinkHacked.Checked = true;
			}
			else
			{
				rdXoaTrucTiep.Checked = true;
			}
			ckbPassRandomXoaMail.Checked = settings.GetValueBool("ckbPassRandomXoaMail");
			ckbAutoDeleteFile.Checked = settings.GetValueBool("ckbAutoDeleteFile");
			if (settings.GetValueInt("typeLogin") == 0)
			{
				rbLoginUidPass.Checked = true;
			}
			else
			{
				rbLoginCookie.Checked = true;
			}
			if (settings.GetValueInt("typeBrowserLogin") == 0)
			{
				rbLoginMFB.Checked = true;
			}
			else
			{
				rbLoginWWW.Checked = true;
			}
			ckbCreateProfile.Checked = settings.GetValueBool("ckbCreateProfile");
			ckbXoaThietBiTinCay.Checked = settings.GetValueBool("change_ckbXoaThietBiTinCay");
		}

		private void SaveSettings()
		{
			settings.Update("change_nudThread", Convert.ToInt32(nudThread.Value));
			settings.Update("change_ckbVerify", ckbVerify.Checked);
			settings.Update("change_ckbDoiNgonNgu", ckbDoiNgonNgu.Checked);
			settings.Update("change_cbbNgonNgu", cbbNgonNgu.SelectedValue);
			settings.Update("change_ckbAddPhone", ckbAddPhone.Checked);
			settings.Update("change_txtPhone", txtPhone.Text);
			settings.Update("change_txtPathAvatar", txtPathAvatar.Text);
			settings.Update("change_ckbAvatarThuTu", ckbAvatarThuTu.Checked);
			settings.Update("change_txtPathCover", txtPathCover.Text);
			settings.Update("change_ckbDoiAvatar", ckbDoiAvatar.Checked);
			settings.Update("change_ckbDoiAnhBia", ckbDoiAnhBia.Checked);
			int num = 0;
			if (rdAnhNgheThuat.Checked)
			{
				num = 1;
			}
			settings.Update("change_typeUpCover", num);
			settings.Update("change_ckbThemMoTa", ckbThemMoTa.Checked);
			settings.Update("change_ckbCapNhatThongTin", ckbCapNhatThongTin.Checked);
			settings.Update("change_ckbCoverThuTu", ckbCoverThuTu.Checked);
			settings.Update("change_ckbDoiNgaySinh", ckbDoiNgaySinh.Checked);
			settings.Update("change_nudNgayFrom", Convert.ToInt32(nudNgayFrom.Value));
			settings.Update("change_nudNgayTo", Convert.ToInt32(nudNgayTo.Value));
			settings.Update("change_nudThangFrom", Convert.ToInt32(nudThangFrom.Value));
			settings.Update("change_nudThangTo", Convert.ToInt32(nudThangTo.Value));
			settings.Update("change_nudNamFrom", Convert.ToInt32(nudNamFrom.Value));
			settings.Update("change_nudNamTo", Convert.ToInt32(nudNamTo.Value));
			settings.Update("change_ckbGioiTinh", ckbGioiTinh.Checked);
			int num2 = 0;
			if (rbNam.Checked)
			{
				num2 = 1;
			}
			settings.Update("change_typeGioiTinh", num2);
			settings.Update("change_ckbDoiTen", ckbDoiTen.Checked);
			int num3 = 0;
			if (rdTenRandom.Checked)
			{
				num3 = 1;
			}
			settings.Update("change_typeDatTen", num3);
			int num4 = 0;
			if (rdTenRandomNgoai.Checked)
			{
				num4 = 1;
			}
			settings.Update("change_typeTenRandom", num4);
			settings.Update("change_ckbDoiPass", ckbDoiPass.Checked);
			int num5 = 0;
			if (rdPassRandom.Checked)
			{
				num5 = 1;
			}
			settings.Update("change_typeDoiPass", num5);
			settings.Update("change_ckbDoiPassUseLinkHacked", ckbChangePassLinkHacked.Checked);
			settings.Update("change_ckb2fa", ckb2fa.Checked);
			int num6 = 0;
			if (rdTat2fa.Checked)
			{
				num6 = 1;
			}
			settings.Update("change_type2fa", num6);
			settings.Update("ckbAddMail", ckbAddMail.Checked.ToString());
			settings.Update("themMail", 1);
			settings.Update("ckbMailVip", ckbMailVip.Checked.ToString());
			settings.Update("ckbXoaMailCu", ckbXoaMailCu.Checked.ToString());
			settings.Update("ckbAnMailMoi", ckbAnMailMoi.Checked.ToString());
			settings.Update("ckbCloseChrome", ckbCloseChrome.Checked.ToString());
			settings.Update("ckbAddMailLinkHacked", ckbAddMailLinkHacked.Checked.ToString());
			settings.Update("txtPassMailHacked", txtPassMailHacked.Text.Trim());
			settings.Update("ckbRandomPassMailHacked", ckbRandomPassMailHacked.Checked);
			settings.Update("ckbAnMailAll", ckbAnMailAll.Checked);
			settings.Update("ckbXoaMailCu2", ckbXoaMailCu2.Checked);
			settings.Update("ckbLogOut", ckbLogOut.Checked.ToString());
			settings.Update("ckbXoaSdt", ckbXoaSdt.Checked);
			settings.Update("ckbXoaMail", ckbXoaMail.Checked);
			int num7 = 0;
			if (rdXoaLinkHacked.Checked)
			{
				num7 = 1;
			}
			settings.Update("xoaMail", num7.ToString());
			settings.Update("ckbPassRandomXoaMail", ckbPassRandomXoaMail.Checked);
			settings.Update("ckbAutoDeleteFile", ckbAutoDeleteFile.Checked);
			if (rbLoginUidPass.Checked)
			{
				settings.Update("typeLogin", 0);
			}
			else
			{
				settings.Update("typeLogin", 1);
			}
			int num8 = ((!rbLoginMFB.Checked) ? 1 : 0);
			settings.Update("typeBrowserLogin", num8);
			settings.Update("ckbCreateProfile", ckbCreateProfile.Checked);
			settings.Update("change_ckbXoaThietBiTinCay", ckbXoaThietBiTinCay.Checked);
			settings.Save();
		}

		private void BtnMinimize_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void fShareConfig_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		private void btnOpenShare_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fCauHinhChung());
		}

		private void groupBox5_Enter(object sender, EventArgs e)
		{
		}

		private void ChứcNăngToolStripMenuItem1_Click(object sender, EventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				SaveSettings();
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Lưu thành công, ba\u0323n co\u0301 muô\u0301n đo\u0301ng cư\u0309a sô\u0309?")) == DialogResult.Yes)
				{
					Close();
				}
			}
			catch
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng thử lại sau!"), 2);
			}
		}

		private void CheckedChangedFull()
		{
			ckbDoiNgonNgu_CheckedChanged(null, null);
			ckbAddPhone_CheckedChanged(null, null);
			ckbDoiAvatar_CheckedChanged(null, null);
			ckbDoiAnhBia_CheckedChanged(null, null);
			rdAnhNguoiDungDat_CheckedChanged(null, null);
			ckbThemMoTa_CheckedChanged(null, null);
			ckbCapNhatThongTin_CheckedChanged(null, null);
			ckbDoiTen_CheckedChanged(null, null);
			rdTenTuDat_CheckedChanged(null, null);
			rdTenRandom_CheckedChanged(null, null);
			ckbDoiPass_CheckedChanged(null, null);
			rdPassTuNhap_CheckedChanged(null, null);
			ckb2fa_CheckedChanged(null, null);
			checkBox1_CheckedChanged(null, null);
			ckbAddMail_CheckedChanged(null, null);
			rdXoaLinkHacked_CheckedChanged(null, null);
			ckbXoaMail_CheckedChanged(null, null);
			ckbPassRandomXoaMail_CheckedChanged(null, null);
			ckbCloseChrome_CheckedChanged(null, null);
			ckbGioiTinh_CheckedChanged(null, null);
			ckbGiaiCheckPoint_CheckedChanged(null, null);
			ckbAnMailMoi_CheckedChanged(null, null);
			ckbXoaMailCu_CheckedChanged(null, null);
			ckbAnMailAll_CheckedChanged(null, null);
			ckbXoaMailCu2_CheckedChanged(null, null);
			ckbAddMailLinkHacked_CheckedChanged(null, null);
			ckbRandomPassMailHacked_CheckedChanged(null, null);
		}

		private void ckbDoiNgonNgu_CheckedChanged(object sender, EventArgs e)
		{
			cbbNgonNgu.Enabled = ckbDoiNgonNgu.Checked;
		}

		private void ckbAddPhone_CheckedChanged(object sender, EventArgs e)
		{
			txtPhone.Enabled = ckbAddPhone.Checked;
		}

		private void ckbDoiAvatar_CheckedChanged(object sender, EventArgs e)
		{
			plAvatar.Enabled = ckbDoiAvatar.Checked;
		}

		private void ckbDoiAnhBia_CheckedChanged(object sender, EventArgs e)
		{
			plDoiAnhBia.Enabled = ckbDoiAnhBia.Checked;
		}

		private void rdAnhNguoiDungDat_CheckedChanged(object sender, EventArgs e)
		{
			txtPathCover.Enabled = rdAnhNguoiDungDat.Checked;
		}

		private void ckbThemMoTa_CheckedChanged(object sender, EventArgs e)
		{
			btnThemMoTa.Enabled = ckbThemMoTa.Checked;
		}

		private void ckbCapNhatThongTin_CheckedChanged(object sender, EventArgs e)
		{
			panel3.Enabled = ckbCapNhatThongTin.Checked;
		}

		private void ckbDoiTen_CheckedChanged(object sender, EventArgs e)
		{
			plDoiTen.Enabled = ckbDoiTen.Checked;
		}

		private void rdTenTuDat_CheckedChanged(object sender, EventArgs e)
		{
			plTenTuDat.Enabled = rdTenTuDat.Checked;
		}

		private void rdTenRandom_CheckedChanged(object sender, EventArgs e)
		{
			plTenNgauNhien.Enabled = rdTenRandom.Checked;
		}

		private void ckbDoiPass_CheckedChanged(object sender, EventArgs e)
		{
			plDoiMatKhau.Enabled = ckbDoiPass.Checked;
		}

		private void rdPassTuNhap_CheckedChanged(object sender, EventArgs e)
		{
			btnNhapPass.Enabled = rdPassTuNhap.Checked;
		}

		private void btnOpenAvatar_Click(object sender, EventArgs e)
		{
			txtPathAvatar.Text = MCommon.Common.SelectFolder();
		}

		private void btnAnhNguoiDungDat_Click(object sender, EventArgs e)
		{
			Process.Start("configschange\\anhbia");
		}

		private void btnThemMoTa_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fNhapDuLieu2("configschange\\tieusu", Language.GetValue("Nhâ\u0323p danh sa\u0301ch tiê\u0309u sư\u0309")));
		}

		private void btnCapNhatThongTin_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\thongtincanhan\\NoiLamViec.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Nơi la\u0300m viê\u0323c"), Language.GetValue("Danh sa\u0301ch tư\u0300 kho\u0301a"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button6_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\doiten\\ho.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Ho\u0323"), Language.GetValue("Danh sa\u0301ch Ho\u0323"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button7_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\doiten\\tendem.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Tên đê\u0323m"), Language.GetValue("Danh sa\u0301ch Tên đê\u0323m"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button8_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\doiten\\ten.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Tên"), Language.GetValue("Danh sa\u0301ch Tên"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void btnNhapPass_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\doimk.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch mâ\u0323t khâ\u0309u câ\u0300n đô\u0309i"), Language.GetValue("Danh sa\u0301ch mâ\u0323t khâ\u0309u"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void ckb2fa_CheckedChanged(object sender, EventArgs e)
		{
			pl2fa.Enabled = ckb2fa.Checked;
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			panel1.Enabled = ckbDoiNgaySinh.Checked;
		}

		private void btnOpenCover_Click(object sender, EventArgs e)
		{
			txtPathCover.Text = MCommon.Common.SelectFolder();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\thongtincanhan\\QueQuan.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Quê qua\u0301n"), Language.GetValue("Danh sa\u0301ch tư\u0300 kho\u0301a"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button4_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\thongtincanhan\\ThanhPho.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Tha\u0300nh phô\u0301"), Language.GetValue("Danh sa\u0301ch tư\u0300 kho\u0301a"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button5_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\thongtincanhan\\TruongDH.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Trươ\u0300ng ĐH"), Language.GetValue("Danh sa\u0301ch tư\u0300 kho\u0301a"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void button9_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\thongtincanhan\\TruongTHPT.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch Trươ\u0300ng THPT"), Language.GetValue("Danh sa\u0301ch tư\u0300 kho\u0301a"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void btnNhapHotmail_Click(object sender, EventArgs e)
		{
			MCommon.Common.CreateFolder("configschange\\addmail");
			MCommon.Common.ShowForm(new fNhapMailAdd());
		}

		private void ckbAddMail_CheckedChanged(object sender, EventArgs e)
		{
			plDoiMail.Enabled = ckbAddMail.Checked;
			ckbXoaMailCu2.Enabled = !ckbAddMail.Checked;
			ckbAnMailAll.Enabled = !ckbAddMail.Checked;
		}

		private void btnNhapPassXoaMail_Click(object sender, EventArgs e)
		{
			MCommon.Common.OpenFileAndPressData("configschange\\doimk2.txt", Language.GetValue("Nhâ\u0323p danh sa\u0301ch mâ\u0323t khâ\u0309u mơ\u0301i"), Language.GetValue("Danh sa\u0301ch mâ\u0323t khâ\u0309u"), Language.GetValue("(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void ckbXoaMail_CheckedChanged(object sender, EventArgs e)
		{
			plXoaMail.Enabled = ckbXoaMail.Checked;
			if (ckbXoaMail.Checked && ckbAddMail.Checked && ckbXoaMailCu.Checked)
			{
				ckbXoaMailCu.Checked = false;
			}
		}

		private void rdXoaLinkHacked_CheckedChanged(object sender, EventArgs e)
		{
			plXoaMailLinkHacked.Enabled = rdXoaLinkHacked.Checked;
			if (rdXoaLinkHacked.Checked)
			{
				ckbDoiPass.Checked = false;
			}
		}

		private void ckbPassRandomXoaMail_CheckedChanged(object sender, EventArgs e)
		{
			btnNhapPassXoaMail.Enabled = !ckbPassRandomXoaMail.Checked;
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			if ((e as MouseEventArgs).Button == MouseButtons.Right && Control.ModifierKeys == Keys.Control)
			{
				ckbAutoDeleteFile.Visible = true;
			}
		}

		private void ckbCloseChrome_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void button1_Click(object sender, EventArgs e)
		{
			MCommon.Common.CreateFolder("configschange\\verify");
			MCommon.Common.ShowForm(new fNhapDuLieu1("configschange\\verify\\hotmail.txt", "Nhâ\u0323p danh sa\u0301ch hotmail/outlook dùng để verify", "Danh sa\u0301ch email|pass mail", "(Mô\u0303i nô\u0323i dung 1 do\u0300ng)"));
		}

		private void ckbVerify_CheckedChanged(object sender, EventArgs e)
		{
			button1.Enabled = ckbVerify.Checked;
		}

		private void ckbGioiTinh_CheckedChanged(object sender, EventArgs e)
		{
			panel5.Enabled = ckbGioiTinh.Checked;
		}

		private void ckbGiaiCheckPoint_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void btnConfigCheckpoint_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fCheckPoint());
		}

		private void groupBox3_Enter(object sender, EventArgs e)
		{
		}

		private void plDoiMail_Paint(object sender, PaintEventArgs e)
		{
		}

		private void ckbAnMailMoi_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbXoaMailCu_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbAnMailAll_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbXoaMailCu2_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbAddMailLinkHacked_CheckedChanged(object sender, EventArgs e)
		{
			plPassMailHacked.Enabled = ckbAddMailLinkHacked.Checked;
		}

		private void ckbRandomPassMailHacked_CheckedChanged(object sender, EventArgs e)
		{
			txtPassMailHacked.Enabled = !ckbRandomPassMailHacked.Checked;
		}

		private void plDoiMatKhau_Paint(object sender, PaintEventArgs e)
		{
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			string s = "Có thể sử dụng ký tự * để random 1 ký tự ngẫu nhiên!\r\nVí dụ: MIN****** => MINdfghta";
			MessageBoxHelper.ShowMessageBox(s);
		}

		private void panel2_Paint(object sender, PaintEventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fChangeConfig));
			ctmsAcc = new MetroFramework.Controls.MetroContextMenu(components);
			chọnLiveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			bỏChọnTấtCảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			mởTrìnhDuyệtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			xóaTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			chuyểnThưMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			checkCookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			mởCheckpointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			thêmVàoThưMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			tảiLạiDanhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			cậpNhậtDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			chứcNăngToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			tấtCảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			liveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			dieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			checkpointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			đăngNhậpProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			cookieToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			uidPassToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			đăngNhậpTrìnhDuyệtMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			cookieToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			uidPassToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			tokenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			cookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			uidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			passToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			uidPassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			uidPassTokenCookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			danhSáchChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			danhSáchKhôngChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			giữNguyênỞThưMụcCũToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			mnsCutAccount = new System.Windows.Forms.ToolStripMenuItem();
			kiểmTraTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			kiểmTraCookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			kiểmTraTokenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			backupTokenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			backupCookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			backupCookieTrungGianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			mậtKhẩuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			nhậpDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			tokenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			tựĐộngLấyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			tokenBussinessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			tokenInstagramToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			tokenIosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			tokenAndroidToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			nhậpDữLiệuToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			cookieToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
			tựĐộngLấyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			nhậpDữLiệuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			btnMinimize = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			ckbXoaThietBiTinCay = new System.Windows.Forms.CheckBox();
			ckbXoaMailCu2 = new System.Windows.Forms.CheckBox();
			ckbAnMailAll = new System.Windows.Forms.CheckBox();
			panel5 = new System.Windows.Forms.Panel();
			rbNu = new System.Windows.Forms.RadioButton();
			rbNam = new System.Windows.Forms.RadioButton();
			ckbGioiTinh = new System.Windows.Forms.CheckBox();
			plAvatar = new System.Windows.Forms.Panel();
			ckbAvatarThuTu = new System.Windows.Forms.CheckBox();
			label16 = new System.Windows.Forms.Label();
			txtPathAvatar = new MetroFramework.Controls.MetroTextBox();
			plDoiMail = new System.Windows.Forms.Panel();
			plPassMailHacked = new System.Windows.Forms.Panel();
			txtPassMailHacked = new MetroFramework.Controls.MetroTextBox();
			label18 = new System.Windows.Forms.Label();
			ckbRandomPassMailHacked = new System.Windows.Forms.CheckBox();
			ckbAddMailLinkHacked = new System.Windows.Forms.CheckBox();
			ckbAnMailMoi = new System.Windows.Forms.CheckBox();
			ckbXoaMailCu = new System.Windows.Forms.CheckBox();
			ckbMailVip = new System.Windows.Forms.CheckBox();
			ckbCloseChrome = new System.Windows.Forms.CheckBox();
			label15 = new System.Windows.Forms.Label();
			btnNhapHotmail = new System.Windows.Forms.Button();
			ckbAddMail = new System.Windows.Forms.CheckBox();
			txtPhone = new System.Windows.Forms.TextBox();
			panel1 = new System.Windows.Forms.Panel();
			nudNamFrom = new System.Windows.Forms.NumericUpDown();
			nudNamTo = new System.Windows.Forms.NumericUpDown();
			nudThangTo = new System.Windows.Forms.NumericUpDown();
			nudNgayTo = new System.Windows.Forms.NumericUpDown();
			nudThangFrom = new System.Windows.Forms.NumericUpDown();
			nudNgayFrom = new System.Windows.Forms.NumericUpDown();
			label13 = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			panel3 = new System.Windows.Forms.Panel();
			button4 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button9 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			btnCapNhatThongTin = new System.Windows.Forms.Button();
			pl2fa = new System.Windows.Forms.Panel();
			rdTat2fa = new System.Windows.Forms.RadioButton();
			rdBat2fa = new System.Windows.Forms.RadioButton();
			plDoiMatKhau = new System.Windows.Forms.Panel();
			button2 = new System.Windows.Forms.Button();
			ckbChangePassLinkHacked = new System.Windows.Forms.CheckBox();
			btnNhapPass = new System.Windows.Forms.Button();
			rdPassRandom = new System.Windows.Forms.RadioButton();
			rdPassTuNhap = new System.Windows.Forms.RadioButton();
			plDoiAnhBia = new System.Windows.Forms.Panel();
			ckbCoverThuTu = new System.Windows.Forms.CheckBox();
			txtPathCover = new MetroFramework.Controls.MetroTextBox();
			rdAnhNguoiDungDat = new System.Windows.Forms.RadioButton();
			rdAnhNgheThuat = new System.Windows.Forms.RadioButton();
			ckbThemMoTa = new System.Windows.Forms.CheckBox();
			btnThemMoTa = new System.Windows.Forms.Button();
			ckbDoiNgaySinh = new System.Windows.Forms.CheckBox();
			ckb2fa = new System.Windows.Forms.CheckBox();
			ckbXoaSdt = new System.Windows.Forms.CheckBox();
			ckbLogOut = new System.Windows.Forms.CheckBox();
			ckbDoiPass = new System.Windows.Forms.CheckBox();
			ckbCapNhatThongTin = new System.Windows.Forms.CheckBox();
			ckbDoiTen = new System.Windows.Forms.CheckBox();
			ckbDoiAnhBia = new System.Windows.Forms.CheckBox();
			ckbAddPhone = new System.Windows.Forms.CheckBox();
			ckbAutoDeleteFile = new System.Windows.Forms.CheckBox();
			ckbDoiAvatar = new System.Windows.Forms.CheckBox();
			plDoiTen = new System.Windows.Forms.Panel();
			plTenTuDat = new System.Windows.Forms.Panel();
			button8 = new System.Windows.Forms.Button();
			button7 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			rdTenTuDat = new System.Windows.Forms.RadioButton();
			rdTenRandom = new System.Windows.Forms.RadioButton();
			plTenNgauNhien = new System.Windows.Forms.Panel();
			rdTenRandomNgoai = new System.Windows.Forms.RadioButton();
			rdTenRandomViet = new System.Windows.Forms.RadioButton();
			ckbDoiNgonNgu = new System.Windows.Forms.CheckBox();
			cbbNgonNgu = new System.Windows.Forms.ComboBox();
			button1 = new System.Windows.Forms.Button();
			ckbVerify = new System.Windows.Forms.CheckBox();
			plXoaMail = new System.Windows.Forms.Panel();
			plXoaMailLinkHacked = new System.Windows.Forms.Panel();
			lblNewPass1 = new System.Windows.Forms.Label();
			ckbPassRandomXoaMail = new System.Windows.Forms.CheckBox();
			btnNhapPassXoaMail = new System.Windows.Forms.Button();
			rdXoaTrucTiep = new System.Windows.Forms.RadioButton();
			rdXoaLinkHacked = new System.Windows.Forms.RadioButton();
			ckbXoaMail = new System.Windows.Forms.CheckBox();
			groupBox5 = new System.Windows.Forms.GroupBox();
			panel7 = new System.Windows.Forms.Panel();
			rbLoginWWW = new System.Windows.Forms.RadioButton();
			rbLoginMFB = new System.Windows.Forms.RadioButton();
			label17 = new System.Windows.Forms.Label();
			label14 = new System.Windows.Forms.Label();
			panel4 = new System.Windows.Forms.Panel();
			rbLoginUidPass = new System.Windows.Forms.RadioButton();
			rbLoginCookie = new System.Windows.Forms.RadioButton();
			metroButton1 = new MetroFramework.Controls.MetroButton();
			label12 = new System.Windows.Forms.Label();
			label10 = new System.Windows.Forms.Label();
			nudThread = new System.Windows.Forms.NumericUpDown();
			label11 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			ckbCreateProfile = new System.Windows.Forms.CheckBox();
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			panel2 = new System.Windows.Forms.Panel();
			btnCancel = new System.Windows.Forms.Button();
			btnAdd = new System.Windows.Forms.Button();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			ctmsAcc.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox3.SuspendLayout();
			panel5.SuspendLayout();
			plAvatar.SuspendLayout();
			plDoiMail.SuspendLayout();
			plPassMailHacked.SuspendLayout();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudNamFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudNamTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudThangTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudNgayTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudThangFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudNgayFrom).BeginInit();
			panel3.SuspendLayout();
			pl2fa.SuspendLayout();
			plDoiMatKhau.SuspendLayout();
			plDoiAnhBia.SuspendLayout();
			plDoiTen.SuspendLayout();
			plTenTuDat.SuspendLayout();
			plTenNgauNhien.SuspendLayout();
			plXoaMail.SuspendLayout();
			plXoaMailLinkHacked.SuspendLayout();
			groupBox5.SuspendLayout();
			panel7.SuspendLayout();
			panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudThread).BeginInit();
			panel2.SuspendLayout();
			bunifuCards1.SuspendLayout();
			SuspendLayout();
			ctmsAcc.Items.AddRange(new System.Windows.Forms.ToolStripItem[13]
			{
				chọnLiveToolStripMenuItem, bỏChọnTấtCảToolStripMenuItem, mởTrìnhDuyệtToolStripMenuItem, copyToolStripMenuItem, xóaTàiKhoảnToolStripMenuItem, chuyểnThưMụcToolStripMenuItem, checkCookieToolStripMenuItem, backupToolStripMenuItem, mởCheckpointToolStripMenuItem, thêmVàoThưMụcToolStripMenuItem,
				tảiLạiDanhSáchToolStripMenuItem, cậpNhậtDữLiệuToolStripMenuItem, chứcNăngToolStripMenuItem1
			});
			ctmsAcc.Name = "ctmsAcc";
			ctmsAcc.Size = new System.Drawing.Size(133, 290);
			chọnLiveToolStripMenuItem.Name = "chọnLiveToolStripMenuItem";
			chọnLiveToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			bỏChọnTấtCảToolStripMenuItem.Name = "bỏChọnTấtCảToolStripMenuItem";
			bỏChọnTấtCảToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			mởTrìnhDuyệtToolStripMenuItem.Name = "mởTrìnhDuyệtToolStripMenuItem";
			mởTrìnhDuyệtToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			copyToolStripMenuItem.Name = "copyToolStripMenuItem";
			copyToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			xóaTàiKhoảnToolStripMenuItem.Name = "xóaTàiKhoảnToolStripMenuItem";
			xóaTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			chuyểnThưMụcToolStripMenuItem.Name = "chuyểnThưMụcToolStripMenuItem";
			chuyểnThưMụcToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			checkCookieToolStripMenuItem.Name = "checkCookieToolStripMenuItem";
			checkCookieToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			backupToolStripMenuItem.Name = "backupToolStripMenuItem";
			backupToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			mởCheckpointToolStripMenuItem.Name = "mởCheckpointToolStripMenuItem";
			mởCheckpointToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			thêmVàoThưMụcToolStripMenuItem.Name = "thêmVàoThưMụcToolStripMenuItem";
			thêmVàoThưMụcToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			tảiLạiDanhSáchToolStripMenuItem.Name = "tảiLạiDanhSáchToolStripMenuItem";
			tảiLạiDanhSáchToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			cậpNhậtDữLiệuToolStripMenuItem.Name = "cậpNhậtDữLiệuToolStripMenuItem";
			cậpNhậtDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			chứcNăngToolStripMenuItem1.Name = "chứcNăngToolStripMenuItem1";
			chứcNăngToolStripMenuItem1.Size = new System.Drawing.Size(132, 22);
			chứcNăngToolStripMenuItem1.Text = "Chức năng";
			chứcNăngToolStripMenuItem1.Click += new System.EventHandler(ChứcNăngToolStripMenuItem1_Click);
			tấtCảToolStripMenuItem.Name = "tấtCảToolStripMenuItem";
			tấtCảToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			liveToolStripMenuItem.Name = "liveToolStripMenuItem";
			liveToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			dieToolStripMenuItem.Name = "dieToolStripMenuItem";
			dieToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			checkpointToolStripMenuItem.Name = "checkpointToolStripMenuItem";
			checkpointToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
			changePasswordToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			đăngNhậpProfileToolStripMenuItem.Name = "đăngNhậpProfileToolStripMenuItem";
			đăngNhậpProfileToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			cookieToolStripMenuItem1.Name = "cookieToolStripMenuItem1";
			cookieToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			uidPassToolStripMenuItem1.Name = "uidPassToolStripMenuItem1";
			uidPassToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			đăngNhậpTrìnhDuyệtMớiToolStripMenuItem.Name = "đăngNhậpTrìnhDuyệtMớiToolStripMenuItem";
			đăngNhậpTrìnhDuyệtMớiToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			cookieToolStripMenuItem2.Name = "cookieToolStripMenuItem2";
			cookieToolStripMenuItem2.Size = new System.Drawing.Size(32, 19);
			uidPassToolStripMenuItem2.Name = "uidPassToolStripMenuItem2";
			uidPassToolStripMenuItem2.Size = new System.Drawing.Size(32, 19);
			tokenToolStripMenuItem.Name = "tokenToolStripMenuItem";
			tokenToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			cookieToolStripMenuItem.Name = "cookieToolStripMenuItem";
			cookieToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			uidToolStripMenuItem.Name = "uidToolStripMenuItem";
			uidToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			passToolStripMenuItem.Name = "passToolStripMenuItem";
			passToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			uidPassToolStripMenuItem.Name = "uidPassToolStripMenuItem";
			uidPassToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			uidPassTokenCookieToolStripMenuItem.Name = "uidPassTokenCookieToolStripMenuItem";
			uidPassTokenCookieToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			danhSáchChọnToolStripMenuItem.Name = "danhSáchChọnToolStripMenuItem";
			danhSáchChọnToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			danhSáchKhôngChọnToolStripMenuItem.Name = "danhSáchKhôngChọnToolStripMenuItem";
			danhSáchKhôngChọnToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			giữNguyênỞThưMụcCũToolStripMenuItem.Name = "giữNguyênỞThưMụcCũToolStripMenuItem";
			giữNguyênỞThưMụcCũToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			mnsCutAccount.Name = "mnsCutAccount";
			mnsCutAccount.Size = new System.Drawing.Size(32, 19);
			kiểmTraTàiKhoảnToolStripMenuItem.Name = "kiểmTraTàiKhoảnToolStripMenuItem";
			kiểmTraTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			kiểmTraCookieToolStripMenuItem.Name = "kiểmTraCookieToolStripMenuItem";
			kiểmTraCookieToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			kiểmTraTokenToolStripMenuItem.Name = "kiểmTraTokenToolStripMenuItem";
			kiểmTraTokenToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			backupTokenToolStripMenuItem.Name = "backupTokenToolStripMenuItem";
			backupTokenToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			backupCookieToolStripMenuItem.Name = "backupCookieToolStripMenuItem";
			backupCookieToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			backupCookieTrungGianToolStripMenuItem.Name = "backupCookieTrungGianToolStripMenuItem";
			backupCookieTrungGianToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			mậtKhẩuToolStripMenuItem1.Name = "mậtKhẩuToolStripMenuItem1";
			mậtKhẩuToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			nhậpDữLiệuToolStripMenuItem.Name = "nhậpDữLiệuToolStripMenuItem";
			nhậpDữLiệuToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			tokenToolStripMenuItem2.Name = "tokenToolStripMenuItem2";
			tokenToolStripMenuItem2.Size = new System.Drawing.Size(32, 19);
			tựĐộngLấyToolStripMenuItem1.Name = "tựĐộngLấyToolStripMenuItem1";
			tựĐộngLấyToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			tokenBussinessToolStripMenuItem.Name = "tokenBussinessToolStripMenuItem";
			tokenBussinessToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			tokenInstagramToolStripMenuItem1.Name = "tokenInstagramToolStripMenuItem1";
			tokenInstagramToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			tokenIosToolStripMenuItem.Name = "tokenIosToolStripMenuItem";
			tokenIosToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			tokenAndroidToolStripMenuItem1.Name = "tokenAndroidToolStripMenuItem1";
			tokenAndroidToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			nhậpDữLiệuToolStripMenuItem2.Name = "nhậpDữLiệuToolStripMenuItem2";
			nhậpDữLiệuToolStripMenuItem2.Size = new System.Drawing.Size(32, 19);
			cookieToolStripMenuItem3.Name = "cookieToolStripMenuItem3";
			cookieToolStripMenuItem3.Size = new System.Drawing.Size(32, 19);
			tựĐộngLấyToolStripMenuItem.Name = "tựĐộngLấyToolStripMenuItem";
			tựĐộngLấyToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			nhậpDữLiệuToolStripMenuItem1.Name = "nhậpDữLiệuToolStripMenuItem1";
			nhậpDữLiệuToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			bunifuCustomLabel1.AutoSize = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(43, 7);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(254, 16);
			bunifuCustomLabel1.TabIndex = 7;
			bunifuCustomLabel1.Text = "Cấu hình chức năng thay đô\u0309i thông tin";
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = pnlHeader;
			bunifuDragControl2.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 5);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(658, 32);
			pnlHeader.TabIndex = 9;
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(6, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 16;
			pictureBox1.TabStop = false;
			pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.Dock = System.Windows.Forms.DockStyle.Right;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Image = (System.Drawing.Image)resources.GetObject("btnMinimize.Image");
			btnMinimize.Location = new System.Drawing.Point(626, 0);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(32, 32);
			btnMinimize.TabIndex = 13;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			btnMinimize.Click += new System.EventHandler(BtnMinimize_Click);
			groupBox3.BackColor = System.Drawing.Color.White;
			groupBox3.Controls.Add(ckbXoaThietBiTinCay);
			groupBox3.Controls.Add(ckbXoaMailCu2);
			groupBox3.Controls.Add(ckbAnMailAll);
			groupBox3.Controls.Add(panel5);
			groupBox3.Controls.Add(ckbGioiTinh);
			groupBox3.Controls.Add(plAvatar);
			groupBox3.Controls.Add(plDoiMail);
			groupBox3.Controls.Add(ckbAddMail);
			groupBox3.Controls.Add(txtPhone);
			groupBox3.Controls.Add(panel1);
			groupBox3.Controls.Add(panel3);
			groupBox3.Controls.Add(pl2fa);
			groupBox3.Controls.Add(plDoiMatKhau);
			groupBox3.Controls.Add(plDoiAnhBia);
			groupBox3.Controls.Add(ckbThemMoTa);
			groupBox3.Controls.Add(btnThemMoTa);
			groupBox3.Controls.Add(ckbDoiNgaySinh);
			groupBox3.Controls.Add(ckb2fa);
			groupBox3.Controls.Add(ckbXoaSdt);
			groupBox3.Controls.Add(ckbLogOut);
			groupBox3.Controls.Add(ckbDoiPass);
			groupBox3.Controls.Add(ckbCapNhatThongTin);
			groupBox3.Controls.Add(ckbDoiTen);
			groupBox3.Controls.Add(ckbDoiAnhBia);
			groupBox3.Controls.Add(ckbAddPhone);
			groupBox3.Controls.Add(ckbAutoDeleteFile);
			groupBox3.Controls.Add(ckbDoiAvatar);
			groupBox3.Controls.Add(plDoiTen);
			groupBox3.Controls.Add(ckbDoiNgonNgu);
			groupBox3.Controls.Add(cbbNgonNgu);
			groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox3.Location = new System.Drawing.Point(6, 153);
			groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			groupBox3.Name = "groupBox3";
			groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			groupBox3.Size = new System.Drawing.Size(647, 612);
			groupBox3.TabIndex = 18;
			groupBox3.TabStop = false;
			groupBox3.Text = "Tu\u0300y cho\u0323n";
			groupBox3.Enter += new System.EventHandler(groupBox3_Enter);
			ckbXoaThietBiTinCay.AutoSize = true;
			ckbXoaThietBiTinCay.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbXoaThietBiTinCay.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbXoaThietBiTinCay.Location = new System.Drawing.Point(16, 525);
			ckbXoaThietBiTinCay.Name = "ckbXoaThietBiTinCay";
			ckbXoaThietBiTinCay.Size = new System.Drawing.Size(133, 20);
			ckbXoaThietBiTinCay.TabIndex = 174;
			ckbXoaThietBiTinCay.Text = "Xóa thiết bị tin cậy";
			ckbXoaThietBiTinCay.UseVisualStyleBackColor = true;
			ckbXoaMailCu2.AutoSize = true;
			ckbXoaMailCu2.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbXoaMailCu2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbXoaMailCu2.Location = new System.Drawing.Point(454, 243);
			ckbXoaMailCu2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbXoaMailCu2.Name = "ckbXoaMailCu2";
			ckbXoaMailCu2.Size = new System.Drawing.Size(117, 20);
			ckbXoaMailCu2.TabIndex = 173;
			ckbXoaMailCu2.Text = "Xóa các mail cũ";
			ckbXoaMailCu2.UseVisualStyleBackColor = true;
			ckbXoaMailCu2.CheckedChanged += new System.EventHandler(ckbXoaMailCu2_CheckedChanged);
			ckbAnMailAll.AutoSize = true;
			ckbAnMailAll.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAnMailAll.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAnMailAll.Location = new System.Drawing.Point(336, 243);
			ckbAnMailAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbAnMailAll.Name = "ckbAnMailAll";
			ckbAnMailAll.Size = new System.Drawing.Size(70, 20);
			ckbAnMailAll.TabIndex = 172;
			ckbAnMailAll.Text = "Â\u0309n mail";
			ckbAnMailAll.UseVisualStyleBackColor = true;
			ckbAnMailAll.CheckedChanged += new System.EventHandler(ckbAnMailAll_CheckedChanged);
			panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel5.Controls.Add(rbNu);
			panel5.Controls.Add(rbNam);
			panel5.Location = new System.Drawing.Point(146, 499);
			panel5.Name = "panel5";
			panel5.Size = new System.Drawing.Size(121, 22);
			panel5.TabIndex = 167;
			rbNu.AutoSize = true;
			rbNu.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNu.Location = new System.Drawing.Point(67, 0);
			rbNu.Name = "rbNu";
			rbNu.Size = new System.Drawing.Size(42, 20);
			rbNu.TabIndex = 1;
			rbNu.TabStop = true;
			rbNu.Text = "Nữ";
			rbNu.UseVisualStyleBackColor = true;
			rbNam.AutoSize = true;
			rbNam.Checked = true;
			rbNam.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNam.Location = new System.Drawing.Point(3, 0);
			rbNam.Name = "rbNam";
			rbNam.Size = new System.Drawing.Size(52, 20);
			rbNam.TabIndex = 0;
			rbNam.TabStop = true;
			rbNam.Text = "Nam";
			rbNam.UseVisualStyleBackColor = true;
			ckbGioiTinh.AutoSize = true;
			ckbGioiTinh.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbGioiTinh.Font = new System.Drawing.Font("Segoe UI", 9.75f);
			ckbGioiTinh.Location = new System.Drawing.Point(16, 498);
			ckbGioiTinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbGioiTinh.Name = "ckbGioiTinh";
			ckbGioiTinh.Size = new System.Drawing.Size(98, 21);
			ckbGioiTinh.TabIndex = 166;
			ckbGioiTinh.Text = "Đổi giới tính";
			ckbGioiTinh.UseVisualStyleBackColor = true;
			ckbGioiTinh.CheckedChanged += new System.EventHandler(ckbGioiTinh_CheckedChanged);
			plAvatar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plAvatar.Controls.Add(ckbAvatarThuTu);
			plAvatar.Controls.Add(label16);
			plAvatar.Controls.Add(txtPathAvatar);
			plAvatar.Location = new System.Drawing.Point(38, 107);
			plAvatar.Name = "plAvatar";
			plAvatar.Size = new System.Drawing.Size(270, 53);
			plAvatar.TabIndex = 165;
			ckbAvatarThuTu.AutoSize = true;
			ckbAvatarThuTu.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAvatarThuTu.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAvatarThuTu.Location = new System.Drawing.Point(3, 31);
			ckbAvatarThuTu.Name = "ckbAvatarThuTu";
			ckbAvatarThuTu.Size = new System.Drawing.Size(139, 20);
			ckbAvatarThuTu.TabIndex = 161;
			ckbAvatarThuTu.Text = "Lấy ảnh theo thứ tự";
			ckbAvatarThuTu.UseVisualStyleBackColor = true;
			label16.AutoSize = true;
			label16.Location = new System.Drawing.Point(2, 7);
			label16.Name = "label16";
			label16.Size = new System.Drawing.Size(101, 16);
			label16.TabIndex = 160;
			label16.Text = "Đường dẫn ảnh:";
			txtPathAvatar.CustomButton.Image = null;
			txtPathAvatar.CustomButton.Location = new System.Drawing.Point(139, 1);
			txtPathAvatar.CustomButton.Name = "";
			txtPathAvatar.CustomButton.Size = new System.Drawing.Size(21, 21);
			txtPathAvatar.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			txtPathAvatar.CustomButton.TabIndex = 1;
			txtPathAvatar.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			txtPathAvatar.CustomButton.UseSelectable = true;
			txtPathAvatar.CustomButton.Visible = false;
			txtPathAvatar.Lines = new string[0];
			txtPathAvatar.Location = new System.Drawing.Point(104, 3);
			txtPathAvatar.MaxLength = 32767;
			txtPathAvatar.Name = "txtPathAvatar";
			txtPathAvatar.PasswordChar = '\0';
			txtPathAvatar.ScrollBars = System.Windows.Forms.ScrollBars.None;
			txtPathAvatar.SelectedText = "";
			txtPathAvatar.SelectionLength = 0;
			txtPathAvatar.SelectionStart = 0;
			txtPathAvatar.ShortcutsEnabled = true;
			txtPathAvatar.Size = new System.Drawing.Size(161, 23);
			txtPathAvatar.TabIndex = 159;
			txtPathAvatar.UseSelectable = true;
			txtPathAvatar.WaterMarkColor = System.Drawing.Color.FromArgb(109, 109, 109);
			txtPathAvatar.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12f, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			plDoiMail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDoiMail.Controls.Add(plPassMailHacked);
			plDoiMail.Controls.Add(ckbAddMailLinkHacked);
			plDoiMail.Controls.Add(ckbAnMailMoi);
			plDoiMail.Controls.Add(ckbXoaMailCu);
			plDoiMail.Controls.Add(ckbMailVip);
			plDoiMail.Controls.Add(ckbCloseChrome);
			plDoiMail.Controls.Add(label15);
			plDoiMail.Controls.Add(btnNhapHotmail);
			plDoiMail.Enabled = false;
			plDoiMail.Location = new System.Drawing.Point(365, 44);
			plDoiMail.Name = "plDoiMail";
			plDoiMail.Size = new System.Drawing.Size(273, 192);
			plDoiMail.TabIndex = 161;
			plDoiMail.Paint += new System.Windows.Forms.PaintEventHandler(plDoiMail_Paint);
			plPassMailHacked.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plPassMailHacked.Controls.Add(txtPassMailHacked);
			plPassMailHacked.Controls.Add(label18);
			plPassMailHacked.Controls.Add(ckbRandomPassMailHacked);
			plPassMailHacked.Location = new System.Drawing.Point(24, 136);
			plPassMailHacked.Name = "plPassMailHacked";
			plPassMailHacked.Size = new System.Drawing.Size(242, 51);
			plPassMailHacked.TabIndex = 147;
			txtPassMailHacked.CustomButton.Image = null;
			txtPassMailHacked.CustomButton.Location = new System.Drawing.Point(117, 1);
			txtPassMailHacked.CustomButton.Name = "";
			txtPassMailHacked.CustomButton.Size = new System.Drawing.Size(21, 21);
			txtPassMailHacked.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			txtPassMailHacked.CustomButton.TabIndex = 1;
			txtPassMailHacked.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			txtPassMailHacked.CustomButton.UseSelectable = true;
			txtPassMailHacked.CustomButton.Visible = false;
			txtPassMailHacked.Lines = new string[0];
			txtPassMailHacked.Location = new System.Drawing.Point(98, 3);
			txtPassMailHacked.MaxLength = 32767;
			txtPassMailHacked.Name = "txtPassMailHacked";
			txtPassMailHacked.PasswordChar = '\0';
			txtPassMailHacked.ScrollBars = System.Windows.Forms.ScrollBars.None;
			txtPassMailHacked.SelectedText = "";
			txtPassMailHacked.SelectionLength = 0;
			txtPassMailHacked.SelectionStart = 0;
			txtPassMailHacked.ShortcutsEnabled = true;
			txtPassMailHacked.Size = new System.Drawing.Size(139, 23);
			txtPassMailHacked.TabIndex = 160;
			txtPassMailHacked.UseSelectable = true;
			txtPassMailHacked.WaterMarkColor = System.Drawing.Color.FromArgb(109, 109, 109);
			txtPassMailHacked.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12f, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			label18.AutoSize = true;
			label18.Location = new System.Drawing.Point(6, 5);
			label18.Name = "label18";
			label18.Size = new System.Drawing.Size(90, 16);
			label18.TabIndex = 128;
			label18.Text = "Mật khẩu mới:";
			ckbRandomPassMailHacked.AutoSize = true;
			ckbRandomPassMailHacked.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbRandomPassMailHacked.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbRandomPassMailHacked.Location = new System.Drawing.Point(9, 27);
			ckbRandomPassMailHacked.Name = "ckbRandomPassMailHacked";
			ckbRandomPassMailHacked.Size = new System.Drawing.Size(74, 20);
			ckbRandomPassMailHacked.TabIndex = 115;
			ckbRandomPassMailHacked.Text = "Random";
			ckbRandomPassMailHacked.UseVisualStyleBackColor = true;
			ckbRandomPassMailHacked.CheckedChanged += new System.EventHandler(ckbRandomPassMailHacked_CheckedChanged);
			ckbAddMailLinkHacked.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbAddMailLinkHacked.AutoSize = true;
			ckbAddMailLinkHacked.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAddMailLinkHacked.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAddMailLinkHacked.Location = new System.Drawing.Point(7, 109);
			ckbAddMailLinkHacked.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbAddMailLinkHacked.Name = "ckbAddMailLinkHacked";
			ckbAddMailLinkHacked.Size = new System.Drawing.Size(123, 20);
			ckbAddMailLinkHacked.TabIndex = 173;
			ckbAddMailLinkHacked.Text = "Dùng link hacked";
			ckbAddMailLinkHacked.UseVisualStyleBackColor = true;
			ckbAddMailLinkHacked.CheckedChanged += new System.EventHandler(ckbAddMailLinkHacked_CheckedChanged);
			ckbAnMailMoi.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbAnMailMoi.AutoSize = true;
			ckbAnMailMoi.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAnMailMoi.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAnMailMoi.Location = new System.Drawing.Point(7, 57);
			ckbAnMailMoi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbAnMailMoi.Name = "ckbAnMailMoi";
			ckbAnMailMoi.Size = new System.Drawing.Size(95, 20);
			ckbAnMailMoi.TabIndex = 171;
			ckbAnMailMoi.Text = "Â\u0309n mail mơ\u0301i";
			ckbAnMailMoi.UseVisualStyleBackColor = true;
			ckbAnMailMoi.CheckedChanged += new System.EventHandler(ckbAnMailMoi_CheckedChanged);
			ckbXoaMailCu.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbXoaMailCu.AutoSize = true;
			ckbXoaMailCu.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbXoaMailCu.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbXoaMailCu.Location = new System.Drawing.Point(106, 57);
			ckbXoaMailCu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbXoaMailCu.Name = "ckbXoaMailCu";
			ckbXoaMailCu.Size = new System.Drawing.Size(117, 20);
			ckbXoaMailCu.TabIndex = 172;
			ckbXoaMailCu.Text = "Xóa các mail cũ";
			ckbXoaMailCu.UseVisualStyleBackColor = true;
			ckbXoaMailCu.CheckedChanged += new System.EventHandler(ckbXoaMailCu_CheckedChanged);
			ckbMailVip.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbMailVip.AutoSize = true;
			ckbMailVip.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbMailVip.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbMailVip.Location = new System.Drawing.Point(7, 33);
			ckbMailVip.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbMailVip.Name = "ckbMailVip";
			ckbMailVip.Size = new System.Drawing.Size(97, 20);
			ckbMailVip.TabIndex = 143;
			ckbMailVip.Text = "Mail Domain";
			ckbMailVip.UseVisualStyleBackColor = true;
			ckbCloseChrome.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbCloseChrome.AutoSize = true;
			ckbCloseChrome.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCloseChrome.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbCloseChrome.Location = new System.Drawing.Point(7, 83);
			ckbCloseChrome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbCloseChrome.Name = "ckbCloseChrome";
			ckbCloseChrome.Size = new System.Drawing.Size(224, 20);
			ckbCloseChrome.TabIndex = 142;
			ckbCloseChrome.Text = "Đóng chrome khi add mail thất bại";
			ckbCloseChrome.UseVisualStyleBackColor = true;
			ckbCloseChrome.CheckedChanged += new System.EventHandler(ckbCloseChrome_CheckedChanged);
			label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label15.AutoSize = true;
			label15.Location = new System.Drawing.Point(4, 8);
			label15.Name = "label15";
			label15.Size = new System.Drawing.Size(132, 16);
			label15.TabIndex = 141;
			label15.Text = "Nhập danh sách mail:";
			btnNhapHotmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
			btnNhapHotmail.Cursor = System.Windows.Forms.Cursors.Hand;
			btnNhapHotmail.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnNhapHotmail.ForeColor = System.Drawing.Color.Black;
			btnNhapHotmail.Location = new System.Drawing.Point(136, 2);
			btnNhapHotmail.Name = "btnNhapHotmail";
			btnNhapHotmail.Size = new System.Drawing.Size(82, 27);
			btnNhapHotmail.TabIndex = 95;
			btnNhapHotmail.Text = "Nhập";
			btnNhapHotmail.UseVisualStyleBackColor = true;
			btnNhapHotmail.Click += new System.EventHandler(btnNhapHotmail_Click);
			ckbAddMail.AutoSize = true;
			ckbAddMail.Checked = true;
			ckbAddMail.CheckState = System.Windows.Forms.CheckState.Checked;
			ckbAddMail.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAddMail.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAddMail.Location = new System.Drawing.Point(336, 23);
			ckbAddMail.Name = "ckbAddMail";
			ckbAddMail.Size = new System.Drawing.Size(281, 20);
			ckbAddMail.TabIndex = 160;
			ckbAddMail.Text = "Change mail (Thêm mail mới + Xóa mail cũ)";
			ckbAddMail.UseVisualStyleBackColor = true;
			ckbAddMail.CheckedChanged += new System.EventHandler(ckbAddMail_CheckedChanged);
			txtPhone.Location = new System.Drawing.Point(194, 54);
			txtPhone.Name = "txtPhone";
			txtPhone.Size = new System.Drawing.Size(114, 23);
			txtPhone.TabIndex = 158;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(nudNamFrom);
			panel1.Controls.Add(nudNamTo);
			panel1.Controls.Add(nudThangTo);
			panel1.Controls.Add(nudNgayTo);
			panel1.Controls.Add(nudThangFrom);
			panel1.Controls.Add(nudNgayFrom);
			panel1.Controls.Add(label13);
			panel1.Controls.Add(label7);
			panel1.Controls.Add(label3);
			panel1.Controls.Add(label9);
			panel1.Controls.Add(label6);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(label8);
			panel1.Controls.Add(label5);
			panel1.Controls.Add(label1);
			panel1.Location = new System.Drawing.Point(47, 318);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(263, 87);
			panel1.TabIndex = 157;
			nudNamFrom.Location = new System.Drawing.Point(78, 58);
			nudNamFrom.Maximum = new decimal(new int[4] { 2020, 0, 0, 0 });
			nudNamFrom.Minimum = new decimal(new int[4] { 1900, 0, 0, 0 });
			nudNamFrom.Name = "nudNamFrom";
			nudNamFrom.Size = new System.Drawing.Size(50, 23);
			nudNamFrom.TabIndex = 2;
			nudNamFrom.Value = new decimal(new int[4] { 2020, 0, 0, 0 });
			nudNamTo.Location = new System.Drawing.Point(166, 58);
			nudNamTo.Maximum = new decimal(new int[4] { 2020, 0, 0, 0 });
			nudNamTo.Minimum = new decimal(new int[4] { 1900, 0, 0, 0 });
			nudNamTo.Name = "nudNamTo";
			nudNamTo.Size = new System.Drawing.Size(53, 23);
			nudNamTo.TabIndex = 2;
			nudNamTo.Value = new decimal(new int[4] { 2020, 0, 0, 0 });
			nudThangTo.Location = new System.Drawing.Point(166, 31);
			nudThangTo.Maximum = new decimal(new int[4] { 12, 0, 0, 0 });
			nudThangTo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudThangTo.Name = "nudThangTo";
			nudThangTo.Size = new System.Drawing.Size(53, 23);
			nudThangTo.TabIndex = 2;
			nudThangTo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudNgayTo.Location = new System.Drawing.Point(166, 4);
			nudNgayTo.Maximum = new decimal(new int[4] { 31, 0, 0, 0 });
			nudNgayTo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudNgayTo.Name = "nudNgayTo";
			nudNgayTo.Size = new System.Drawing.Size(53, 23);
			nudNgayTo.TabIndex = 2;
			nudNgayTo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudThangFrom.Location = new System.Drawing.Point(78, 31);
			nudThangFrom.Maximum = new decimal(new int[4] { 12, 0, 0, 0 });
			nudThangFrom.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudThangFrom.Name = "nudThangFrom";
			nudThangFrom.Size = new System.Drawing.Size(50, 23);
			nudThangFrom.TabIndex = 2;
			nudThangFrom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			nudNgayFrom.Location = new System.Drawing.Point(78, 4);
			nudNgayFrom.Maximum = new decimal(new int[4] { 31, 0, 0, 0 });
			nudNgayFrom.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudNgayFrom.Name = "nudNgayFrom";
			nudNgayFrom.Size = new System.Drawing.Size(50, 23);
			nudNgayFrom.TabIndex = 2;
			nudNgayFrom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label13.Location = new System.Drawing.Point(133, 60);
			label13.Name = "label13";
			label13.Size = new System.Drawing.Size(29, 16);
			label13.TabIndex = 1;
			label13.Text = "đến";
			label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label7.Location = new System.Drawing.Point(133, 33);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(29, 16);
			label7.TabIndex = 1;
			label7.Text = "đến";
			label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label3.Location = new System.Drawing.Point(133, 6);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(29, 16);
			label3.TabIndex = 1;
			label3.Text = "đến";
			label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label9.Location = new System.Drawing.Point(49, 60);
			label9.Name = "label9";
			label9.Size = new System.Drawing.Size(25, 16);
			label9.TabIndex = 1;
			label9.Text = "từ";
			label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label6.Location = new System.Drawing.Point(49, 33);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(25, 16);
			label6.TabIndex = 1;
			label6.Text = "từ";
			label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label2.Location = new System.Drawing.Point(49, 6);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(25, 16);
			label2.TabIndex = 1;
			label2.Text = "từ";
			label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label8.AutoSize = true;
			label8.Location = new System.Drawing.Point(4, 60);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(39, 16);
			label8.TabIndex = 0;
			label8.Text = "Năm:";
			label5.AutoSize = true;
			label5.Location = new System.Drawing.Point(4, 33);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(49, 16);
			label5.TabIndex = 0;
			label5.Text = "Tháng:";
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(4, 6);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(41, 16);
			label1.TabIndex = 0;
			label1.Text = "Ngày:";
			panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel3.Controls.Add(button4);
			panel3.Controls.Add(button3);
			panel3.Controls.Add(button9);
			panel3.Controls.Add(button5);
			panel3.Controls.Add(btnCapNhatThongTin);
			panel3.Location = new System.Drawing.Point(47, 433);
			panel3.Name = "panel3";
			panel3.Size = new System.Drawing.Size(268, 60);
			panel3.TabIndex = 157;
			button4.Cursor = System.Windows.Forms.Cursors.Hand;
			button4.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button4.ForeColor = System.Drawing.Color.Black;
			button4.Location = new System.Drawing.Point(185, 1);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(80, 27);
			button4.TabIndex = 146;
			button4.Text = "Tha\u0300nh phô\u0301";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			button3.Cursor = System.Windows.Forms.Cursors.Hand;
			button3.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button3.ForeColor = System.Drawing.Color.Black;
			button3.Location = new System.Drawing.Point(98, 1);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(83, 27);
			button3.TabIndex = 146;
			button3.Text = "Quê qua\u0301n";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button9.Cursor = System.Windows.Forms.Cursors.Hand;
			button9.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button9.ForeColor = System.Drawing.Color.Black;
			button9.Location = new System.Drawing.Point(98, 30);
			button9.Name = "button9";
			button9.Size = new System.Drawing.Size(96, 27);
			button9.TabIndex = 146;
			button9.Text = "Trươ\u0300ng THPT";
			button9.UseVisualStyleBackColor = true;
			button9.Click += new System.EventHandler(button9_Click);
			button5.Cursor = System.Windows.Forms.Cursors.Hand;
			button5.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button5.ForeColor = System.Drawing.Color.Black;
			button5.Location = new System.Drawing.Point(3, 30);
			button5.Name = "button5";
			button5.Size = new System.Drawing.Size(90, 27);
			button5.TabIndex = 146;
			button5.Text = "Trươ\u0300ng ĐH";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			btnCapNhatThongTin.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCapNhatThongTin.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnCapNhatThongTin.ForeColor = System.Drawing.Color.Black;
			btnCapNhatThongTin.Location = new System.Drawing.Point(3, 1);
			btnCapNhatThongTin.Name = "btnCapNhatThongTin";
			btnCapNhatThongTin.Size = new System.Drawing.Size(90, 27);
			btnCapNhatThongTin.TabIndex = 146;
			btnCapNhatThongTin.Text = "Nơi la\u0300m viê\u0323c";
			btnCapNhatThongTin.UseVisualStyleBackColor = true;
			btnCapNhatThongTin.Click += new System.EventHandler(btnCapNhatThongTin_Click);
			pl2fa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			pl2fa.Controls.Add(rdTat2fa);
			pl2fa.Controls.Add(rdBat2fa);
			pl2fa.Location = new System.Drawing.Point(366, 429);
			pl2fa.Name = "pl2fa";
			pl2fa.Size = new System.Drawing.Size(266, 27);
			pl2fa.TabIndex = 157;
			rdTat2fa.AutoSize = true;
			rdTat2fa.Cursor = System.Windows.Forms.Cursors.Hand;
			rdTat2fa.Location = new System.Drawing.Point(121, 3);
			rdTat2fa.Name = "rdTat2fa";
			rdTat2fa.Size = new System.Drawing.Size(96, 20);
			rdTat2fa.TabIndex = 131;
			rdTat2fa.Text = "Tă\u0301t ba\u0309o mâ\u0323t";
			rdTat2fa.UseVisualStyleBackColor = true;
			rdBat2fa.AutoSize = true;
			rdBat2fa.Checked = true;
			rdBat2fa.Cursor = System.Windows.Forms.Cursors.Hand;
			rdBat2fa.Location = new System.Drawing.Point(3, 3);
			rdBat2fa.Name = "rdBat2fa";
			rdBat2fa.Size = new System.Drawing.Size(95, 20);
			rdBat2fa.TabIndex = 131;
			rdBat2fa.TabStop = true;
			rdBat2fa.Text = "Bâ\u0323t ba\u0309o mâ\u0323t";
			rdBat2fa.UseVisualStyleBackColor = true;
			rdBat2fa.CheckedChanged += new System.EventHandler(rdPassTuNhap_CheckedChanged);
			plDoiMatKhau.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDoiMatKhau.Controls.Add(button2);
			plDoiMatKhau.Controls.Add(ckbChangePassLinkHacked);
			plDoiMatKhau.Controls.Add(btnNhapPass);
			plDoiMatKhau.Controls.Add(rdPassRandom);
			plDoiMatKhau.Controls.Add(rdPassTuNhap);
			plDoiMatKhau.Location = new System.Drawing.Point(365, 480);
			plDoiMatKhau.Name = "plDoiMatKhau";
			plDoiMatKhau.Size = new System.Drawing.Size(274, 80);
			plDoiMatKhau.TabIndex = 157;
			plDoiMatKhau.Paint += new System.Windows.Forms.PaintEventHandler(plDoiMatKhau_Paint);
			button2.Cursor = System.Windows.Forms.Cursors.Help;
			button2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button2.Location = new System.Drawing.Point(199, 4);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(24, 24);
			button2.TabIndex = 150;
			button2.Text = "?";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click_1);
			ckbChangePassLinkHacked.AutoSize = true;
			ckbChangePassLinkHacked.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbChangePassLinkHacked.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbChangePassLinkHacked.Location = new System.Drawing.Point(4, 55);
			ckbChangePassLinkHacked.Name = "ckbChangePassLinkHacked";
			ckbChangePassLinkHacked.Size = new System.Drawing.Size(123, 20);
			ckbChangePassLinkHacked.TabIndex = 149;
			ckbChangePassLinkHacked.Text = "Dùng link hacked";
			ckbChangePassLinkHacked.UseVisualStyleBackColor = true;
			btnNhapPass.Cursor = System.Windows.Forms.Cursors.Hand;
			btnNhapPass.Location = new System.Drawing.Point(88, 3);
			btnNhapPass.Name = "btnNhapPass";
			btnNhapPass.Size = new System.Drawing.Size(105, 27);
			btnNhapPass.TabIndex = 124;
			btnNhapPass.Text = "Nhập mật khẩu";
			btnNhapPass.UseVisualStyleBackColor = true;
			btnNhapPass.Click += new System.EventHandler(btnNhapPass_Click);
			rdPassRandom.AutoSize = true;
			rdPassRandom.Cursor = System.Windows.Forms.Cursors.Hand;
			rdPassRandom.Location = new System.Drawing.Point(4, 30);
			rdPassRandom.Name = "rdPassRandom";
			rdPassRandom.Size = new System.Drawing.Size(73, 20);
			rdPassRandom.TabIndex = 131;
			rdPassRandom.Text = "Random";
			rdPassRandom.UseVisualStyleBackColor = true;
			rdPassTuNhap.AutoSize = true;
			rdPassTuNhap.Checked = true;
			rdPassTuNhap.Cursor = System.Windows.Forms.Cursors.Hand;
			rdPassTuNhap.Location = new System.Drawing.Point(3, 5);
			rdPassTuNhap.Name = "rdPassTuNhap";
			rdPassTuNhap.Size = new System.Drawing.Size(74, 20);
			rdPassTuNhap.TabIndex = 131;
			rdPassTuNhap.TabStop = true;
			rdPassTuNhap.Text = "Tư\u0323 nhâ\u0323p";
			rdPassTuNhap.UseVisualStyleBackColor = true;
			rdPassTuNhap.CheckedChanged += new System.EventHandler(rdPassTuNhap_CheckedChanged);
			plDoiAnhBia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDoiAnhBia.Controls.Add(ckbCoverThuTu);
			plDoiAnhBia.Controls.Add(txtPathCover);
			plDoiAnhBia.Controls.Add(rdAnhNguoiDungDat);
			plDoiAnhBia.Controls.Add(rdAnhNgheThuat);
			plDoiAnhBia.Location = new System.Drawing.Point(46, 188);
			plDoiAnhBia.Name = "plDoiAnhBia";
			plDoiAnhBia.Size = new System.Drawing.Size(262, 74);
			plDoiAnhBia.TabIndex = 154;
			ckbCoverThuTu.AutoSize = true;
			ckbCoverThuTu.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCoverThuTu.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbCoverThuTu.Location = new System.Drawing.Point(3, 52);
			ckbCoverThuTu.Name = "ckbCoverThuTu";
			ckbCoverThuTu.Size = new System.Drawing.Size(139, 20);
			ckbCoverThuTu.TabIndex = 162;
			ckbCoverThuTu.Text = "Lấy ảnh theo thứ tự";
			ckbCoverThuTu.UseVisualStyleBackColor = true;
			txtPathCover.CustomButton.Image = null;
			txtPathCover.CustomButton.Location = new System.Drawing.Point(115, 1);
			txtPathCover.CustomButton.Name = "";
			txtPathCover.CustomButton.Size = new System.Drawing.Size(21, 21);
			txtPathCover.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			txtPathCover.CustomButton.TabIndex = 1;
			txtPathCover.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			txtPathCover.CustomButton.UseSelectable = true;
			txtPathCover.CustomButton.Visible = false;
			txtPathCover.Lines = new string[0];
			txtPathCover.Location = new System.Drawing.Point(120, 3);
			txtPathCover.MaxLength = 32767;
			txtPathCover.Name = "txtPathCover";
			txtPathCover.PasswordChar = '\0';
			txtPathCover.ScrollBars = System.Windows.Forms.ScrollBars.None;
			txtPathCover.SelectedText = "";
			txtPathCover.SelectionLength = 0;
			txtPathCover.SelectionStart = 0;
			txtPathCover.ShortcutsEnabled = true;
			txtPathCover.Size = new System.Drawing.Size(137, 23);
			txtPathCover.TabIndex = 159;
			txtPathCover.UseSelectable = true;
			txtPathCover.WaterMarkColor = System.Drawing.Color.FromArgb(109, 109, 109);
			txtPathCover.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12f, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			rdAnhNguoiDungDat.AutoSize = true;
			rdAnhNguoiDungDat.Checked = true;
			rdAnhNguoiDungDat.Cursor = System.Windows.Forms.Cursors.Hand;
			rdAnhNguoiDungDat.Location = new System.Drawing.Point(3, 4);
			rdAnhNguoiDungDat.Name = "rdAnhNguoiDungDat";
			rdAnhNguoiDungDat.Size = new System.Drawing.Size(119, 20);
			rdAnhNguoiDungDat.TabIndex = 131;
			rdAnhNguoiDungDat.TabStop = true;
			rdAnhNguoiDungDat.Text = "Đường dẫn ảnh:";
			rdAnhNguoiDungDat.UseVisualStyleBackColor = true;
			rdAnhNguoiDungDat.CheckedChanged += new System.EventHandler(rdAnhNguoiDungDat_CheckedChanged);
			rdAnhNgheThuat.AutoSize = true;
			rdAnhNgheThuat.Cursor = System.Windows.Forms.Cursors.Hand;
			rdAnhNgheThuat.Location = new System.Drawing.Point(3, 28);
			rdAnhNgheThuat.Name = "rdAnhNgheThuat";
			rdAnhNgheThuat.Size = new System.Drawing.Size(216, 20);
			rdAnhNgheThuat.TabIndex = 130;
			rdAnhNgheThuat.Text = "Ảnh bìa nghệ thuật của Facebook";
			rdAnhNgheThuat.UseVisualStyleBackColor = true;
			ckbThemMoTa.AutoSize = true;
			ckbThemMoTa.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbThemMoTa.Font = new System.Drawing.Font("Segoe UI", 9.75f);
			ckbThemMoTa.Location = new System.Drawing.Point(16, 268);
			ckbThemMoTa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbThemMoTa.Name = "ckbThemMoTa";
			ckbThemMoTa.Size = new System.Drawing.Size(148, 21);
			ckbThemMoTa.TabIndex = 155;
			ckbThemMoTa.Text = "Thêm tiểu sử (mô tả)";
			ckbThemMoTa.UseVisualStyleBackColor = true;
			ckbThemMoTa.CheckedChanged += new System.EventHandler(ckbThemMoTa_CheckedChanged);
			btnThemMoTa.Cursor = System.Windows.Forms.Cursors.Hand;
			btnThemMoTa.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnThemMoTa.ForeColor = System.Drawing.Color.Black;
			btnThemMoTa.Location = new System.Drawing.Point(169, 265);
			btnThemMoTa.Name = "btnThemMoTa";
			btnThemMoTa.Size = new System.Drawing.Size(96, 27);
			btnThemMoTa.TabIndex = 147;
			btnThemMoTa.Text = "Nhập tiểu sử";
			btnThemMoTa.UseVisualStyleBackColor = true;
			btnThemMoTa.Click += new System.EventHandler(btnThemMoTa_Click);
			ckbDoiNgaySinh.AutoSize = true;
			ckbDoiNgaySinh.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiNgaySinh.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiNgaySinh.Location = new System.Drawing.Point(16, 296);
			ckbDoiNgaySinh.Name = "ckbDoiNgaySinh";
			ckbDoiNgaySinh.Size = new System.Drawing.Size(104, 20);
			ckbDoiNgaySinh.TabIndex = 148;
			ckbDoiNgaySinh.Text = "Đổi ngày sinh";
			ckbDoiNgaySinh.UseVisualStyleBackColor = true;
			ckbDoiNgaySinh.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			ckb2fa.AutoSize = true;
			ckb2fa.Cursor = System.Windows.Forms.Cursors.Hand;
			ckb2fa.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckb2fa.Location = new System.Drawing.Point(331, 405);
			ckb2fa.Name = "ckb2fa";
			ckb2fa.Size = new System.Drawing.Size(142, 20);
			ckb2fa.TabIndex = 148;
			ckb2fa.Text = "Ba\u0309o mâ\u0323t 2 lơ\u0301p (2FA)";
			ckb2fa.UseVisualStyleBackColor = true;
			ckb2fa.CheckedChanged += new System.EventHandler(ckb2fa_CheckedChanged);
			ckbXoaSdt.AutoSize = true;
			ckbXoaSdt.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbXoaSdt.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbXoaSdt.Location = new System.Drawing.Point(16, 551);
			ckbXoaSdt.Name = "ckbXoaSdt";
			ckbXoaSdt.Size = new System.Drawing.Size(176, 20);
			ckbXoaSdt.TabIndex = 148;
			ckbXoaSdt.Text = "Tự động xóa số điện thoại";
			ckbXoaSdt.UseVisualStyleBackColor = true;
			ckbLogOut.AutoSize = true;
			ckbLogOut.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbLogOut.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbLogOut.Location = new System.Drawing.Point(16, 577);
			ckbLogOut.Name = "ckbLogOut";
			ckbLogOut.Size = new System.Drawing.Size(167, 20);
			ckbLogOut.TabIndex = 148;
			ckbLogOut.Text = "Đăng xuất hết thiết bị cũ";
			ckbLogOut.UseVisualStyleBackColor = true;
			ckbDoiPass.AutoSize = true;
			ckbDoiPass.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiPass.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiPass.Location = new System.Drawing.Point(336, 458);
			ckbDoiPass.Name = "ckbDoiPass";
			ckbDoiPass.Size = new System.Drawing.Size(103, 20);
			ckbDoiPass.TabIndex = 148;
			ckbDoiPass.Text = "Đổi mật khẩu";
			ckbDoiPass.UseVisualStyleBackColor = true;
			ckbDoiPass.CheckedChanged += new System.EventHandler(ckbDoiPass_CheckedChanged);
			ckbCapNhatThongTin.AutoSize = true;
			ckbCapNhatThongTin.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCapNhatThongTin.Font = new System.Drawing.Font("Segoe UI", 9.75f);
			ckbCapNhatThongTin.Location = new System.Drawing.Point(16, 409);
			ckbCapNhatThongTin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbCapNhatThongTin.Name = "ckbCapNhatThongTin";
			ckbCapNhatThongTin.Size = new System.Drawing.Size(184, 21);
			ckbCapNhatThongTin.TabIndex = 156;
			ckbCapNhatThongTin.Text = "Cập nhật thông tin cá nhân";
			ckbCapNhatThongTin.UseVisualStyleBackColor = true;
			ckbCapNhatThongTin.CheckedChanged += new System.EventHandler(ckbCapNhatThongTin_CheckedChanged);
			ckbDoiTen.AutoSize = true;
			ckbDoiTen.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiTen.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiTen.Location = new System.Drawing.Point(336, 270);
			ckbDoiTen.Name = "ckbDoiTen";
			ckbDoiTen.Size = new System.Drawing.Size(68, 20);
			ckbDoiTen.TabIndex = 149;
			ckbDoiTen.Text = "Đổi tên";
			ckbDoiTen.UseVisualStyleBackColor = true;
			ckbDoiTen.CheckedChanged += new System.EventHandler(ckbDoiTen_CheckedChanged);
			ckbDoiAnhBia.AutoSize = true;
			ckbDoiAnhBia.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiAnhBia.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiAnhBia.Location = new System.Drawing.Point(16, 166);
			ckbDoiAnhBia.Name = "ckbDoiAnhBia";
			ckbDoiAnhBia.Size = new System.Drawing.Size(92, 20);
			ckbDoiAnhBia.TabIndex = 150;
			ckbDoiAnhBia.Text = "Đổi ảnh bìa";
			ckbDoiAnhBia.UseVisualStyleBackColor = true;
			ckbDoiAnhBia.CheckedChanged += new System.EventHandler(ckbDoiAnhBia_CheckedChanged);
			ckbAddPhone.AutoSize = true;
			ckbAddPhone.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAddPhone.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAddPhone.Location = new System.Drawing.Point(16, 55);
			ckbAddPhone.Name = "ckbAddPhone";
			ckbAddPhone.Size = new System.Drawing.Size(184, 20);
			ckbAddPhone.TabIndex = 151;
			ckbAddPhone.Text = "Thêm sđt (không xa\u0301c minh)";
			ckbAddPhone.UseVisualStyleBackColor = true;
			ckbAddPhone.CheckedChanged += new System.EventHandler(ckbAddPhone_CheckedChanged);
			ckbAutoDeleteFile.AutoSize = true;
			ckbAutoDeleteFile.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAutoDeleteFile.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbAutoDeleteFile.Location = new System.Drawing.Point(135, 168);
			ckbAutoDeleteFile.Name = "ckbAutoDeleteFile";
			ckbAutoDeleteFile.Size = new System.Drawing.Size(173, 20);
			ckbAutoDeleteFile.TabIndex = 151;
			ckbAutoDeleteFile.Text = "Tự động xóa File đã dùng";
			ckbAutoDeleteFile.UseVisualStyleBackColor = true;
			ckbAutoDeleteFile.Visible = false;
			ckbDoiAvatar.AutoSize = true;
			ckbDoiAvatar.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiAvatar.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiAvatar.Location = new System.Drawing.Point(16, 81);
			ckbDoiAvatar.Name = "ckbDoiAvatar";
			ckbDoiAvatar.Size = new System.Drawing.Size(86, 20);
			ckbDoiAvatar.TabIndex = 151;
			ckbDoiAvatar.Text = "Đổi avatar";
			ckbDoiAvatar.UseVisualStyleBackColor = true;
			ckbDoiAvatar.CheckedChanged += new System.EventHandler(ckbDoiAvatar_CheckedChanged);
			plDoiTen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDoiTen.Controls.Add(plTenTuDat);
			plDoiTen.Controls.Add(rdTenTuDat);
			plDoiTen.Controls.Add(rdTenRandom);
			plDoiTen.Controls.Add(plTenNgauNhien);
			plDoiTen.Location = new System.Drawing.Point(366, 292);
			plDoiTen.Name = "plDoiTen";
			plDoiTen.Size = new System.Drawing.Size(273, 109);
			plDoiTen.TabIndex = 153;
			plTenTuDat.Controls.Add(button8);
			plTenTuDat.Controls.Add(button7);
			plTenTuDat.Controls.Add(button6);
			plTenTuDat.Location = new System.Drawing.Point(23, 27);
			plTenTuDat.Name = "plTenTuDat";
			plTenTuDat.Size = new System.Drawing.Size(244, 27);
			plTenTuDat.TabIndex = 119;
			button8.Cursor = System.Windows.Forms.Cursors.Hand;
			button8.Location = new System.Drawing.Point(175, 0);
			button8.Name = "button8";
			button8.Size = new System.Drawing.Size(67, 27);
			button8.TabIndex = 124;
			button8.Text = "Nhập tên";
			button8.UseVisualStyleBackColor = true;
			button8.Click += new System.EventHandler(button8_Click);
			button7.Cursor = System.Windows.Forms.Cursors.Hand;
			button7.Location = new System.Drawing.Point(73, 0);
			button7.Name = "button7";
			button7.Size = new System.Drawing.Size(96, 27);
			button7.TabIndex = 124;
			button7.Text = "Nhập tên đệm";
			button7.UseVisualStyleBackColor = true;
			button7.Click += new System.EventHandler(button7_Click);
			button6.Cursor = System.Windows.Forms.Cursors.Hand;
			button6.Location = new System.Drawing.Point(4, 0);
			button6.Name = "button6";
			button6.Size = new System.Drawing.Size(63, 27);
			button6.TabIndex = 124;
			button6.Text = "Nhập họ";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			rdTenTuDat.AutoSize = true;
			rdTenTuDat.Checked = true;
			rdTenTuDat.Cursor = System.Windows.Forms.Cursors.Hand;
			rdTenTuDat.Location = new System.Drawing.Point(3, 4);
			rdTenTuDat.Name = "rdTenTuDat";
			rdTenTuDat.Size = new System.Drawing.Size(156, 20);
			rdTenTuDat.TabIndex = 131;
			rdTenTuDat.TabStop = true;
			rdTenTuDat.Text = "Tên do người dùng đặt";
			rdTenTuDat.UseVisualStyleBackColor = true;
			rdTenTuDat.CheckedChanged += new System.EventHandler(rdTenTuDat_CheckedChanged);
			rdTenRandom.AutoSize = true;
			rdTenRandom.Cursor = System.Windows.Forms.Cursors.Hand;
			rdTenRandom.Location = new System.Drawing.Point(3, 55);
			rdTenRandom.Name = "rdTenRandom";
			rdTenRandom.Size = new System.Drawing.Size(115, 20);
			rdTenRandom.TabIndex = 130;
			rdTenRandom.Text = "Tên ngẫu nhiên";
			rdTenRandom.UseVisualStyleBackColor = true;
			rdTenRandom.CheckedChanged += new System.EventHandler(rdTenRandom_CheckedChanged);
			plTenNgauNhien.Controls.Add(rdTenRandomNgoai);
			plTenNgauNhien.Controls.Add(rdTenRandomViet);
			plTenNgauNhien.Location = new System.Drawing.Point(23, 77);
			plTenNgauNhien.Name = "plTenNgauNhien";
			plTenNgauNhien.Size = new System.Drawing.Size(195, 27);
			plTenNgauNhien.TabIndex = 135;
			rdTenRandomNgoai.AutoSize = true;
			rdTenRandomNgoai.Cursor = System.Windows.Forms.Cursors.Hand;
			rdTenRandomNgoai.Location = new System.Drawing.Point(83, 3);
			rdTenRandomNgoai.Name = "rdTenRandomNgoai";
			rdTenRandomNgoai.Size = new System.Drawing.Size(83, 20);
			rdTenRandomNgoai.TabIndex = 134;
			rdTenRandomNgoai.Text = "Tên ngoại";
			rdTenRandomNgoai.UseVisualStyleBackColor = true;
			rdTenRandomViet.AutoSize = true;
			rdTenRandomViet.Checked = true;
			rdTenRandomViet.Cursor = System.Windows.Forms.Cursors.Hand;
			rdTenRandomViet.Location = new System.Drawing.Point(5, 3);
			rdTenRandomViet.Name = "rdTenRandomViet";
			rdTenRandomViet.Size = new System.Drawing.Size(72, 20);
			rdTenRandomViet.TabIndex = 134;
			rdTenRandomViet.TabStop = true;
			rdTenRandomViet.Text = "Tên việt";
			rdTenRandomViet.UseVisualStyleBackColor = true;
			ckbDoiNgonNgu.AutoSize = true;
			ckbDoiNgonNgu.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDoiNgonNgu.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbDoiNgonNgu.Location = new System.Drawing.Point(16, 26);
			ckbDoiNgonNgu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			ckbDoiNgonNgu.Name = "ckbDoiNgonNgu";
			ckbDoiNgonNgu.Size = new System.Drawing.Size(104, 20);
			ckbDoiNgonNgu.TabIndex = 142;
			ckbDoiNgonNgu.Text = "Đổi ngôn ngữ";
			ckbDoiNgonNgu.UseVisualStyleBackColor = true;
			ckbDoiNgonNgu.CheckedChanged += new System.EventHandler(ckbDoiNgonNgu_CheckedChanged);
			cbbNgonNgu.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbNgonNgu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbNgonNgu.Font = new System.Drawing.Font("Tahoma", 9.75f);
			cbbNgonNgu.ForeColor = System.Drawing.Color.Black;
			cbbNgonNgu.FormattingEnabled = true;
			cbbNgonNgu.Location = new System.Drawing.Point(126, 24);
			cbbNgonNgu.Name = "cbbNgonNgu";
			cbbNgonNgu.Size = new System.Drawing.Size(182, 24);
			cbbNgonNgu.TabIndex = 143;
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Font = new System.Drawing.Font("Segoe UI", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Location = new System.Drawing.Point(564, 814);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(106, 27);
			button1.TabIndex = 95;
			button1.Text = "Nhập mail|pass";
			button1.UseVisualStyleBackColor = true;
			button1.Visible = false;
			button1.Click += new System.EventHandler(button1_Click);
			ckbVerify.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ckbVerify.AutoSize = true;
			ckbVerify.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbVerify.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbVerify.Location = new System.Drawing.Point(453, 817);
			ckbVerify.Name = "ckbVerify";
			ckbVerify.Size = new System.Drawing.Size(109, 20);
			ckbVerify.TabIndex = 164;
			ckbVerify.Text = "Verify Account";
			ckbVerify.UseVisualStyleBackColor = true;
			ckbVerify.Visible = false;
			ckbVerify.CheckedChanged += new System.EventHandler(ckbVerify_CheckedChanged);
			plXoaMail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plXoaMail.Controls.Add(plXoaMailLinkHacked);
			plXoaMail.Controls.Add(rdXoaTrucTiep);
			plXoaMail.Controls.Add(rdXoaLinkHacked);
			plXoaMail.Enabled = false;
			plXoaMail.Location = new System.Drawing.Point(707, 393);
			plXoaMail.Name = "plXoaMail";
			plXoaMail.Size = new System.Drawing.Size(274, 75);
			plXoaMail.TabIndex = 164;
			plXoaMail.Visible = false;
			plXoaMailLinkHacked.Controls.Add(lblNewPass1);
			plXoaMailLinkHacked.Controls.Add(ckbPassRandomXoaMail);
			plXoaMailLinkHacked.Controls.Add(btnNhapPassXoaMail);
			plXoaMailLinkHacked.Location = new System.Drawing.Point(15, 43);
			plXoaMailLinkHacked.Name = "plXoaMailLinkHacked";
			plXoaMailLinkHacked.Size = new System.Drawing.Size(252, 27);
			plXoaMailLinkHacked.TabIndex = 146;
			lblNewPass1.AutoSize = true;
			lblNewPass1.Location = new System.Drawing.Point(10, 5);
			lblNewPass1.Name = "lblNewPass1";
			lblNewPass1.Size = new System.Drawing.Size(90, 16);
			lblNewPass1.TabIndex = 128;
			lblNewPass1.Text = "Mật khẩu mới:";
			ckbPassRandomXoaMail.AutoSize = true;
			ckbPassRandomXoaMail.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbPassRandomXoaMail.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbPassRandomXoaMail.Location = new System.Drawing.Point(100, 4);
			ckbPassRandomXoaMail.Name = "ckbPassRandomXoaMail";
			ckbPassRandomXoaMail.Size = new System.Drawing.Size(74, 20);
			ckbPassRandomXoaMail.TabIndex = 115;
			ckbPassRandomXoaMail.Text = "Random";
			ckbPassRandomXoaMail.UseVisualStyleBackColor = true;
			ckbPassRandomXoaMail.CheckedChanged += new System.EventHandler(ckbPassRandomXoaMail_CheckedChanged);
			btnNhapPassXoaMail.Cursor = System.Windows.Forms.Cursors.Hand;
			btnNhapPassXoaMail.Location = new System.Drawing.Point(174, 0);
			btnNhapPassXoaMail.Name = "btnNhapPassXoaMail";
			btnNhapPassXoaMail.Size = new System.Drawing.Size(62, 27);
			btnNhapPassXoaMail.TabIndex = 124;
			btnNhapPassXoaMail.Text = "Nhập";
			btnNhapPassXoaMail.UseVisualStyleBackColor = true;
			btnNhapPassXoaMail.Click += new System.EventHandler(btnNhapPassXoaMail_Click);
			rdXoaTrucTiep.AutoSize = true;
			rdXoaTrucTiep.Checked = true;
			rdXoaTrucTiep.Cursor = System.Windows.Forms.Cursors.Hand;
			rdXoaTrucTiep.Location = new System.Drawing.Point(3, 1);
			rdXoaTrucTiep.Name = "rdXoaTrucTiep";
			rdXoaTrucTiep.Size = new System.Drawing.Size(100, 20);
			rdXoaTrucTiep.TabIndex = 131;
			rdXoaTrucTiep.TabStop = true;
			rdXoaTrucTiep.Text = "Xóa trực tiếp";
			rdXoaTrucTiep.UseVisualStyleBackColor = true;
			rdXoaLinkHacked.AutoSize = true;
			rdXoaLinkHacked.Cursor = System.Windows.Forms.Cursors.Hand;
			rdXoaLinkHacked.Location = new System.Drawing.Point(3, 22);
			rdXoaLinkHacked.Name = "rdXoaLinkHacked";
			rdXoaLinkHacked.Size = new System.Drawing.Size(147, 20);
			rdXoaLinkHacked.TabIndex = 130;
			rdXoaLinkHacked.Text = "Xóa bằng link hacked";
			rdXoaLinkHacked.UseVisualStyleBackColor = true;
			rdXoaLinkHacked.CheckedChanged += new System.EventHandler(rdXoaLinkHacked_CheckedChanged);
			ckbXoaMail.AutoSize = true;
			ckbXoaMail.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbXoaMail.Enabled = false;
			ckbXoaMail.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbXoaMail.Location = new System.Drawing.Point(676, 371);
			ckbXoaMail.Name = "ckbXoaMail";
			ckbXoaMail.Size = new System.Drawing.Size(148, 20);
			ckbXoaMail.TabIndex = 163;
			ckbXoaMail.Text = "Chỉ xóa mail (sắp có)";
			ckbXoaMail.UseVisualStyleBackColor = true;
			ckbXoaMail.Visible = false;
			ckbXoaMail.CheckedChanged += new System.EventHandler(ckbXoaMail_CheckedChanged);
			groupBox5.BackColor = System.Drawing.Color.White;
			groupBox5.Controls.Add(panel7);
			groupBox5.Controls.Add(label17);
			groupBox5.Controls.Add(label14);
			groupBox5.Controls.Add(panel4);
			groupBox5.Controls.Add(metroButton1);
			groupBox5.Controls.Add(label12);
			groupBox5.Controls.Add(label10);
			groupBox5.Controls.Add(nudThread);
			groupBox5.Controls.Add(label11);
			groupBox5.Controls.Add(label4);
			groupBox5.Controls.Add(ckbCreateProfile);
			groupBox5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox5.Location = new System.Drawing.Point(7, 42);
			groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			groupBox5.Name = "groupBox5";
			groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			groupBox5.Size = new System.Drawing.Size(647, 104);
			groupBox5.TabIndex = 20;
			groupBox5.TabStop = false;
			groupBox5.Text = "Cấu hình chung";
			groupBox5.Enter += new System.EventHandler(groupBox5_Enter);
			panel7.Controls.Add(rbLoginWWW);
			panel7.Controls.Add(rbLoginMFB);
			panel7.Location = new System.Drawing.Point(147, 74);
			panel7.Name = "panel7";
			panel7.Size = new System.Drawing.Size(228, 26);
			panel7.TabIndex = 150;
			rbLoginWWW.AutoSize = true;
			rbLoginWWW.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginWWW.Location = new System.Drawing.Point(129, 3);
			rbLoginWWW.Name = "rbLoginWWW";
			rbLoginWWW.Size = new System.Drawing.Size(99, 20);
			rbLoginWWW.TabIndex = 4;
			rbLoginWWW.Text = "www.fb.com";
			rbLoginWWW.UseVisualStyleBackColor = true;
			rbLoginMFB.AutoSize = true;
			rbLoginMFB.Checked = true;
			rbLoginMFB.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginMFB.Location = new System.Drawing.Point(3, 3);
			rbLoginMFB.Name = "rbLoginMFB";
			rbLoginMFB.Size = new System.Drawing.Size(120, 20);
			rbLoginMFB.TabIndex = 4;
			rbLoginMFB.TabStop = true;
			rbLoginMFB.Text = "m.facebook.com";
			rbLoginMFB.UseVisualStyleBackColor = true;
			label17.AutoSize = true;
			label17.Location = new System.Drawing.Point(13, 77);
			label17.Name = "label17";
			label17.Size = new System.Drawing.Size(111, 16);
			label17.TabIndex = 149;
			label17.Text = "Trang đăng nhâ\u0323p:";
			label14.AutoSize = true;
			label14.Location = new System.Drawing.Point(13, 53);
			label14.Name = "label14";
			label14.Size = new System.Drawing.Size(129, 16);
			label14.TabIndex = 65;
			label14.Text = "Tùy chọn đăng nhâ\u0323p:";
			panel4.Controls.Add(rbLoginUidPass);
			panel4.Controls.Add(rbLoginCookie);
			panel4.Location = new System.Drawing.Point(147, 49);
			panel4.Name = "panel4";
			panel4.Size = new System.Drawing.Size(163, 26);
			panel4.TabIndex = 66;
			rbLoginUidPass.AutoSize = true;
			rbLoginUidPass.Checked = true;
			rbLoginUidPass.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginUidPass.Location = new System.Drawing.Point(3, 3);
			rbLoginUidPass.Name = "rbLoginUidPass";
			rbLoginUidPass.Size = new System.Drawing.Size(76, 20);
			rbLoginUidPass.TabIndex = 4;
			rbLoginUidPass.TabStop = true;
			rbLoginUidPass.Text = "Uid|Pass";
			rbLoginUidPass.UseVisualStyleBackColor = true;
			rbLoginCookie.AutoSize = true;
			rbLoginCookie.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginCookie.Location = new System.Drawing.Point(90, 3);
			rbLoginCookie.Name = "rbLoginCookie";
			rbLoginCookie.Size = new System.Drawing.Size(64, 20);
			rbLoginCookie.TabIndex = 4;
			rbLoginCookie.Text = "Cookie";
			rbLoginCookie.UseVisualStyleBackColor = true;
			metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton1.Location = new System.Drawing.Point(435, 20);
			metroButton1.Name = "metroButton1";
			metroButton1.Size = new System.Drawing.Size(72, 28);
			metroButton1.TabIndex = 64;
			metroButton1.Text = "Ca\u0300i đă\u0323t";
			metroButton1.UseSelectable = true;
			metroButton1.Click += new System.EventHandler(btnOpenShare_Click);
			label12.AutoSize = true;
			label12.Location = new System.Drawing.Point(333, 24);
			label12.Name = "label12";
			label12.Size = new System.Drawing.Size(99, 16);
			label12.TabIndex = 30;
			label12.Text = "Cấu hình đổi IP:";
			label10.AutoSize = true;
			label10.Location = new System.Drawing.Point(13, 24);
			label10.Name = "label10";
			label10.Size = new System.Drawing.Size(93, 16);
			label10.TabIndex = 30;
			label10.Text = "Số luồng chạy:";
			nudThread.Location = new System.Drawing.Point(112, 22);
			nudThread.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			nudThread.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			nudThread.Name = "nudThread";
			nudThread.Size = new System.Drawing.Size(64, 23);
			nudThread.TabIndex = 31;
			nudThread.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label11.AutoSize = true;
			label11.Location = new System.Drawing.Point(181, 24);
			label11.Name = "label11";
			label11.Size = new System.Drawing.Size(39, 16);
			label11.TabIndex = 32;
			label11.Text = "luồng";
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(23, 133);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(0, 16);
			label4.TabIndex = 19;
			ckbCreateProfile.AutoSize = true;
			ckbCreateProfile.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCreateProfile.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			ckbCreateProfile.Location = new System.Drawing.Point(336, 52);
			ckbCreateProfile.Name = "ckbCreateProfile";
			ckbCreateProfile.Size = new System.Drawing.Size(137, 20);
			ckbCreateProfile.TabIndex = 148;
			ckbCreateProfile.Text = "Tự động tạo Profile";
			ckbCreateProfile.UseVisualStyleBackColor = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 500;
			toolTip1.ReshowDelay = 100;
			toolTip1.ToolTipTitle = "Chú thích";
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel2.Controls.Add(btnCancel);
			panel2.Controls.Add(plXoaMail);
			panel2.Controls.Add(btnAdd);
			panel2.Controls.Add(ckbXoaMail);
			panel2.Controls.Add(bunifuCards1);
			panel2.Controls.Add(button1);
			panel2.Controls.Add(groupBox3);
			panel2.Controls.Add(ckbVerify);
			panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			panel2.Location = new System.Drawing.Point(0, 0);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(660, 814);
			panel2.TabIndex = 69;
			panel2.Paint += new System.Windows.Forms.PaintEventHandler(panel2_Paint);
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(333, 778);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 71;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(BtnMinimize_Click);
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(229, 778);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 70;
			btnAdd.Text = "Lưu";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(button2_Click);
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.RoyalBlue;
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(658, 38);
			bunifuCards1.TabIndex = 69;
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			base.ClientSize = new System.Drawing.Size(660, 814);
			base.Controls.Add(groupBox5);
			base.Controls.Add(panel2);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fChangeConfig";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "MAX CARE - phần mềm quản lý tài khoản v1.2.1(ngày cập nhật 6/6/2019)";
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(fShareConfig_FormClosing);
			ctmsAcc.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			pnlHeader.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			panel5.ResumeLayout(false);
			panel5.PerformLayout();
			plAvatar.ResumeLayout(false);
			plAvatar.PerformLayout();
			plDoiMail.ResumeLayout(false);
			plDoiMail.PerformLayout();
			plPassMailHacked.ResumeLayout(false);
			plPassMailHacked.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudNamFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudNamTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudThangTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudNgayTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudThangFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudNgayFrom).EndInit();
			panel3.ResumeLayout(false);
			pl2fa.ResumeLayout(false);
			pl2fa.PerformLayout();
			plDoiMatKhau.ResumeLayout(false);
			plDoiMatKhau.PerformLayout();
			plDoiAnhBia.ResumeLayout(false);
			plDoiAnhBia.PerformLayout();
			plDoiTen.ResumeLayout(false);
			plDoiTen.PerformLayout();
			plTenTuDat.ResumeLayout(false);
			plTenNgauNhien.ResumeLayout(false);
			plTenNgauNhien.PerformLayout();
			plXoaMail.ResumeLayout(false);
			plXoaMail.PerformLayout();
			plXoaMailLinkHacked.ResumeLayout(false);
			plXoaMailLinkHacked.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			panel7.ResumeLayout(false);
			panel7.PerformLayout();
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudThread).EndInit();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			bunifuCards1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
