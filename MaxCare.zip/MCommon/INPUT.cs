namespace MCommon
{
	public struct INPUT
	{
		public uint Type;

		public MOUSEKEYBDHARDWAREINPUT Data;
	}
}
