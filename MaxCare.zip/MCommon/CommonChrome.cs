using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Common;
using maxcare;
using maxcare.Enum;
using Newtonsoft.Json.Linq;

namespace MCommon
{
	public class CommonChrome
	{
		public static bool CheckFacebookBlocked(Chrome chrome)
		{
			if (chrome.GetURL().StartsWith("https://m.facebook.com/feature_limit_notice/") || chrome.CheckExistElements(0.0, "[href*=\"facebook.com/help/177066345680802\"]", "[href*=\"facebook.com/help/contact/\"]") != 0 || chrome.GetURL().StartsWith("https://m.facebook.com/si/actor_experience/actor_gateway"))
			{
				return true;
			}
			return false;
		}

		public static void AnswerQuestionWhenJoinGroup(Chrome chrome, List<string> lstCauTraLoi)
		{
			List<string> list = new List<string>();
			int num = chrome.CountElement("textarea");
			string text = "";
			for (int i = 0; i < num; i++)
			{
				if (list.Count == 0)
				{
					list = Common.CloneList(lstCauTraLoi);
				}
				text = list[Base.rd.Next(0, list.Count)];
				text = Common.SpinText(text, Base.rd);
				list.Remove(text);
				chrome.ScrollSmooth($"document.querySelectorAll('textarea')[{num}]");
				chrome.DelayRandom(1, 2);
				chrome.SendKeys(4, "textarea", i, text, 0.1);
				chrome.DelayRandom(1, 2);
			}
		}

		public static void AnswerQuestionWhenJoinGroupWWW(Chrome chrome, List<string> lstCauTraLoi)
		{
			List<string> list = new List<string>();
			string text = "[aria-label=\"Answer Questions\"][role=\"dialog\"] [data-visualcompletion=\"ignore-dynamic\"]";
			string text2 = "";
			int num = 0;
			int num2 = Convert.ToInt32(chrome.ExecuteScript("return document.querySelectorAll('" + text + "').length").ToString());
			for (int i = 0; i < num2; i++)
			{
				if (chrome.ExecuteScript("return document.querySelectorAll('" + text + "')[" + i + "].querySelector('[name=\"radio\"]')+''").ToString() != "null")
				{
					num = 1;
				}
				else if (chrome.ExecuteScript("return document.querySelectorAll('" + text + "')[" + i + "].querySelector('textarea')+''").ToString() != "null")
				{
					num = 2;
				}
				else if (chrome.ExecuteScript("return document.querySelectorAll('" + text + "')[" + i + "].querySelector('[name=\"checkbox\"]')+''").ToString() != "null")
				{
					num = 3;
				}
				chrome.ScrollSmoothIfNotExistOnScreen("document.querySelectorAll('" + text + "')[" + i + "]");
				chrome.DelayTime(1.0);
				switch (num)
				{
				case 1:
					chrome.ExecuteScript("document.querySelectorAll('" + text + "')[" + i + "].querySelector('[name=\"radio\"]').click()");
					chrome.DelayTime(1.0);
					break;
				case 2:
					if (list.Count == 0)
					{
						list = Common.CloneList(lstCauTraLoi);
					}
					text2 = list[Base.rd.Next(0, list.Count)];
					list.Remove(text2);
					chrome.SendKeysv2(4, text ?? "", i, 4, "textarea", 0, text2);
					chrome.DelayTime(1.0);
					break;
				case 3:
					chrome.ExecuteScript("document.querySelectorAll('" + text + "')[" + i + "].querySelector('[name=\"checkbox\"]').click()");
					chrome.DelayTime(1.0);
					break;
				}
			}
			if (chrome.CheckExistElement("[name=\"agree-to-group-rules\"]") == 1)
			{
				chrome.Click(2, "agree-to-group-rules");
				chrome.DelayTime(1.0);
			}
		}

		public static bool IsCheckpointWhenLoginWhenGiaiCP(Chrome chrome)
		{
			try
			{
				List<string> list = new List<string> { "#captcha_response", "[name=\"captcha_response\"]", "[name=\"verification_method\"]", "[name=\"password_new\"]", "[href=\"https://www.facebook.com/communitystandards/\"]" };
				return chrome.CheckExistElements(0.0, list.ToArray()) > 0;
			}
			catch
			{
				return false;
			}
		}

		public static int LoginFacebookUsingUidPassWhenGiaiCP(Chrome chrome, string uid, string pass, string fa2 = "", string URL = "https://www.facebook.com")
		{
			new Random();
			int result = 0;
			try
			{
				int num = 0;
				num = CheckTypeWebFacebookFromUrl(chrome.GetURL());
				if (num != 0)
				{
					goto IL_005b;
				}
				if (chrome.GotoURL(URL) != -2)
				{
					num = CheckTypeWebFacebookFromUrl(chrome.GetURL());
					goto IL_005b;
				}
				result = -2;
				goto end_IL_000c;
				IL_005b:
				if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") == 1)
				{
					chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
					chrome.DelayTime(1.0);
				}
				if (num == 1)
				{
					chrome.GotoURLIfNotExist("https://www.facebook.com/login");
					if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") == 1)
					{
						chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
						chrome.DelayTime(1.0);
					}
					if (chrome.SendKeys(1, "email", uid, 0.1) == -2)
					{
						result = -2;
					}
					else
					{
						chrome.DelayTime(1.0);
						if (chrome.SendKeys(1, "pass", pass, 0.1) == -2)
						{
							result = -2;
						}
						else
						{
							chrome.DelayTime(1.0);
							if (chrome.Click(1, "loginbutton") != -2)
							{
								chrome.DelayTime(1.0);
								if (chrome.CheckExistElement("#approvals_code", 5.0) == 1 && fa2 != "")
								{
									string totp = Common.GetTotp(fa2.Replace(" ", "").Replace("\n", ""));
									if (totp != "")
									{
										chrome.SendKeys(1, "approvals_code", totp, 0.1);
										chrome.DelayTime(1.0);
										chrome.Click(1, "checkpointSubmitButton");
										chrome.DelayTime(1.0);
									}
								}
								int num2 = 0;
								while (chrome.CheckExistElement("#checkpointSubmitButton", 3.0) == 1)
								{
									if (chrome.CheckIsLive())
									{
										if (IsCheckpointWhenLoginWhenGiaiCP(chrome) || num2 == 7)
										{
											break;
										}
										chrome.Click(1, "checkpointSubmitButton");
										chrome.DelayTime(1.0);
										num2++;
										continue;
									}
									result = -2;
									goto end_IL_000c;
								}
								goto IL_08be;
							}
							result = -2;
						}
					}
				}
				else
				{
					int num3 = chrome.GotoURLIfNotExist("https://m.facebook.com/login");
					if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") == 1)
					{
						chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
						chrome.DelayTime(1.0);
					}
					num3 = chrome.CheckExistElement("[data-sigil=\"login_profile_form\"] div[role=\"button\"]", 1.0);
					int num4 = num3;
					int num5 = num4;
					if (num5 != -2)
					{
						if (num5 != 1)
						{
							if (chrome.SendKeys(1, "m_login_email", uid, 0.1) == 1)
							{
								chrome.DelayThaoTacNho();
								string attributeValue = ((chrome.CheckExistElements(3.0, "#m_login_password", "[name=\"pass\"]") == 1) ? "#m_login_password" : "[name=\"pass\"]");
								chrome.SendKeys(4, attributeValue, pass, 0.1);
								chrome.DelayThaoTacNho();
								chrome.Click(2, "login");
								chrome.DelayThaoTacNho();
							}
							goto IL_06e4;
						}
						chrome.DelayThaoTacNho();
						if (chrome.Click(4, "[data-sigil=\"login_profile_form\"] div[role=\"button\"]") != -2)
						{
							chrome.DelayThaoTacNho(2);
							switch (chrome.CheckExistElements(10.0, "[name=\"pass\"]", "#approvals_code"))
							{
							case -2:
								result = -2;
								goto end_IL_000c;
							case 1:
								if (chrome.SendKeys(2, "pass", pass, 0.1) == 1)
								{
									chrome.DelayThaoTacNho();
									if (chrome.Click(4, chrome.GetCssSelector("button", "data-sigil", "password_login_button")) == 1)
									{
										chrome.DelayTime(1.0);
									}
								}
								break;
							}
							goto IL_06e4;
						}
						result = -2;
					}
					else
					{
						result = -2;
					}
				}
				goto end_IL_000c;
				IL_08be:
				chrome.DelayTime(1.0);
				return CheckLiveCookie(chrome);
				IL_06e4:
				int num6;
				int num7;
				switch (chrome.CheckExistElement("#approvals_code", 5.0))
				{
				case -2:
					result = -2;
					goto end_IL_000c;
				case 1:
					num6 = ((fa2.Trim() != "") ? 1 : 0);
					goto IL_0736;
				default:
					{
						num6 = 0;
						goto IL_0736;
					}
					IL_0736:
					if (num6 != 0)
					{
						string totp2 = Common.GetTotp(fa2.Replace(" ", "").Replace("\n", ""));
						if (totp2 != "")
						{
							chrome.SendKeys(1, "approvals_code", totp2, 0.1);
							chrome.DelayThaoTacNho(-1);
							chrome.Click(1, "checkpointSubmitButton-actual-button");
							chrome.DelayThaoTacNho();
						}
					}
					num7 = 0;
					while (chrome.CheckExistElement("#checkpointSubmitButton-actual-button", 3.0) == 1 && chrome.CheckExistElement("[name=\"password_new\"]") != 1)
					{
						if (chrome.CheckIsLive())
						{
							if (IsCheckpointWhenLogin(chrome) || num7 == 7)
							{
								break;
							}
							chrome.Click(1, "checkpointSubmitButton-actual-button");
							chrome.DelayThaoTacNho();
							num7++;
							continue;
						}
						result = -2;
						goto end_IL_000c;
					}
					break;
				}
				goto IL_08be;
				end_IL_000c:;
			}
			catch (Exception ex)
			{
				Common.ExportError(chrome, ex, "Login Uid Pass Fail");
			}
			return result;
		}

		public static string GetNameFromPost(Chrome chrome)
		{
			string text = chrome.ExecuteScript("var x='';document.querySelectorAll('[property=\"og:title\"]').length>0&&(x=document.querySelector('[property=\"og:title\"]').getAttribute('content')),''==x&&document.querySelectorAll('[data-gt] a').length>0&&(x=document.querySelector('[data-gt] a').innerText),''==x&&document.querySelectorAll('.actor').length>0&&(x=document.querySelector('.actor').innerText), x+''; return x;").ToString();
			if (text == "")
			{
				text = chrome.ExecuteScript("return document.title").ToString().Split('-', '|')[0].Trim();
			}
			return text;
		}

		public static string GetNameFromStory(Chrome chrome)
		{
			return chrome.ExecuteScript("var x='';document.querySelectorAll('.overflowText').length>0&&(x=document.querySelector('.overflowText').innerText), x+''; return x;").ToString();
		}

		public static int GoToHome(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (!(chrome.GetURL() == "https://m.facebook.com/home.php") && !(chrome.GetURL() == "https://m.facebook.com"))
					{
						if (chrome.CheckExistElement("#feed_jewel a") == 1)
						{
							chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#feed_jewel a')");
							chrome.DelayThaoTacNho();
						}
						if (chrome.Click(4, "#feed_jewel a") != 1)
						{
							chrome.GotoURL("https://m.facebook.com/home.php");
						}
						chrome.DelayTime(1.0);
						if (chrome.CheckExistElement("#nux-nav-button", 2.0) == 1)
						{
							chrome.ClickWithAction(1, "nux-nav-button");
							chrome.DelayTime(2.0);
						}
					}
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.GetURL() == "https://m.facebook.com/home.php" || chrome.GetURL() == "https://m.facebook.com/home.php?ref=wizard&_rdr" || chrome.GetURL() == "https://m.facebook.com")
					{
						return 1;
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToFriend(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("#requests_jewel a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#requests_jewel a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "#requests_jewel a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "#requests_jewel a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						if (chrome.Click(4, "[href=\"/friends/center/friends/?mff_nav=1\"]") == 1)
						{
							chrome.DelayThaoTacNho();
							return 1;
						}
					}
					return chrome.GotoURL("https://m.facebook.com/friends/center/friends/?mff_nav=1");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToFriendSuggest(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("#requests_jewel a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#requests_jewel a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "#requests_jewel a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "#requests_jewel a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						if (chrome.Click(4, "[href=\"/friends/center/suggestions/?mff_nav=1&ref=bookmarks\"]") == 1)
						{
							chrome.DelayThaoTacNho();
							return 1;
						}
					}
					return chrome.GotoURL("https://m.facebook.com/friends/center/suggestions/?mff_nav=1&ref=bookmarks");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToGroup(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("[data-sigil=\"nav-popover bookmarks\"]>a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('[data-sigil=\"nav-popover bookmarks\"]>a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						string cssSelector = chrome.GetCssSelector("a", "href", "/groups/");
						if (cssSelector != "")
						{
							chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('" + cssSelector + "')");
							chrome.DelayThaoTacNho();
							if (chrome.Click(4, cssSelector) == 1)
							{
								chrome.DelayThaoTacNho(2);
								if (chrome.Click(4, "[href=\"/groups_browse/your_groups/\"]") == 1)
								{
									chrome.DelayThaoTacNho();
									return 1;
								}
							}
						}
					}
					return chrome.GotoURL("https://m.facebook.com/groups_browse/your_groups/");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToWatch(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("[data-sigil=\"nav-popover bookmarks\"]>a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('[data-sigil=\"nav-popover bookmarks\"]>a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						string cssSelector = chrome.GetCssSelector("a", "href", "/watch/");
						if (cssSelector != "")
						{
							chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('" + cssSelector + "')");
							chrome.DelayThaoTacNho();
							if (chrome.Click(4, cssSelector) == 1)
							{
								chrome.DelayThaoTacNho();
								return 1;
							}
						}
					}
					return chrome.GotoURL("https://m.facebook.com/watch/?ref=bookmarks");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToSetting(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("[data-sigil=\"nav-popover bookmarks\"]>a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('[data-sigil=\"nav-popover bookmarks\"]>a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "[data-sigil=\"nav-popover bookmarks\"]>a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						string cssSelector = chrome.GetCssSelector("a", "href", "/settings/");
						if (cssSelector != "")
						{
							chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('" + cssSelector + "')");
							chrome.DelayThaoTacNho();
							if (chrome.Click(4, cssSelector) == 1)
							{
								chrome.DelayThaoTacNho();
								return 1;
							}
						}
					}
					return chrome.GotoURL("https://m.facebook.com/settings/?entry_point=bookmark");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToSetting_TimelineAndTagging(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					GoToSetting(chrome);
					string cssSelector = chrome.GetCssSelector("a", "href", "/privacy/touch/timeline_and_tagging/");
					if (cssSelector != "")
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('" + cssSelector + "')");
						chrome.DelayThaoTacNho();
						if (chrome.Click(4, cssSelector) == 1)
						{
							chrome.DelayThaoTacNho();
							return 1;
						}
					}
					return chrome.GotoURL("https://m.facebook.com/privacy/touch/timeline_and_tagging/");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToNotifications(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("#notifications_jewel a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#notifications_jewel a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "#notifications_jewel a");
					if (num != 1)
					{
						GoToHome(chrome);
						num = chrome.Click(4, "#notifications_jewel a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						return 1;
					}
					return chrome.GotoURL("https://m.facebook.com/notifications.php?ref=bookmarks");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToMessages(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("#messages_jewel a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#messages_jewel a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "#messages_jewel a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "#messages_jewel a");
					}
					if (num == 1)
					{
						chrome.DelayThaoTacNho(1);
						return 1;
					}
					return chrome.GotoURL("https://m.facebook.com/messages/?entrypoint=jewel&no_hist=1&ref=bookmarks");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToMessagesUnread(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (GoToMessages(chrome) == 1 && chrome.Click(4, "[href=\"/messages/?folder=unread&refid=11&ref=bookmarks\"]") == 1)
					{
						chrome.DelayRandom(3, 5);
						return 1;
					}
					return chrome.GotoURL("https://m.facebook.com/messages/?folder=unread&ref=bookmarks");
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToSearch(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (chrome.CheckExistElement("#notifications_jewel a") == 1)
					{
						chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('#search_jewel a')");
						chrome.DelayThaoTacNho();
					}
					int num = chrome.Click(4, "#search_jewel a");
					if (num != 1)
					{
						GoToHome(chrome);
						chrome.DelayThaoTacNho(2);
						num = chrome.Click(4, "#search_jewel a");
					}
					if (num == 1 && chrome.CheckExistElement("#main-search-input") == 1)
					{
						chrome.DelayThaoTacNho(1);
						return 1;
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToSearchGroup(Chrome chrome, string tuKhoa, int tocDoGoVanBan = 0)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (GoToSearch(chrome) == 1)
					{
						bool flag = false;
						if (chrome.CheckExistElement("#main-search-input") == 1)
						{
							tuKhoa = Common.SpinText(tuKhoa, Base.rd);
							switch (tocDoGoVanBan)
							{
							case 0:
								chrome.SendKeys(Base.rd, 1, "main-search-input", tuKhoa, 0.1);
								break;
							case 1:
								chrome.SendKeys(1, "main-search-input", tuKhoa, 0.1);
								break;
							case 2:
								chrome.SendKeys(1, "main-search-input", tuKhoa);
								break;
							}
							chrome.DelayThaoTacNho();
							chrome.SendEnter(1, "main-search-input");
							chrome.DelayThaoTacNho(2);
							string cssSelector = chrome.GetCssSelector("[data-sigil=\"mlayer-hide-on-click search-tabbar-tab\"]", "href", "/search/groups");
							if (cssSelector != "")
							{
								if (chrome.Click(4, cssSelector) == 0)
								{
									if (chrome.Click(4, "[data-sigil=\" flyout-causal\"]") == 1)
									{
										chrome.DelayThaoTacNho();
										cssSelector = chrome.GetCssSelector("[data-sigil=\"mlayer-hide-on-click search-tabbar-tab\"]", "href", "/search/groups");
										if (cssSelector != "")
										{
											flag = true;
											chrome.Click(4, cssSelector);
											chrome.DelayThaoTacNho(2);
										}
									}
								}
								else
								{
									flag = true;
									chrome.DelayThaoTacNho(2);
								}
							}
						}
						if (!flag)
						{
							chrome.GotoURL("https://m.facebook.com/search/groups/?q=" + tuKhoa);
							chrome.DelayThaoTacNho(2);
							flag = true;
						}
						if (flag)
						{
							chrome.DelayThaoTacNho(1);
							return 1;
						}
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToSearchFriend(Chrome chrome, string tuKhoa, int tocDoGoVanBan = 0)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					if (GoToSearch(chrome) == 1)
					{
						bool flag = false;
						if (chrome.CheckExistElement("#main-search-input") == 1)
						{
							tuKhoa = Common.SpinText(tuKhoa, Base.rd);
							switch (tocDoGoVanBan)
							{
							case 0:
								chrome.SendKeys(Base.rd, 1, "main-search-input", tuKhoa, 0.1);
								break;
							case 1:
								chrome.SendKeys(1, "main-search-input", tuKhoa, 0.1);
								break;
							case 2:
								chrome.SendKeys(1, "main-search-input", tuKhoa);
								break;
							}
							chrome.DelayThaoTacNho();
							chrome.SendEnter(1, "main-search-input");
							chrome.DelayThaoTacNho(2);
							string cssSelector = chrome.GetCssSelector("[data-sigil=\"mlayer-hide-on-click search-tabbar-tab\"]", "href", "/search/people");
							if (cssSelector != "")
							{
								if (chrome.Click(4, cssSelector) == 0)
								{
									if (chrome.Click(4, "[data-sigil=\" flyout-causal\"]") == 1)
									{
										chrome.DelayThaoTacNho();
										cssSelector = chrome.GetCssSelector("[data-sigil=\"mlayer-hide-on-click search-tabbar-tab\"]", "href", "/search/people");
										if (cssSelector != "")
										{
											flag = true;
											chrome.Click(4, cssSelector);
											chrome.DelayThaoTacNho(2);
										}
									}
								}
								else
								{
									flag = true;
									chrome.DelayThaoTacNho(2);
								}
							}
						}
						if (!flag)
						{
							chrome.GotoURL("https://m.facebook.com/search/people/?q=" + tuKhoa + "&source=filter&isTrending=0");
							chrome.DelayThaoTacNho(2);
							flag = true;
						}
						if (flag)
						{
							chrome.DelayThaoTacNho(1);
							return 1;
						}
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToBirthday(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.GotoURL("https://m.facebook.com/browse/birthdays/") != -2)
					{
						chrome.DelayRandom(2, 5);
						return 1;
					}
					return -2;
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int GoToPoke(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.GotoURL("https://m.facebook.com/pokes/") != -2)
					{
						chrome.DelayRandom(2, 5);
						return 1;
					}
					return -2;
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int ScrollRandom(Chrome chrome, int from = 3, int to = 5)
		{
			try
			{
				if (chrome.CheckChromeClosed())
				{
					return -2;
				}
				int num = Base.rd.Next(from, to + 1);
				int num2 = Convert.ToInt32(chrome.ExecuteScript("return document.querySelector('html').getBoundingClientRect().y+''").ToString());
				if (chrome.ScrollSmooth(Base.rd.Next(chrome.GetSizeChrome().Y / 2, chrome.GetSizeChrome().Y)) == 1)
				{
					chrome.DelayRandom(1, 3);
					int num3 = Convert.ToInt32(chrome.ExecuteScript("return document.querySelector('html').getBoundingClientRect().y+''").ToString());
					if (num2 != num3)
					{
						for (int i = 0; i < num - 1; i++)
						{
							num2 = Convert.ToInt32(chrome.ExecuteScript("return document.querySelector('html').getBoundingClientRect().y+''").ToString());
							if (chrome.ScrollSmooth(((Base.rd.Next(1, 1000) % 5 != 0) ? 1 : (-1)) * Base.rd.Next(chrome.GetSizeChrome().Y / 2, chrome.GetSizeChrome().Y)) != -2)
							{
								chrome.DelayRandom(1, 3);
								num3 = Convert.ToInt32(chrome.ExecuteScript("return document.querySelector('html').getBoundingClientRect().y+''").ToString());
								if (num2 == num3)
								{
									break;
								}
								chrome.DelayRandom(1, 2);
								continue;
							}
							return -2;
						}
					}
					return 1;
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int CheckStatusChrome(Chrome chrome)
		{
			try
			{
				if (chrome != null)
				{
					if (chrome.CheckChromeClosed())
					{
						return -2;
					}
					switch (chrome.CheckExistElement("[jsselect=\"suggestionsSummaryList\"]"))
					{
					default:
						if (IsCheckpoint(chrome))
						{
							return -1;
						}
						break;
					case 1:
						return -3;
					case -2:
						return -2;
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		public static string GetUserAgentDefault()
		{
			string text = "";
			try
			{
				JSON_Settings jSON_Settings = new JSON_Settings("configGeneral");
				Chrome chrome = new Chrome
				{
					HideBrowser = true,
					PathExtension = ""
				};
				if (jSON_Settings.GetValueInt("typeBrowser") != 0)
				{
					chrome.LinkToOtherBrowser = jSON_Settings.GetValue("txtLinkToOtherBrowser");
				}
				if (chrome.Open(isGetUseragentDefault: true))
				{
					text = chrome.GetUseragent();
					text = text.Replace("Headless", "");
					chrome.Close();
				}
			}
			catch
			{
			}
			return text;
		}

		public static string LoginFacebookUsingCookie(Chrome chrome, string cookie, string URL = "https://www.facebook.com")
		{
			try
			{
				if (chrome.GotoURLIfNotExist(URL) == -2)
				{
					return "-2";
				}
				if (chrome.AddCookieIntoChrome(cookie) == -2)
				{
					return "-2";
				}
				if (chrome.Refresh() == -2)
				{
					return "-2";
				}
				return CheckLiveCookie(chrome).ToString() ?? "";
			}
			catch
			{
			}
			return "0";
		}

		public static int CheckTypeWebFacebookFromUrl(string url)
		{
			int result = 0;
			if (url.StartsWith("https://www.facebook") || url.StartsWith("https://facebook") || url.StartsWith("https://web.facebook"))
			{
				result = 1;
			}
			else if (url.StartsWith("https://m.facebook") || url.StartsWith("https://d.facebook") || url.StartsWith("https://mobile.facebook"))
			{
				result = 2;
			}
			else if (url.StartsWith("https://mbasic.facebook"))
			{
				result = 3;
			}
			return result;
		}

		public static int CheckFacebookWebsite(Chrome chrome, string url)
		{
			if (!chrome.CheckIsLive())
			{
				return -2;
			}
			int num = 0;
			for (int i = 0; i < 2; i++)
			{
				num = CheckTypeWebFacebookFromUrl(chrome.GetURL());
				if (num != 0)
				{
					break;
				}
				chrome.GotoURL(url);
				chrome.DelayTime(1.0);
			}
			return num;
		}

		public static List<string> GetListLinkFromWebsite(Chrome chrome)
		{
			List<string> result = new List<string>();
			try
			{
				result = chrome.ExecuteScript("var arr=[]; document.querySelectorAll('a').forEach(e=>{arr.push(e.href)});var s=arr.join('|'); return s").ToString().Split('|')
					.ToList();
			}
			catch
			{
			}
			return result;
		}

		public static int GotoLogin(Chrome chrome, int typeWeb)
		{
			bool flag = false;
			try
			{
				switch (typeWeb)
				{
				case 1:
					chrome.GotoURL("https://www.facebook.com/login");
					break;
				case 2:
					chrome.GotoURL("https://m.facebook.com/login");
					break;
				case 3:
					chrome.GotoURL("https://mbasic.facebook.com/login");
					break;
				}
				flag = true;
				chrome.DelayTime(1.0);
			}
			catch (Exception)
			{
			}
			return flag ? 1 : 0;
		}

		public static string LoginFacebookUsingUidPassNew(Chrome chrome, string uid, string pass, string fa2 = "", string Url = "https://m.facebook.com", int tocDoGoVanBan = 0, bool isDontSaveBrowser = false, int timeOut = 120)
		{
			int num = 0;
			int num2 = 0;
			int tickCount = Environment.TickCount;
			try
			{
				if (CheckTypeWebFacebookFromUrl(chrome.GetURL()) != CheckTypeWebFacebookFromUrl(Url))
				{
					chrome.GotoURL(Url);
				}
				while (true)
				{
					IL_1217:
					int num3 = CheckFacebookWebsite(chrome, chrome.GetURL());
					if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") != 1)
					{
						bool flag = chrome.CheckExistElement("[name=\"email\"]") == 1 && chrome.CheckExistElement("[name=\"pass\"]") == 1 && chrome.CheckExistElement("[name=\"login\"]") == 1;
						bool flag2 = chrome.CheckExistElements(0.0, "[ajaxify*=\"/login/device-based/async/remove/\"]", "[data-sigil=\"login_profile_form\"] div[role=\"button\"]", "[action=\"/login/device-based/validate-pin/\"] input[type=\"submit\"]") > 0;
						if (!flag && !flag2)
						{
							GotoLogin(chrome, num3);
							if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") == 1)
							{
								chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
							}
						}
					}
					else
					{
						chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
						if (chrome.CheckExistElement("[name=\"pass\"]") != 1)
						{
							GotoLogin(chrome, num3);
							if (chrome.CheckExistElement("[data-cookiebanner=\"accept_button\"]") == 1)
							{
								chrome.Click(4, "[data-cookiebanner=\"accept_button\"]");
							}
						}
					}
					if (!CheckCheckpoint(chrome))
					{
						int num4 = chrome.CheckExistElements(0.0, "[data-sigil=\"login_profile_form\"] div[role=\"button\"]", "[action=\"/login/device-based/validate-pin/\"] input[type=\"submit\"]");
						if (num3 == 2 && num4 > 0)
						{
							switch (num4)
							{
							case 2:
								chrome.ExecuteScript("document.querySelector('[action=\"/login/device-based/validate-pin/\"] input[type=\"submit\"]').click()");
								break;
							case 1:
								chrome.ExecuteScript("document.querySelector('[data-sigil=\"login_profile_form\"] div[role=\"button\"]').click()");
								break;
							}
							chrome.DelayTime(1.0);
							num2 = chrome.CheckExistElements(5.0, "[name=\"pass\"]", "#approvals_code");
							if (num2 == 1 && chrome.SendKeysWithSpeed(tocDoGoVanBan, 2, "pass", pass, 0.1) == 1)
							{
								chrome.DelayTime(1.0);
								if (chrome.Click(4, chrome.GetCssSelector("button", "data-sigil", "password_login_button")) == 1)
								{
									chrome.DelayTime(1.0);
								}
							}
							goto IL_04a0;
						}
						if (chrome.CheckExistElement("[data-sigil=\"touchable\"]") == 1 && chrome.CheckExistElement("#m_login_auto_search_form_forgot_password_button") != 1)
						{
							chrome.Click(4, "[data-sigil=\"touchable\"]");
						}
						int num5 = 1;
						bool flag3 = false;
						int num6 = 1;
						int num7 = 1;
						while (true)
						{
							IL_046b:
							num2 = chrome.SendKeysWithSpeed(tocDoGoVanBan, 2, "email", uid, 0.1);
							while (true)
							{
								if (num2 != -2)
								{
									chrome.DelayTime(1.0);
									num5++;
									if (!flag3)
									{
										switch (num5)
										{
										default:
											flag3 = true;
											continue;
										case 2:
											num2 = chrome.SendKeysWithSpeed(tocDoGoVanBan, 2, "pass", pass, 0.1);
											continue;
										case 3:
											num2 = chrome.SendEnter(2, "pass");
											chrome.DelayTime(3.0);
											flag3 = true;
											continue;
										case 1:
											break;
										}
										goto IL_046b;
									}
									goto IL_04a0;
								}
								num = -2;
								break;
							}
							break;
						}
						break;
					}
					num = 2;
					break;
					IL_04a0:
					Dictionary<int, List<string>> dic = new Dictionary<int, List<string>>
					{
						{
							1,
							new List<string> { "[name=\"login\"]", "[name=\"reset_action\"]" }
						},
						{
							2,
							new List<string> { "[name=\"approvals_code\"]" }
						},
						{
							3,
							new List<string> { "#checkpoint_title" }
						},
						{
							4,
							new List<string> { "#checkpointSubmitButton", "#checkpointBottomBar" }
						},
						{
							5,
							new List<string> { "#qf_skip_dialog_skip_link" }
						},
						{
							6,
							new List<string> { "#nux-nav-button" }
						},
						{
							7,
							new List<string> { "[name=\"n\"]" }
						},
						{
							8,
							new List<string> { "#identify_search_text_input" }
						}
					};
					int num8 = 0;
					int num9 = 0;
					while (Environment.TickCount - tickCount < timeOut * 1000)
					{
						switch (chrome.CheckExistElements(0.0, dic))
						{
						default:
							if (!chrome.GetURL().Contains("facebook.com/confirm"))
							{
								if (!CheckCheckpoint(chrome))
								{
									if (chrome.CheckExistElement("a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]") == 1)
									{
										chrome.ExecuteScript("document.querySelector('a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]').click()");
										chrome.DelayTime(3.0);
										if (chrome.CheckExistElement("[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button", 10.0) == 1)
										{
											chrome.ExecuteScript("document.querySelector('[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button').click()");
											chrome.DelayTime(3.0);
										}
									}
									else if (CheckTypeWebFacebookFromUrl(chrome.GetURL()) == 2)
									{
										if (chrome.GetURL().StartsWith("https://m.facebook.com/zero/policy/optin"))
										{
											chrome.DelayTime(1.0);
											chrome.ExecuteScript("document.querySelector('a[data-sigil=\"touchable\"]').click()");
											chrome.DelayTime(3.0);
											if (chrome.CheckExistElement("button[data-sigil=\"touchable\"]", 10.0) == 1)
											{
												chrome.DelayTime(1.0);
												chrome.ExecuteScript("document.querySelector('button[data-sigil=\"touchable\"]').click()");
												chrome.DelayTime(3.0);
											}
										}
										if (Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
										{
											for (int i = 0; i < 5; i++)
											{
												Common.DelayTime(2.0);
												if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
												{
													break;
												}
											}
											for (int j = 0; j < 5; j++)
											{
												Common.DelayTime(2.0);
												if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('consent/basic/log')){x[i].click();break;check='true'}} return check")))
												{
													break;
												}
											}
											if (chrome.CheckExistElement("[href=\"/home.php\"]") == 1)
											{
												chrome.Click(4, "[href=\"/home.php\"]");
											}
										}
										while (chrome.GetURL().StartsWith("https://m.facebook.com/legal_consent"))
										{
											switch (Convert.ToInt32(chrome.ExecuteScript("return document.querySelectorAll('button').length").ToString()))
											{
											case 3:
												chrome.Click(4, "button");
												break;
											case 4:
												chrome.Click(4, "button", 1);
												break;
											}
											chrome.DelayTime(2.0);
										}
										if (chrome.GetURL().StartsWith("https://m.facebook.com/si/actor_experience/actor_gateway") && chrome.CheckExistElement("[data-nt=\"NT:IMAGE\"]", 15.0) == 1)
										{
											chrome.ExecuteScript("document.querySelector('[data-nt=\"NT:IMAGE\"]').click()");
											chrome.DelayTime(2.0);
										}
										if (chrome.CheckExistElement("button[value=\"OK\"]") == 1)
										{
											chrome.Click(4, "button[value=\"OK\"]");
											chrome.DelayTime(1.0);
										}
										if (chrome.CheckExistElement("[data-store-id=\"2\"]>span") == 1)
										{
											chrome.Click(4, "[data-store-id=\"2\"]>span");
											chrome.DelayTime(1.0);
										}
										if (chrome.CheckExistElement("[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span") == 1)
										{
											chrome.Click(4, "[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span");
											chrome.DelayTime(3.0);
										}
									}
									else if (chrome.GetURL().StartsWith("https://www.facebook.com/legal_consent"))
									{
										for (int k = 0; k < 5; k++)
										{
											if (chrome.CheckExistElement("button") != 1)
											{
												break;
											}
											chrome.ExecuteScript("document.querySelector('button').click()");
											chrome.DelayTime(1.0);
										}
									}
									if (CheckLoginSuccess(chrome))
									{
										num = 1;
									}
									goto IL_1109;
								}
								num = 2;
							}
							else
							{
								num = 1;
							}
							goto end_IL_0012;
						case 1:
							if (num8 == 0 && num9 == 0)
							{
								string text = "";
								switch (CheckTypeWebFacebookFromUrl(chrome.GetURL()))
								{
								case 2:
									text = chrome.ExecuteScript("var out='';var x=document.querySelector('#login_error');if(x!=null) out=x.innerText;return out;").ToString();
									break;
								case 1:
									text = chrome.ExecuteScript("var out='';var x=document.querySelector('#error_box');if(x!=null) out=x.innerText;return out;").ToString();
									text = ((text.Split(new string[1] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries).Count() > 1) ? text.Split(new string[1] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries)[1] : text);
									break;
								}
								if (!(text != ""))
								{
									if (chrome.CheckExistElement("[href=\"/login/identify/\"]") == 1)
									{
										num = 4;
									}
									else if (chrome.CheckExistElement("#account_recovery_initiate_view_label") == 1)
									{
										num = 5;
									}
									else if (!Convert.ToBoolean(chrome.ExecuteScript("return (document.querySelector('[name=\"email\"]').value!='' && document.querySelector('[name=\"pass\"]').value!='')+''").ToString()))
									{
										if (chrome.ExecuteScript("return document.querySelector('[name=\"email\"]').value").ToString().Trim() == "")
										{
											num = 4;
										}
										else if (chrome.ExecuteScript("return document.querySelector('[name=\"pass\"]').value").ToString().Trim() == "")
										{
											num = 5;
										}
									}
									goto IL_1109;
								}
								return text;
							}
							if (!(chrome.ExecuteScript("return document.querySelector('[name=\"email\"]').value").ToString().Trim() == ""))
							{
								goto IL_1109;
							}
							num = 0;
							goto end_IL_0012;
						case 2:
							if (fa2 == "")
							{
								num = 3;
								goto IL_1109;
							}
							num8++;
							if (num8 <= 2)
							{
								string totp = Common.GetTotp(fa2.Replace(" ", "").Replace("\n", "").Trim());
								if (!string.IsNullOrEmpty(totp))
								{
									chrome.SendKeysWithSpeed(tocDoGoVanBan, 2, "approvals_code", totp, 0.1);
									chrome.DelayTime(1.0);
									chrome.SendEnter(2, "approvals_code");
									chrome.DelayTime(1.0);
									goto IL_1109;
								}
								num = 6;
							}
							else
							{
								num = 6;
							}
							goto end_IL_0012;
						case 3:
							if (num8 > 1)
							{
								num = 6;
								goto IL_1109;
							}
							if (!CheckCheckpoint(chrome))
							{
								num2 = chrome.CheckExistElements(0.0, "button#checkpointSubmitButton", "#checkpointSubmitButton [type=\"submit\"]");
								num9++;
								if (num9 <= 10)
								{
									if (chrome.CheckExistElement("[value=\"dont_save\"]") == 1 && isDontSaveBrowser)
									{
										chrome.Click(4, "[value=\"dont_save\"]");
									}
									if (num2 == 1)
									{
										chrome.Click(4, "button#checkpointSubmitButton");
									}
									else
									{
										chrome.Click(4, "#checkpointSubmitButton [type=\"submit\"]");
									}
									chrome.DelayTime(1.0);
									goto IL_1109;
								}
							}
							else
							{
								num = 2;
							}
							goto end_IL_0012;
						case 4:
							if (num8 > 1)
							{
								num = 6;
								goto IL_1109;
							}
							if (!CheckCheckpoint(chrome))
							{
								num2 = chrome.CheckExistElements(0.0, "button#checkpointSubmitButton", "#checkpointSubmitButton [type=\"submit\"]");
								num9++;
								if (num9 <= 10)
								{
									if (chrome.CheckExistElement("[value=\"dont_save\"]") == 1 && isDontSaveBrowser)
									{
										chrome.Click(4, "[value=\"dont_save\"]");
									}
									if (num2 == 1)
									{
										chrome.Click(4, "button#checkpointSubmitButton");
									}
									else
									{
										chrome.Click(4, "#checkpointSubmitButton [type=\"submit\"]");
									}
									chrome.DelayTime(1.0);
									goto IL_1109;
								}
							}
							else
							{
								num = 2;
							}
							goto end_IL_0012;
						case 5:
							chrome.ClickWithAction(1, "qf_skip_dialog_skip_link");
							chrome.DelayTime(2.0);
							goto IL_1109;
						case 6:
							chrome.Click(1, "nux-nav-button");
							chrome.DelayTime(2.0);
							goto IL_1109;
						case 7:
							num = 5;
							goto IL_1109;
						case 8:
							break;
							IL_1109:
							if (num == 0)
							{
								continue;
							}
							goto end_IL_0012;
						}
						chrome.GotoURL("https://www.facebook.com");
						chrome.DelayTime(1.0);
						goto IL_1217;
					}
					break;
				}
				end_IL_0012:;
			}
			catch (Exception ex)
			{
				Common.ExportError(chrome, ex, "Error Login Uid Pass");
			}
			return num.ToString() ?? "";
		}

		public static string GetInfoAccountFromUidUsingCookie(Chrome chrome)
		{
			string text = "";
			bool flag = false;
			string text2 = "";
			string text3 = "";
			string text4 = "";
			string text5 = "";
			string text6 = "";
			string text7 = "";
			string text8 = "";
			string text9 = "";
			string text10 = "";
			string text11 = "";
			try
			{
				string cookieFromChrome = chrome.GetCookieFromChrome();
				string value = Regex.Match(cookieFromChrome + ";", "c_user=(.*?);").Groups[1].Value;
				string input = RequestGet(chrome, GetHostFacebook(chrome, 3) + "/friends/center/friends/?mff_nav=1", GetHostFacebook(chrome, 3));
				text7 = Regex.Match(input, "bm bn\">(.*?)<").Groups[1].Value.Replace(",", "").Replace(".", "");
				if (text7 == "")
				{
					text7 = Regex.Match(input, "bm\">(.*?)<").Groups[1].Value.Replace(",", "").Replace(".", "");
				}
				text7 = Regex.Match(text7, "\\d+").Value;
				input = RequestGet(chrome, GetHostFacebook(chrome, 3) + "/groups/?seemore&refid=27", GetHostFacebook(chrome, 3));
				text8 = Regex.Matches(input, "class=\"bl\"").Count.ToString();
				if (text8 == "0")
				{
					text8 = Regex.Matches(input, "class=\"bm\"").Count.ToString();
				}
				try
				{
					input = RequestGet(chrome, GetHostFacebook(chrome) + "/composer/ocelot/async_loader/?publisher=feed", GetHostFacebook(chrome));
					string value2 = Regex.Match(input, "fb_dtsg\\\\\" value=\\\\\"(.*?)\\\\\"").Groups[1].Value;
					text9 = Regex.Match(input, "EAAA(.*?)\"").Value.TrimEnd('"', '\\');
					string data = "av=" + value + "&__user=" + value + "&__a=1&__dyn=&__csr=&__req=y&__hs=18794.EXP2%3Acomet_pkg.2.1.0.0&dpr=1&__ccg=EXCELLENT&__rev=1003974565&__s=zbue97%3A5iciql%3Abxnvge&__hsi=6974199735511561326-0&__comet_req=1&fb_dtsg=" + value2 + "&jazoest=22414&lsd=&__spin_r=1003974565&__spin_b=trunk&__spin_t=1623807413&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PrivacyAccessHubYourInformationSectionQuery&variables=%7B%7D&server_timestamps=true&doc_id=3200030856767767";
					input = RequestPost(chrome, GetHostFacebook(chrome, 1) + "/api/graphql/", data, GetHostFacebook(chrome, 1) + "/api/graphql/");
					JObject jObject = JObject.Parse(input);
					text10 = jObject["data"]!["section"]!["tiles"]![1]!["links"]![0]!["non_link_content"]!["metadata"]!.ToString();
				}
				catch
				{
				}
				string infoAccountFromUidUsingToken = GetInfoAccountFromUidUsingToken(chrome, text9);
				string[] array = infoAccountFromUidUsingToken.Split('|');
				text2 = array[1];
				text3 = array[2];
				text4 = array[3];
				text6 = array[5];
				if (text11 == "")
				{
					text11 = "0";
				}
				if (text7 == "")
				{
					text7 = "0";
				}
				if (text8 == "")
				{
					text8 = "0";
				}
			}
			catch (Exception ex)
			{
				if (CheckLiveCookie(chrome, "https://m.facebook.com/") == 0)
				{
					return "-1";
				}
				CommonCSharp.ExportError(null, ex.ToString());
			}
			return $"{flag}|{text2}|{text3}|{text4}|{text5}|{text6}|{text7}|{text8}|{text9}|{text10}|{text11}";
		}

		public static string GetInfoAccountFromUidUsingToken(Chrome chrome, string token)
		{
			string text = "";
			bool flag = false;
			string text2 = "";
			string text3 = "";
			string text4 = "";
			string text5 = "";
			string text6 = "";
			string text7 = "";
			string text8 = "";
			try
			{
				string json = RequestGet(chrome, "https://graph.facebook.com/v2.11/me?fields=name,email,gender,birthday&access_token=" + token, "https://graph.facebook.com/");
				JObject jObject = JObject.Parse(json);
				flag = true;
				text2 = jObject["name"]!.ToString();
				try
				{
					text3 = jObject["gender"]!.ToString();
				}
				catch
				{
				}
				try
				{
					text4 = jObject["birthday"]!.ToString();
				}
				catch
				{
				}
				try
				{
					text6 = jObject["email"]!.ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
			return $"{flag}|{text2}|{text3}|{text4}|{text5}|{text6}|{text7}|{text8}";
		}

		public static string GetTokenEAAAAZ(Chrome chrome)
		{
			string result = "";
			try
			{
				string input = RequestGet(chrome, "https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed", "https://m.facebook.com");
				result = Regex.Match(input, "EAAAAZ(.*?)\"").Value.Replace("\"", "").Replace("\\", "");
			}
			catch
			{
			}
			return result;
		}

		public static int CheckLiveCookie(Chrome chrome, string url = "https://m.facebook.com")
		{
			try
			{
				if (chrome.CheckChromeClosed())
				{
					return -2;
				}
				if (CheckTypeWebFacebookFromUrl(chrome.GetURL()) != CheckTypeWebFacebookFromUrl(url))
				{
					chrome.GotoURL(url);
				}
				string uRL = chrome.GetURL();
				if (uRL.Contains("facebook.com/checkpoint/") || uRL.Contains("facebook.com/nt/screen/?params=%7B%22token") || uRL.Contains("facebook.com/x/checkpoint/"))
				{
					return 2;
				}
				switch (CheckFacebookWebsite(chrome, url))
				{
				case 2:
				{
					if (chrome.CheckExistElement("a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]", 5.0) == 1)
					{
						chrome.ExecuteScript("document.querySelector('a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]').click()");
						chrome.DelayTime(3.0);
						if (chrome.CheckExistElement("[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button", 10.0) == 1)
						{
							chrome.ExecuteScript("document.querySelector('[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button').click()");
							chrome.DelayTime(3.0);
						}
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/zero/optin/write/"))
					{
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button').click()");
						chrome.DelayTime(3.0);
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/zero/policy/optin"))
					{
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('a[data-sigil=\"touchable\"]').click()");
						chrome.DelayTime(3.0);
						if (chrome.CheckExistElement("button[data-sigil=\"touchable\"]", 10.0) == 1)
						{
							chrome.DelayTime(1.0);
							chrome.ExecuteScript("document.querySelector('button[data-sigil=\"touchable\"]').click()");
							chrome.DelayTime(3.0);
						}
					}
					if (Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
					{
						for (int j = 0; j < 5; j++)
						{
							Common.DelayTime(2.0);
							if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
							{
								break;
							}
						}
						for (int k = 0; k < 5; k++)
						{
							Common.DelayTime(2.0);
							if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('consent/basic/log')){x[i].click();break;check='true'}} return check")))
							{
								break;
							}
						}
						if (chrome.CheckExistElement("[href=\"/home.php\"]") == 1)
						{
							chrome.Click(4, "[href=\"/home.php\"]");
						}
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/legal_consent"))
					{
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelectorAll('button')[1].click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelectorAll('button')[1].click()");
						chrome.DelayTime(1.0);
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/si/actor_experience/actor_gateway"))
					{
						chrome.Click(4, "[data-sigil=\"touchable\"]");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("button[value=\"OK\"]") == 1)
					{
						chrome.Click(4, "button[value=\"OK\"]");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("[data-store-id=\"2\"]>span") == 1)
					{
						chrome.Click(4, "[data-store-id=\"2\"]>span");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span") == 1)
					{
						chrome.Click(4, "[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span");
						chrome.DelayTime(3.0);
					}
					if (chrome.CheckExistElement("#nux-nav-button") != 1)
					{
						break;
					}
					bool flag = false;
					for (int l = 0; l < 5; l++)
					{
						if (flag)
						{
							break;
						}
						switch (chrome.CheckExistElements(3.0, "#qf_skip_dialog_skip_link", "#nux-nav-button"))
						{
						default:
							flag = true;
							break;
						case 2:
							chrome.Click(1, "nux-nav-button");
							chrome.DelayTime(2.0);
							break;
						case 1:
							chrome.ExecuteScript("document.querySelector('#qf_skip_dialog_skip_link').click()");
							chrome.DelayTime(1.0);
							break;
						}
					}
					break;
				}
				case 1:
				{
					if (!chrome.GetURL().StartsWith("https://www.facebook.com/legal_consent"))
					{
						break;
					}
					for (int i = 0; i < 5; i++)
					{
						if (chrome.CheckExistElement("button") != 1)
						{
							break;
						}
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
					}
					break;
				}
				}
				CheckStatusAccount(chrome, isSendRequest: true);
				switch (chrome.Status)
				{
				case StatusChromeAccount.ChromeClosed:
					return -2;
				case StatusChromeAccount.LoginWithUserPass:
				case StatusChromeAccount.LoginWithSelectAccount:
					return 0;
				case StatusChromeAccount.Checkpoint:
					return 2;
				case StatusChromeAccount.Logined:
					return 1;
				case StatusChromeAccount.NoInternet:
					return -3;
				case StatusChromeAccount.Blocked:
					break;
				case StatusChromeAccount.Noveri:
					return 3;
				}
			}
			catch
			{
			}
			return 0;
		}

		public static int CheckLiveCookieWhenGiaiCP(Chrome chrome, string url = "https://m.facebook.com")
		{
			try
			{
				if (chrome.CheckChromeClosed())
				{
					return -2;
				}
				if (chrome.GetURL().Contains("https://m.facebook.com/x/checkpoint/hacked_cleanup") || chrome.CheckExistElement("#checkpointButtonGetStarted") == 1)
				{
					return 1;
				}
				if (CheckTypeWebFacebookFromUrl(chrome.GetURL()) == 0)
				{
					chrome.GotoURL(url);
				}
				switch (CheckFacebookWebsite(chrome, url))
				{
				case 2:
					if (chrome.CheckExistElement("a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]", 5.0) == 1)
					{
						chrome.ExecuteScript("document.querySelector('a[href*=\"/zero/optin/write/?action=cancel&page=dialtone_optin_page\"]').click()");
						chrome.DelayTime(3.0);
						if (chrome.CheckExistElement("[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button", 10.0) == 1)
						{
							chrome.ExecuteScript("document.querySelector('[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button').click()");
							chrome.DelayTime(3.0);
						}
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/zero/optin/write/"))
					{
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('[action=\"/zero/optin/write/?action=confirm&page=reconsider_optin_dialog\"] button').click()");
						chrome.DelayTime(3.0);
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/zero/policy/optin"))
					{
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('a[data-sigil=\"touchable\"]').click()");
						chrome.DelayTime(3.0);
						if (chrome.CheckExistElement("button[data-sigil=\"touchable\"]", 10.0) == 1)
						{
							chrome.DelayTime(1.0);
							chrome.ExecuteScript("document.querySelector('button[data-sigil=\"touchable\"]').click()");
							chrome.DelayTime(3.0);
						}
					}
					if (Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
					{
						for (int j = 0; j < 5; j++)
						{
							Common.DelayTime(2.0);
							if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('legal_consent/basic/?consent_step=1')){x[i].click();break;check='true'}} return check")))
							{
								break;
							}
						}
						for (int k = 0; k < 5; k++)
						{
							Common.DelayTime(2.0);
							if (!Convert.ToBoolean(chrome.ExecuteScript("var check='false';var x=document.querySelectorAll('a');for(i=0;i<x.length;i++){if(x[i].href.includes('consent/basic/log')){x[i].click();break;check='true'}} return check")))
							{
								break;
							}
						}
						if (chrome.CheckExistElement("[href=\"/home.php\"]") == 1)
						{
							chrome.Click(4, "[href=\"/home.php\"]");
						}
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/legal_consent"))
					{
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelectorAll('button')[1].click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
						chrome.ExecuteScript("document.querySelectorAll('button')[1].click()");
						chrome.DelayTime(1.0);
					}
					if (chrome.GetURL().StartsWith("https://m.facebook.com/si/actor_experience/actor_gateway"))
					{
						chrome.Click(4, "[data-sigil=\"touchable\"]");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("button[value=\"OK\"]") == 1)
					{
						chrome.Click(4, "button[value=\"OK\"]");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("[data-store-id=\"2\"]>span") == 1)
					{
						chrome.Click(4, "[data-store-id=\"2\"]>span");
						chrome.DelayTime(1.0);
					}
					if (chrome.CheckExistElement("[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span") == 1)
					{
						chrome.Click(4, "[data-nt=\"FB:HEADER_FOOTER_VIEW\"]>div>div>div>span>span");
						chrome.DelayTime(3.0);
					}
					break;
				case 1:
				{
					if (!chrome.GetURL().StartsWith("https://www.facebook.com/legal_consent"))
					{
						break;
					}
					for (int i = 0; i < 5; i++)
					{
						if (chrome.CheckExistElement("button") != 1)
						{
							break;
						}
						chrome.ExecuteScript("document.querySelector('button').click()");
						chrome.DelayTime(1.0);
					}
					break;
				}
				}
				CheckStatusAccount(chrome, isSendRequest: true);
				switch (chrome.Status)
				{
				case StatusChromeAccount.ChromeClosed:
					return -2;
				case StatusChromeAccount.LoginWithUserPass:
				case StatusChromeAccount.LoginWithSelectAccount:
					return 0;
				case StatusChromeAccount.Checkpoint:
					return 2;
				case StatusChromeAccount.Logined:
					return 1;
				case StatusChromeAccount.NoInternet:
					return -3;
				}
			}
			catch
			{
			}
			return 0;
		}

		public static bool IsCheckpoint(Chrome chrome)
		{
			try
			{
				if (chrome.CheckExistElements(0.0, "#checkpointSubmitButton", "#captcha_response", "[name=\"verification_method\"]", "#checkpointBottomBar", "[href =\"https://www.facebook.com/communitystandards/\"]") > 0)
				{
					return true;
				}
			}
			catch
			{
			}
			return false;
		}

		public static bool IsCheckpointWhenLogin(Chrome chrome)
		{
			try
			{
				if (chrome.CheckExistElements(0.0, "[name=\"captcha_response\"]", "#captcha_response", "[name=\"password_new\"]", "[name=\"verification_method\"]", "[href =\"https://www.facebook.com/communitystandards/\"]") > 0)
				{
					return true;
				}
			}
			catch
			{
			}
			return false;
		}

		public static string GetTokenEAAG(Chrome chrome)
		{
			string result = "";
			try
			{
				if (!chrome.GetURL().Contains("https://business.facebook.com/"))
				{
					chrome.GotoURL("https://business.facebook.com/");
				}
				result = (string)chrome.ExecuteScript("async function GetTokenEaag() { var output = ''; try { var response = await fetch('https://business.facebook.com/business_locations/'); if (response.ok) { var body = await response.text(); output=body.match(new RegExp('EAAG(.*?)\"'))[0].replace('\"',''); } } catch {} return output; }; var c = await GetTokenEaag(); return c;");
			}
			catch
			{
			}
			return result;
		}

		public static string RequestGet(Chrome chrome, string url, string website)
		{
			try
			{
				if (website.Split('/').Length > 2)
				{
					website = website.Replace("//", "__");
					website = website.Split('/')[0];
					website = website.Replace("__", "//");
				}
				if (!chrome.GetURL().StartsWith(website))
				{
					chrome.GotoURL(website);
					chrome.DelayTime(1.0);
					chrome.ExecuteScript("document.querySelector('body').innerHTML='MIN SOFTWARE'; document.querySelector('body').style = 'text-align: center; background-color:#fff'");
				}
				return (string)chrome.ExecuteScript("async function RequestGet() { var output = ''; try { var response = await fetch('" + url + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await RequestGet(); return c;");
			}
			catch
			{
			}
			return "";
		}

		public static string RequestPost(Chrome chrome, string url, string data, string website, string contentType = "application/x-www-form-urlencoded")
		{
			try
			{
				if (!chrome.GetURL().StartsWith(website))
				{
					chrome.GotoURL(website);
					chrome.DelayTime(1.0);
					chrome.ExecuteScript("document.querySelector('body').innerHTML='MIN SOFTWARE'; document.querySelector('body').style = 'text-align: center; background-color:#fff'");
				}
				chrome.DelayTime(1.0);
				data = data.Replace("\n", "\\n").Replace("\"", "\\\"");
				return (string)chrome.ExecuteScript("async function RequestPost() { var output = ''; try { var response = await fetch('" + url + "', { method: 'POST', body: '" + data + "', headers: { 'Content-Type': '" + contentType + "' } }); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await RequestPost(); return c;");
			}
			catch
			{
			}
			return "";
		}

		public static string GetBirthday(Chrome chrome, string token)
		{
			string result = "";
			try
			{
				if (!chrome.GetURL().Contains("https://graph.facebook.com/"))
				{
					chrome.GotoURL("https://graph.facebook.com/");
				}
				string json = (string)chrome.ExecuteScript("async function RequestGet() { var output = ''; try { var response = await fetch('https://graph.facebook.com/me?fields=id,birthday,name&access_token=" + token + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await RequestGet(); return c;");
				JObject jObject = JObject.Parse(json);
				return jObject["id"]!.ToString() + "|" + jObject["birthday"]!.ToString() + "|" + jObject["name"]!.ToString();
			}
			catch
			{
			}
			return result;
		}

		public static List<string> GetMyListUidMessage(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				if (!chrome.GetURL().Contains("https://mbasic.facebook.com/"))
				{
					chrome.GotoURL("https://mbasic.facebook.com/");
				}
				string input = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://mbasic.facebook.com/messages/'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
				int num = 1;
				string text = "";
				string text2 = "";
				do
				{
					MatchCollection matchCollection = Regex.Matches(input, "#fua\">(.*?)<");
					for (int i = 0; i < matchCollection.Count; i++)
					{
						try
						{
							text2 = matchCollection[i].Groups[1].Value.Replace("\"", "");
							text2 = WebUtility.HtmlDecode(text2);
							if (!list.Contains(text2))
							{
								list.Add(text2);
							}
						}
						catch
						{
						}
					}
					text = Regex.Match(input, "/messages/.pageNum=(.*?)\"").Value.Replace("amp;", "");
					input = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://mbasic.facebook.com" + text + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
					num++;
				}
				while (num < 5 && text != "");
			}
			catch
			{
			}
			return list;
		}

		public static List<string> GetMyListComments(Chrome chrome, int numberMonth)
		{
			List<string> list = new List<string>();
			try
			{
				if (!chrome.GetURL().Contains("https://mbasic.facebook.com/"))
				{
					chrome.GotoURL("https://mbasic.facebook.com/");
				}
				string format = "https://mbasic.facebook.com/{0}/allactivity/?category_key=commentscluster&timestart={1}&timeend={2}";
				string text = chrome.ExecuteScript("return (document.cookie + ';').match(new RegExp('c_user=(.*?);'))[1]").ToString();
				string text2 = "";
				string text3 = "";
				string text4 = "";
				string text5 = "";
				MatchCollection matchCollection = null;
				List<string> list2 = new List<string>();
				for (int i = 0; i < numberMonth; i++)
				{
					DateTime dateTime = DateTime.Now.AddMonths(2 - i);
					DateTime dateTime2 = DateTime.Now.AddMonths(1 - i);
					text2 = Common.ConvertDatetimeToTimestamp(new DateTime(dateTime.Year, dateTime.Month, 1)).ToString();
					text3 = Common.ConvertDatetimeToTimestamp(new DateTime(dateTime2.Year, dateTime2.Month, 1)).ToString();
					text4 = string.Format(format, text, text2, text3);
					list2.Add(text4);
				}
				for (int j = 0; j < list2.Count; j++)
				{
					text4 = list2[j];
					bool flag = false;
					do
					{
						flag = false;
						text5 = RequestGet(chrome, text4, "https://mbasic.facebook.com/");
						text5 = WebUtility.HtmlDecode(text5);
						matchCollection = Regex.Matches(text5, "<span>(.*?)</h4>");
						for (int k = 0; k < matchCollection.Count; k++)
						{
							string value = matchCollection[k].Groups[1].Value;
							value = value.Substring(0, value.LastIndexOf('<'));
							MatchCollection matchCollection2 = Regex.Matches(value, "<(.*?)>");
							for (int l = 0; l < matchCollection2.Count; l++)
							{
								value = value.Replace(matchCollection2[l].Value, "");
							}
							if (value != "" && !list.Contains(value))
							{
								list.Add(value);
							}
						}
						if (Regex.IsMatch(text5, "/" + text + "/allactivity/\\?category_key=commentscluster&timeend(.*?)\""))
						{
							text4 = "https://mbasic.facebook.com" + Regex.Match(text5, "/" + text + "/allactivity/\\?category_key=commentscluster&timeend(.*?)\"").Value.Replace("\"", "");
							flag = true;
						}
					}
					while (flag);
				}
			}
			catch
			{
			}
			return list;
		}

		public static List<string> GetMyListUidNameFriend(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				string tokenEAAAAZ = GetTokenEAAAAZ(chrome);
				if (!chrome.GetURL().Contains("https://graph.facebook.com/"))
				{
					chrome.GotoURL("https://graph.facebook.com/");
				}
				string json = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://graph.facebook.com/me/friends?limit=5000&fields=id,name&access_token=" + tokenEAAAAZ + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
				JObject jObject = JObject.Parse(json);
				if (jObject["data"].Count() > 0)
				{
					for (int i = 0; i < jObject["data"].Count(); i++)
					{
						string text = jObject["data"]![i]!["id"]!.ToString();
						string text2 = jObject["data"]![i]!["name"]!.ToString();
						list.Add(text + "|" + text2);
					}
				}
			}
			catch
			{
			}
			return list;
		}

		internal static void CheckStatusAccount(Chrome chrome, bool isSendRequest)
		{
			try
			{
				if (chrome.CheckChromeClosed())
				{
					chrome.Status = StatusChromeAccount.ChromeClosed;
					return;
				}
				string text = "";
				if (isSendRequest)
				{
					string uRL = chrome.GetURL();
					uRL = Regex.Match(uRL, "https://(.*?)facebook.com").Value + "/login";
					text = RequestGet(chrome, uRL, uRL);
				}
				else
				{
					text = chrome.GetPageSource();
				}
				if (text == "-2")
				{
					chrome.Status = StatusChromeAccount.ChromeClosed;
				}
				else if (Regex.IsMatch(text, "login_form") || text.Contains("/login/?next"))
				{
					if (chrome.CheckExistElement("[href*=\"/login/?next\"]") == 1)
					{
						chrome.Click(4, "[href*=\"/login/?next\"]");
					}
					chrome.Status = StatusChromeAccount.LoginWithUserPass;
				}
				else if (Regex.IsMatch(text, "login_profile_form") || Regex.IsMatch(text, "/login/device-based/validate-p"))
				{
					chrome.Status = StatusChromeAccount.LoginWithSelectAccount;
				}
				else if (Convert.ToBoolean(chrome.ExecuteScript("var kq=false;if(document.querySelector('#mErrorView')!=null && !document.querySelector('#mErrorView').getAttribute('style').includes('display:none')) kq=true;return kq+''")) || Regex.IsMatch(text, "href=\"https://m.facebook.com/login.php"))
				{
					chrome.Status = StatusChromeAccount.LoginWithSelectAccount;
				}
				else if (CheckNoveri(chrome))
				{
					chrome.Status = StatusChromeAccount.Noveri;
				}
				else if (CheckCheckpoint(chrome))
				{
					chrome.Status = StatusChromeAccount.Checkpoint;
				}
				else if (text.Contains("error-information-popup-content") || text.Contains("suggestionsSummaryList"))
				{
					chrome.Status = StatusChromeAccount.NoInternet;
				}
				else if (CheckLoginSuccess(chrome))
				{
					chrome.Status = StatusChromeAccount.Logined;
				}
			}
			catch
			{
			}
		}

		public static bool CheckNoveri(Chrome chrome, string currentUrl = "", string html = "")
		{
			if (currentUrl == "")
			{
				currentUrl = chrome.GetURL();
			}
			List<string> lstKerword = new List<string> { "facebook.com/confirmemail.php" };
			if (CheckStringContainKeyword(currentUrl, lstKerword))
			{
				return true;
			}
			List<string> list = new List<string> { "[name=\"c\"]" };
			if (chrome.CheckExistElements(0.0, list.ToArray()) > 0)
			{
				return true;
			}
			return false;
		}

		public static bool CheckCheckpoint(Chrome chrome, string currentUrl = "", string html = "")
		{
			if (currentUrl == "")
			{
				currentUrl = chrome.GetURL();
			}
			List<string> lstKerword = new List<string> { "facebook.com/checkpoint/828281030927956", "facebook.com/checkpoint/1501092823525282", "facebook.com/nt/screen/?params=%7B%22token", "facebook.com/x/checkpoint/" };
			if (CheckStringContainKeyword(currentUrl, lstKerword))
			{
				return true;
			}
			if (html == "")
			{
				html = chrome.GetPageSource();
			}
			List<string> lstKerword2 = new List<string>
			{
				"verification_method", "submit[Yes]", "send_code", "/checkpoint/dyi", "captcha_response", "https://www.facebook.com/communitystandards/", "help/121104481304395", "help/166863010078512", "help/117450615006715", "checkpoint/1501092823525282",
				"checkpoint/828281030927956", "name=\"code_1\""
			};
			if (CheckStringContainKeyword(html, lstKerword2))
			{
				return true;
			}
			List<string> list = new List<string> { "[name=\"verification_method\"]", "[name=\"submit[Yes]\"]", "[name=\"send_code\"]", "#captcha_response", "[href=\"https://www.facebook.com/communitystandards/\"]", "[name=\"code_1\"]", "[action=\"/login/checkpoint/\"] [name=\"contact_index\"]" };
			if (chrome.CheckExistElements(0.0, list.ToArray()) > 0)
			{
				return true;
			}
			return false;
		}

		public static bool CheckLoginSuccess(Chrome chrome, string currentUrl = "", string html = "")
		{
			if (currentUrl == "")
			{
				currentUrl = chrome.GetURL();
			}
			List<string> lstKerword = new List<string> { "https://m.facebook.com/home.php" };
			if (CheckStringContainKeyword(currentUrl, lstKerword))
			{
				return true;
			}
			if (html == "")
			{
				html = chrome.GetPageSource();
			}
			List<string> lstKerword2 = new List<string> { "/friends/", "/logout.php?button_location=settings&amp;button_name=logout" };
			if (CheckStringContainKeyword(html, lstKerword2))
			{
				return true;
			}
			List<string> list = new List<string> { "a[href*=\"/friends/\"]", "[action=\"/logout.php?button_location=settings&button_name=logout\"]" };
			if (chrome.CheckExistElements(0.0, list.ToArray()) > 0)
			{
				return true;
			}
			return false;
		}

		private static bool CheckStringContainKeyword(string content, List<string> lstKerword)
		{
			int num = 0;
			while (true)
			{
				if (num < lstKerword.Count)
				{
					if (Regex.IsMatch(content, lstKerword[num]) || content.Contains(lstKerword[num]))
					{
						break;
					}
					num++;
					continue;
				}
				return false;
			}
			return true;
		}

		public static List<string> BackupImageOne(Chrome chrome, string uidFr, string nameFr, string token, int countImage = 20)
		{
			List<string> list = new List<string>();
			try
			{
				if (!chrome.GetURL().Contains("https://graph.facebook.com/"))
				{
					chrome.GotoURL("https://graph.facebook.com/");
				}
				string text = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://graph.facebook.com/" + uidFr + "/photos?fields=images&limit=" + countImage + "&access_token=" + token + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
				JObject jObject = JObject.Parse(text);
				int num = 0;
				if (jObject != null && text.Contains("images"))
				{
					for (int i = 0; i < jObject["data"].Count(); i++)
					{
						num = jObject["data"]![i]!["images"].ToList().Count - 1;
						list.Add(uidFr + "*" + nameFr + "*" + jObject["data"]![i]!["images"]![num]!["source"]?.ToString() + "|" + jObject["data"]![i]!["images"]![num]!["width"]?.ToString() + "|" + jObject["data"]![i]!["images"]![num]!["height"]);
					}
				}
			}
			catch
			{
			}
			return list;
		}

		public static List<string> GetMyListUidFriend(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				string tokenEAAAAZ = GetTokenEAAAAZ(chrome);
				if (!chrome.GetURL().Contains("https://graph.facebook.com/"))
				{
					chrome.GotoURL("https://graph.facebook.com/");
				}
				string json = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://graph.facebook.com/me/friends?limit=5000&fields=id&access_token=" + tokenEAAAAZ + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
				JObject jObject = JObject.Parse(json);
				if (jObject["data"].Count() > 0)
				{
					for (int i = 0; i < jObject["data"].Count(); i++)
					{
						string item = jObject["data"]![i]!["id"]!.ToString();
						list.Add(item);
					}
				}
			}
			catch
			{
			}
			return list;
		}

		public static List<string> GetMyListNameFriend(Chrome chrome, bool isOnlyGetVNName = false)
		{
			List<string> list = new List<string>();
			try
			{
				string tokenEAAAAZ = GetTokenEAAAAZ(chrome);
				if (!chrome.GetURL().Contains("https://graph.facebook.com/"))
				{
					chrome.GotoURL("https://graph.facebook.com/");
				}
				string json = (string)chrome.ExecuteScript("async function GetListUidNameFriend() { var output = ''; try { var response = await fetch('https://graph.facebook.com/me/friends?limit=5000&fields=name&access_token=" + tokenEAAAAZ + "'); if (response.ok) { var body = await response.text(); return body; } } catch {} return output; }; var c = await GetListUidNameFriend(); return c;");
				JObject jObject = JObject.Parse(json);
				for (int i = 0; i < jObject["data"].Count(); i++)
				{
					try
					{
						string text = jObject["data"]![i]!["name"]!.ToString();
						if (isOnlyGetVNName)
						{
							if (Common.IsVNName(text))
							{
								list.Add(text);
							}
						}
						else
						{
							list.Add(text);
						}
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			return list;
		}

		public static bool SkipNotifyWhenAddFriend(Chrome chrome)
		{
			bool result = true;
			string text = "";
			switch (chrome.CheckExistElements(2.0, "[data-sigil=\" m-overlay-layer\"] button", "[data-sigil=\" m-overlay-layer\"] [value=\"OK\"]", "[data-sigil=\"touchable m-error-overlay-done\"]", "[data-sigil=\"touchable m-overlay-layer\"]", "[data-sigil=\"touchable m-error-overlay-cancel\"]"))
			{
			case 0:
				result = false;
				break;
			case 1:
				text = "[data-sigil=\" m-overlay-layer\"] button";
				break;
			case 2:
				text = "[data-sigil=\" m-overlay-layer\"] [value=\"OK\"]";
				break;
			case 3:
				text = "[data-sigil=\"touchable m-error-overlay-done\"]";
				break;
			case 4:
				text = "[data-sigil=\"touchable m-overlay-layer\"]";
				break;
			case 5:
				text = "[data-sigil=\"touchable m-error-overlay-cancel\"]";
				break;
			}
			if (text != "")
			{
				chrome.ExecuteScript("document.querySelector('" + text + "').click();");
			}
			return result;
		}

		public static string GetFbDtag(Chrome chrome)
		{
			try
			{
				string uRL = chrome.GetURL();
				if (CheckTypeWebFacebookFromUrl(uRL) != 2)
				{
					chrome.GotoURL("https://m.facebook.com");
				}
				uRL = Regex.Match(chrome.GetURL(), "https://(.*?)facebook.com").Value;
				string input = RequestGet(chrome, uRL + "/help/", uRL);
				return Regex.Match(input, Common.Base64Decode("ImR0c2dfYWciOnsidG9rZW4iOiIoLio/KSI=")).Groups[1].Value;
			}
			catch
			{
				return "";
			}
		}

		public static string GetHostFacebook(Chrome chrome, int typeWeb = 2)
		{
			try
			{
				string uRL = chrome.GetURL();
				if (CheckTypeWebFacebookFromUrl(uRL) != typeWeb)
				{
					switch (typeWeb)
					{
					case 1:
						chrome.GotoURL("https://www.facebook.com");
						break;
					case 2:
						chrome.GotoURL("https://m.facebook.com");
						break;
					case 3:
						chrome.GotoURL("https://mbasic.facebook.com");
						break;
					}
				}
				return Regex.Match(chrome.GetURL(), "https://(.*?)facebook.com").Value;
			}
			catch
			{
			}
			return "";
		}

		public static List<string> GetListGroup(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				string fbDtag = GetFbDtag(chrome);
				string value = Regex.Match(chrome.GetCookieFromChrome(), "c_user=(.*?);").Groups[1].Value;
				string uRL = chrome.GetURL();
				if (CheckTypeWebFacebookFromUrl(uRL) != 1)
				{
					chrome.GotoURL("https://www.facebook.com");
				}
				uRL = Regex.Match(chrome.GetURL(), "https://(.*?)facebook.com").Value;
				string url = uRL + "/ajax/typeahead/first_degree.php?fb_dtsg_ag=" + fbDtag + "&filter%5B0%5D=group&viewer=" + value + "&__user=" + value + "&__a=1&__dyn=&__comet_req=0&jazoest=26581";
				string json = RequestGet(chrome, url, uRL).Replace("for (;;);", "");
				JObject jObject = JObject.Parse(json);
				foreach (JToken item in (IEnumerable<JToken>)(jObject["payload"]!["entries"]!))
				{
					try
					{
						list.Add(string.Format("{0}|{1}|{2}", item["uid"], item["text"], item["size"]));
					}
					catch
					{
					}
				}
			}
			catch (Exception)
			{
			}
			return list;
		}

		public static List<string> GetListPage(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				string text = "";
				string tokenEAAAAZ = GetTokenEAAAAZ(chrome);
				text = RequestGet(chrome, "https://graph.facebook.com/v3.0/me/accounts?access_token=" + tokenEAAAAZ + "&limit=5000&fields=id,name,like,country_page_likes", "https://graph.facebook.com").ToString();
				JObject jObject = JObject.Parse(text);
				foreach (JToken item in (IEnumerable<JToken>)(jObject["data"]!))
				{
					list.Add(item["id"]!.ToString());
				}
			}
			catch
			{
			}
			return list;
		}

		public static List<string> GetListPage2(Chrome chrome)
		{
			List<string> list = new List<string>();
			try
			{
				string text = "";
				string tokenEAAAAZ = GetTokenEAAAAZ(chrome);
				text = RequestGet(chrome, "https://graph.facebook.com/v3.0/me/accounts?access_token=" + tokenEAAAAZ + "&limit=5000&fields=id,name,like,country_page_likes", "https://graph.facebook.com").ToString();
				JObject jObject = JObject.Parse(text);
				foreach (JToken item in (IEnumerable<JToken>)(jObject["data"]!))
				{
					list.Add(item["name"]!.ToString());
				}
			}
			catch
			{
			}
			return list;
		}

		public static string GetWebsiteFacebook(Chrome chrome, int typeWeb)
		{
			string url = "";
			switch (typeWeb)
			{
			case 1:
				url = "https://www.facebook.com";
				break;
			case 2:
				url = "https://m.facebook.com";
				break;
			case 3:
				url = "https://mbasic.facebook.com";
				break;
			}
			string uRL = chrome.GetURL();
			if (CheckTypeWebFacebookFromUrl(uRL) != typeWeb)
			{
				chrome.GotoURL(url);
			}
			return Regex.Match(chrome.GetURL(), "https://(.*?)facebook.com").Value;
		}

		public static Bitmap CropImageFromChrome(Chrome chrome, string cssSelector)
		{
			chrome.ScrollSmoothIfNotExistOnScreen("document.querySelector('" + cssSelector + "')");
			chrome.DelayTime(1.0);
			string text = chrome.ExecuteScript("var img=document.querySelector('" + cssSelector + "').getBoundingClientRect(); return Math.floor(img.x)+'|'+Math.floor(img.y)+'|'+Math.ceil(img.width)+'|'+Math.ceil(img.height);").ToString();
			int num = Convert.ToInt32(text.Split('|')[0]) + 10;
			int num2 = Convert.ToInt32(text.Split('|')[1]) + 30;
			int width = Convert.ToInt32(text.Split('|')[2]);
			int height = Convert.ToInt32(text.Split('|')[3]);
			Bitmap image = chrome.ScreenCapture();
			Bitmap bitmap = new Bitmap(width, height);
			Graphics graphics = Graphics.FromImage(bitmap);
			graphics.DrawImage(image, -num, -num2);
			return bitmap;
		}
	}
}
