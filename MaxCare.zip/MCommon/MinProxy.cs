using System;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace MCommon
{
	internal class MinProxy
	{
		private Random rd = new Random();

		private object k1 = new object();

		private object k = new object();

		private int lastRequest = 0;

		public int dangSuDung = 0;

		public int daSuDung = 0;

		public int limit_theads_use = 3;

		public string api_key { get; set; }

		public string proxy { get; set; }

		public int typeProxy { get; set; }

		public string ip { get; set; }

		public int timeout { get; set; }

		public int port { get; set; }

		public int next_change { get; set; }

		public string ip_allow { get; set; }

		public string your_ip { get; set; }

		public MinProxy(string api_key, int typeProxy, int limit_theads_use)
		{
			this.api_key = api_key;
			proxy = "";
			ip = "";
			port = 0;
			next_change = 0;
			this.typeProxy = typeProxy;
			this.limit_theads_use = limit_theads_use;
			lastRequest = 0;
			dangSuDung = 0;
			daSuDung = 0;
			ip_allow = "";
			your_ip = "";
		}

		public static bool CheckApiProxy(string apiProxy)
		{
			string text = RequestGet("http://dash.minproxy.vn/api/rotating/v1/proxy/get-status?api_key=" + apiProxy);
			if (text != "")
			{
				try
				{
					JObject jObject = JObject.Parse(text);
					if (jObject["code"]!.ToString() == "1")
					{
						return true;
					}
				}
				catch
				{
				}
			}
			return false;
		}

		public string TryToGetMyIP()
		{
			lock (k1)
			{
				if (dangSuDung == 0)
				{
					if (daSuDung > 0 && daSuDung < limit_theads_use)
					{
						if (GetTimeOut() < 30 && ChangeProxy() != 1)
						{
							return "0";
						}
					}
					else if (ChangeProxy() != 1)
					{
						return "0";
					}
				}
				else
				{
					if (daSuDung >= limit_theads_use)
					{
						return "2";
					}
					if (GetTimeOut() < 30 && ChangeProxy() != 1)
					{
						return "0";
					}
				}
				daSuDung++;
				dangSuDung++;
				return "1";
			}
		}

		public int GetTimeOut()
		{
			CheckStatusProxy();
			return timeout;
		}

		public void DecrementDangSuDung()
		{
			lock (k)
			{
				dangSuDung--;
				if (dangSuDung == 0 && daSuDung == limit_theads_use)
				{
					daSuDung = 0;
				}
			}
		}

		public int ChangeProxy()
		{
			proxy = "";
			ip = "";
			port = 0;
			string text = RequestGet("http://dash.minproxy.vn/api/rotating/v1/proxy/get-new-proxy?api_key=" + api_key);
			if (text != "")
			{
				if (text.Contains("api expired"))
				{
					return -1;
				}
				if (text.Contains("api wrong") || text.Contains("error"))
				{
					return -2;
				}
				try
				{
					JObject jObject = JObject.Parse(text);
					string value = Regex.Match(jObject["data"]!["next_request"]!.ToString(), "\\d+").Value;
					next_change = ((!(value == "")) ? int.Parse(value) : 0);
					if (jObject["code"]!.ToString() == "2")
					{
						ip_allow = jObject["data"]!["ip_allow"]!.ToString();
						your_ip = jObject["data"]!["your_ip"]!.ToString();
						if (typeProxy == 0)
						{
							proxy = jObject["data"]!["http_proxy"]!.ToString();
							string[] array = proxy.Split(':');
							ip = array[0];
							port = int.Parse(array[1]);
						}
						else
						{
							proxy = jObject["data"]!["socks5"]!.ToString();
							string[] array2 = proxy.Split(':');
							ip = array2[0];
							port = int.Parse(array2[1]);
						}
						return 1;
					}
					return 0;
				}
				catch
				{
				}
			}
			next_change = 0;
			return 0;
		}

		private bool checkLastRequest()
		{
			try
			{
				DateTime dateTime = new DateTime(2001, 1, 1);
				long ticks = DateTime.Now.Ticks - dateTime.Ticks;
				int num = (int)new TimeSpan(ticks).TotalSeconds;
				if (num - lastRequest >= 10)
				{
					lastRequest = num;
					return true;
				}
			}
			catch
			{
			}
			return false;
		}

		public bool CheckStatusProxy()
		{
			next_change = 0;
			proxy = "";
			ip = "";
			port = 0;
			timeout = 0;
			string text = RequestGet("http://dash.minproxy.vn/api/rotating/v1/proxy/get-current-proxy?api_key=" + api_key);
			if (text != "")
			{
				try
				{
					JObject jObject = JObject.Parse(text);
					if (jObject["code"]!.ToString() == "1")
					{
						next_change = Convert.ToInt32(jObject["data"]!["next_request"]!.ToString());
						timeout = Convert.ToInt32(jObject["data"]!["timeout"]!.ToString());
						ip_allow = jObject["data"]!["ip_allow"]!.ToString();
						your_ip = jObject["data"]!["your_ip"]!.ToString();
						if (typeProxy == 0)
						{
							proxy = jObject["data"]!["http_proxy"]!.ToString();
							string[] array = proxy.Split(':');
							ip = array[0];
							port = int.Parse(array[1]);
						}
						else
						{
							proxy = jObject["data"]!["socks5"]!.ToString();
							string[] array2 = proxy.Split(':');
							ip = array2[0];
							port = int.Parse(array2[1]);
						}
						return true;
					}
				}
				catch
				{
				}
			}
			return false;
		}

		public string GetProxy()
		{
			while (!CheckStatusProxy())
			{
			}
			return proxy;
		}

		private static string RequestPost(string url, string data)
		{
			string text = "";
			try
			{
				new HttpClient();
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
				HttpContent c = default(HttpContent);
				Task<string> task = Task.Run(() => PostURI(new Uri(url), c));
				task.Wait();
				return task.Result;
			}
			catch (Exception ex)
			{
				Common.ExportError(null, ex, "Request Post");
				return "";
			}
		}

		public static string RequestGet(string url)
		{
			string text = "";
			try
			{
				new HttpClient();
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
				Task<string> task = Task.Run(() => GetURI(new Uri(url)));
				task.Wait();
				return task.Result;
			}
			catch (Exception ex)
			{
				Common.ExportError(null, ex, "Request get");
				return "";
			}
		}

		private static async Task<string> PostURI(Uri u, HttpContent c)
		{
			string response = string.Empty;
			using (HttpClient client = new HttpClient())
			{
				HttpResponseMessage result = await client.PostAsync(u, c);
				if (result.IsSuccessStatusCode)
				{
					response = await result.Content.ReadAsStringAsync();
				}
			}
			return response;
		}

		private static async Task<string> GetURI(Uri u)
		{
			string response = string.Empty;
			using (HttpClient client = new HttpClient())
			{
				HttpResponseMessage result = await client.GetAsync(u);
				if (result.IsSuccessStatusCode)
				{
					response = await result.Content.ReadAsStringAsync();
				}
			}
			return response;
		}
	}
}
