namespace MCommon
{
	public enum EMouseKey
	{
		LEFT,
		RIGHT,
		DOUBLE_LEFT,
		DOUBLE_RIGHT
	}
}
