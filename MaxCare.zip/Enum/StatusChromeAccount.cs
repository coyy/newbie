namespace maxcare.Enum
{
	public enum StatusChromeAccount
	{
		Empty,
		ChromeClosed,
		LoginWithUserPass,
		LoginWithSelectAccount,
		Checkpoint,
		Logined,
		NoInternet,
		Blocked,
		Noveri
	}
}
