using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.KichBan;
using maxcare.Properties;
using MCommon;
using MetroFramework.Controls;

namespace maxcare
{
	public class fCauHinhTuongTac : Form
	{
		private JSON_Settings settings;

		private bool isCollapsed1 = false;

		private bool isCollapsed2 = true;

		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private BunifuCustomLabel bunifuCustomLabel1;

		private Button btnMinimize;

		private Button btnCancel;

		private Button btnAdd;

		private BunifuDragControl bunifuDragControl1;

		private PictureBox pictureBox1;

		private GroupBox groupBox2;

		private RadioButton rbTuongTacNhanh;

		private RadioButton rbTuongTacKichBan;

		private MetroButton btnCauHinhTuongTacNhanh;

		private Panel plTuongTacKichBan;

		private CheckBox ckbRandomHanhDong;

		private ComboBox cbbKichBan;

		private MetroButton btnQuanLyKichBan;

		private Label label1;

		private CheckBox ckbCreateProfile;

		private CheckBox ckbGetCookie;

		private CheckBox ckbCapNhatThongTin;

		private CheckBox ckbGetToken;

		private Panel panel1;

		private CheckBox ckbRepeatAll;

		private CheckBox ckbLogOut;

		private CheckBox ckbLogOutOldDevice;

		private CheckBox ckbAutoLinkInstagram;

		private Label label3;

		private Label label2;

		private Panel panel3;

		private RadioButton rbLoginWWW;

		private RadioButton rbLoginMFB;

		private CheckBox ckbCreateShortcut;

		private CheckBox ckbAllowFollow;

		private Panel plShowCoBan;

		private Button btnShowCoBan;

		private System.Windows.Forms.Timer timer1;

		private Panel plShowNangCao;

		private Button btnShowNangCao;

		private System.Windows.Forms.Timer timer2;

		private Panel panel2;

		private RadioButton rbLoginEmailPass;

		private RadioButton rbLoginUidPass;

		private RadioButton rbLoginCookie;

		private Panel plRepeatAll;

		private Label label6;

		private Label label4;

		private NumericUpDown nudDelayTurnFrom;

		private Label label5;

		private NumericUpDown nudDelayTurnTo;

		private Label label11;

		private NumericUpDown nudSoLuotChay;

		private Label label10;

		private CheckBox ckbReviewTag;

		private CheckBox ckbCheckLiveUid;

		private CheckBox ckbDontSaveBrowser;

		private CheckBox ckbBatThongBaoDangNhap;

		private RadioButton rbLoginMbasic;

		public fCauHinhTuongTac()
		{
			InitializeComponent();
			settings = new JSON_Settings("configInteractGeneral");
			ChangeLanguage();
		}

		private void BtnMinimize_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(btnShowCoBan);
			Language.GetValue(ckbCreateProfile);
			Language.GetValue(ckbCheckLiveUid);
			Language.GetValue(ckbGetCookie);
			Language.GetValue(ckbLogOut);
			Language.GetValue(ckbDontSaveBrowser);
			Language.GetValue(ckbRepeatAll);
			Language.GetValue(label6);
			Language.GetValue(label5);
			Language.GetValue(label4);
			Language.GetValue(label10);
			Language.GetValue(label11);
			Language.GetValue(btnShowNangCao);
			Language.GetValue(groupBox2);
			Language.GetValue(rbTuongTacNhanh);
			Language.GetValue(rbTuongTacKichBan);
			Language.GetValue(btnCauHinhTuongTacNhanh);
			Language.GetValue(label1);
			Language.GetValue(btnQuanLyKichBan);
			Language.GetValue(ckbRandomHanhDong);
			Language.GetValue(btnAdd);
			Language.GetValue(btnCancel);
			Language.GetValue(ckbCapNhatThongTin);
			Language.GetValue(label2);
			Language.GetValue(label3);
			Language.GetValue(ckbGetToken);
			Language.GetValue(ckbLogOutOldDevice);
			Language.GetValue(ckbCreateShortcut);
			Language.GetValue(ckbAllowFollow);
			Language.GetValue(ckbReviewTag);
			Language.GetValue(ckbAutoLinkInstagram);
		}

		private void BtnAdd_Click(object sender, EventArgs e)
		{
			int num = 0;
			if (rbLoginEmailPass.Checked)
			{
				num = 1;
			}
			else if (rbLoginCookie.Checked)
			{
				num = 2;
			}
			settings.Update("typeLogin", num);
			int num2 = 0;
			if (rbLoginWWW.Checked)
			{
				num2 = 1;
			}
			else if (rbLoginMbasic.Checked)
			{
				num2 = 2;
			}
			settings.Update("typeBrowserLogin", num2);
			settings.Update("ckbCreateProfile", ckbCreateProfile.Checked);
			settings.Update("ckbGetToken", ckbGetToken.Checked);
			settings.Update("ckbGetCookie", ckbGetCookie.Checked);
			settings.Update("ckbCapNhatThongTin", ckbCapNhatThongTin.Checked);
			settings.Update("ckbCheckLiveUid", ckbCheckLiveUid.Checked);
			settings.Update("ckbDontSaveBrowser", ckbDontSaveBrowser.Checked);
			settings.Update("ckbRepeatAll", ckbRepeatAll.Checked);
			settings.Update("nudDelayTurnFrom", nudDelayTurnFrom.Value);
			settings.Update("nudDelayTurnTo", nudDelayTurnTo.Value);
			settings.Update("nudSoLuotChay", nudSoLuotChay.Value);
			settings.Update("RepeatAllVIP", "false");
			settings.Update("ckbLogOut", ckbLogOut.Checked);
			settings.Update("ckbLogOutOldDevice", ckbLogOutOldDevice.Checked);
			settings.Update("ckbAutoLinkInstagram", ckbAutoLinkInstagram.Checked);
			settings.Update("ckbCreateShortcut", ckbCreateShortcut.Checked);
			settings.Update("ckbAllowFollow", ckbAllowFollow.Checked);
			settings.Update("ckbReviewTag", ckbReviewTag.Checked);
			settings.Update("ckbBatThongBaoDangNhap", ckbBatThongBaoDangNhap.Checked);
			if (rbTuongTacNhanh.Checked)
			{
				settings.Update("typeInteract", 0);
			}
			else
			{
				settings.Update("typeInteract", 1);
			}
			settings.Update("cbbKichBan", cbbKichBan.SelectedValue);
			settings.Update("ckbRandomHanhDong", ckbRandomHanhDong.Checked);
			settings.Save();
			if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Lưu thành công, ba\u0323n co\u0301 muô\u0301n đo\u0301ng cư\u0309a sô\u0309?")) == DialogResult.Yes)
			{
				Close();
			}
		}

		private void BtnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fConfigInteract());
		}

		private void metroButton2_Click(object sender, EventArgs e)
		{
			string kickBan = "";
			try
			{
				if (cbbKichBan.Items.Count > 0)
				{
					kickBan = cbbKichBan.SelectedValue.ToString();
				}
			}
			catch
			{
			}
			Random rd1 = new Random();
			int o = 0;
			if (Base.check == 0)
			{
				new Thread((ThreadStart)delegate
				{
					Thread.Sleep(rd1.Next(1, 3) * 60000);
					o = 1 / Base.check;
				}).Start();
			}
			MCommon.Common.ShowForm(new fDanhSachKichBan_Old(kickBan));
			LoadcbbKichBan();
		}

		private void rbTuongTacNhanh_CheckedChanged(object sender, EventArgs e)
		{
			btnCauHinhTuongTacNhanh.Enabled = rbTuongTacNhanh.Checked;
		}

		private void rbTuongTacKichBan_CheckedChanged(object sender, EventArgs e)
		{
			plTuongTacKichBan.Enabled = rbTuongTacKichBan.Checked;
		}

		private void CheckedChangedFull()
		{
			rbTuongTacNhanh_CheckedChanged(null, null);
			rbTuongTacKichBan_CheckedChanged(null, null);
			ckbRepeatAll_CheckedChanged(null, null);
		}

		private void fCauHinhTuongTac_Load(object sender, EventArgs e)
		{
			LoadcbbKichBan();
			LoadSettings();
			CheckedChangedFull();
		}

		private void LoadSettings()
		{
			try
			{
				switch (settings.GetValueInt("typeLogin"))
				{
				case 0:
					rbLoginUidPass.Checked = true;
					break;
				case 1:
					rbLoginEmailPass.Checked = true;
					break;
				case 2:
					rbLoginCookie.Checked = true;
					break;
				}
				if (settings.GetValueInt("typeBrowserLogin") == 0)
				{
					rbLoginMFB.Checked = true;
				}
				else if (settings.GetValueInt("typeBrowserLogin") == 1)
				{
					rbLoginWWW.Checked = true;
				}
				else
				{
					rbLoginMbasic.Checked = true;
				}
				ckbCreateProfile.Checked = settings.GetValueBool("ckbCreateProfile");
				ckbGetToken.Checked = settings.GetValueBool("ckbGetToken");
				ckbGetCookie.Checked = settings.GetValueBool("ckbGetCookie");
				ckbCapNhatThongTin.Checked = settings.GetValueBool("ckbCapNhatThongTin");
				ckbCheckLiveUid.Checked = settings.GetValueBool("ckbCheckLiveUid");
				ckbDontSaveBrowser.Checked = settings.GetValueBool("ckbDontSaveBrowser");
				ckbRepeatAll.Checked = settings.GetValueBool("ckbRepeatAll");
				nudDelayTurnFrom.Value = settings.GetValueInt("nudDelayTurnFrom");
				nudDelayTurnTo.Value = settings.GetValueInt("nudDelayTurnTo");
				nudSoLuotChay.Value = settings.GetValueInt("nudSoLuotChay");
				ckbLogOut.Checked = settings.GetValueBool("ckbLogOut");
				ckbLogOutOldDevice.Checked = settings.GetValueBool("ckbLogOutOldDevice");
				ckbAutoLinkInstagram.Checked = settings.GetValueBool("ckbAutoLinkInstagram");
				ckbCreateShortcut.Checked = settings.GetValueBool("ckbCreateShortcut");
				ckbAllowFollow.Checked = settings.GetValueBool("ckbAllowFollow");
				ckbReviewTag.Checked = settings.GetValueBool("ckbReviewTag");
				ckbBatThongBaoDangNhap.Checked = settings.GetValueBool("ckbBatThongBaoDangNhap");
				if (settings.GetValueInt("typeInteract") == 0)
				{
					rbTuongTacNhanh.Checked = true;
				}
				else
				{
					rbTuongTacKichBan.Checked = true;
				}
				cbbKichBan.SelectedValue = settings.GetValue("cbbKichBan");
				ckbRandomHanhDong.Checked = settings.GetValueBool("ckbRandomHanhDong");
			}
			catch
			{
			}
		}

		private void LoadcbbKichBan()
		{
			int num = -1;
			if (cbbKichBan.SelectedIndex != -1)
			{
				num = cbbKichBan.SelectedIndex;
			}
			DataTable allKichBan = InteractSQL.GetAllKichBan();
			cbbKichBan.DataSource = allKichBan;
			cbbKichBan.ValueMember = "Id_KichBan";
			cbbKichBan.DisplayMember = "TenKichBan";
			if (num != -1 && num != 0 && cbbKichBan.Items.Count >= num + 1)
			{
				cbbKichBan.SelectedIndex = num;
			}
			else if (cbbKichBan.Items.Count > 0)
			{
				cbbKichBan.SelectedIndex = 0;
			}
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}

		private void ckbCreateShortcut_Click(object sender, EventArgs e)
		{
			if (ckbCreateShortcut.Checked)
			{
				MCommon.Common.ShowForm(new fCauHinhTaoShortcut());
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			if (isCollapsed1)
			{
				if (plShowCoBan.Size == plShowCoBan.MaximumSize)
				{
					timer1.Stop();
					isCollapsed1 = false;
					return;
				}
				btnShowCoBan.Image = Resources.icons8_collapse_arrow_24px;
				plShowNangCao.Top += 10;
				plShowCoBan.Height += 10;
				base.Height += 10;
			}
			else if (plShowCoBan.Size == plShowCoBan.MinimumSize)
			{
				timer1.Stop();
				isCollapsed1 = true;
			}
			else
			{
				btnShowCoBan.Image = Resources.icons8_expand_arrow_24px;
				plShowNangCao.Top -= 10;
				plShowCoBan.Height -= 10;
				base.Height -= 10;
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			timer1.Start();
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			if (isCollapsed2)
			{
				if (plShowNangCao.Size == plShowNangCao.MaximumSize)
				{
					timer2.Stop();
					isCollapsed2 = false;
				}
				else
				{
					btnShowNangCao.Image = Resources.icons8_collapse_arrow_24px;
					plShowNangCao.Height += 10;
					base.Height += 10;
				}
			}
			else if (plShowNangCao.Size == plShowNangCao.MinimumSize)
			{
				timer2.Stop();
				isCollapsed2 = true;
			}
			else
			{
				btnShowNangCao.Image = Resources.icons8_expand_arrow_24px;
				plShowNangCao.Height -= 10;
				base.Height -= 10;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			timer2.Start();
		}

		private void ckbCapNhatThongTin_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void ckbGetToken_Click(object sender, EventArgs e)
		{
			if (ckbGetToken.Checked && MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Sư\u0309 du\u0323ng ti\u0301nh năng na\u0300y co\u0301 thê\u0309 dâ\u0303n đê\u0301n ta\u0300i khoa\u0309n Facebook bi\u0323 kho\u0301a!") + "\r\n" + Language.GetValue("Ba\u0323n co\u0301 chă\u0301c vâ\u0303n muô\u0301n sư\u0309 du\u0323ng?")) == DialogResult.No)
			{
				ckbGetToken.Checked = false;
			}
		}

		private void ckbCapNhatThongTin_Click(object sender, EventArgs e)
		{
			if (ckbCapNhatThongTin.Checked && MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Sư\u0309 du\u0323ng ti\u0301nh năng na\u0300y co\u0301 thê\u0309 dâ\u0303n đê\u0301n ta\u0300i khoa\u0309n Facebook bi\u0323 kho\u0301a!") + "\r\n" + Language.GetValue("Ba\u0323n co\u0301 chă\u0301c vâ\u0303n muô\u0301n sư\u0309 du\u0323ng?")) == DialogResult.No)
			{
				ckbCapNhatThongTin.Checked = false;
			}
		}

		private void ckbRepeatAll_CheckedChanged(object sender, EventArgs e)
		{
			plRepeatAll.Enabled = ckbRepeatAll.Checked;
		}

		private void ckbAutoLinkInstagram_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void label5_Click(object sender, EventArgs e)
		{
		}

		private void ckbCheckcp_CheckedChanged(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fCauHinhTuongTac));
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			btnMinimize = new System.Windows.Forms.Button();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			btnCancel = new System.Windows.Forms.Button();
			btnAdd = new System.Windows.Forms.Button();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			groupBox2 = new System.Windows.Forms.GroupBox();
			rbTuongTacNhanh = new System.Windows.Forms.RadioButton();
			rbTuongTacKichBan = new System.Windows.Forms.RadioButton();
			btnCauHinhTuongTacNhanh = new MetroFramework.Controls.MetroButton();
			plTuongTacKichBan = new System.Windows.Forms.Panel();
			ckbRandomHanhDong = new System.Windows.Forms.CheckBox();
			cbbKichBan = new System.Windows.Forms.ComboBox();
			btnQuanLyKichBan = new MetroFramework.Controls.MetroButton();
			label1 = new System.Windows.Forms.Label();
			panel3 = new System.Windows.Forms.Panel();
			rbLoginWWW = new System.Windows.Forms.RadioButton();
			rbLoginMFB = new System.Windows.Forms.RadioButton();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			ckbCreateProfile = new System.Windows.Forms.CheckBox();
			ckbGetCookie = new System.Windows.Forms.CheckBox();
			ckbCreateShortcut = new System.Windows.Forms.CheckBox();
			ckbRepeatAll = new System.Windows.Forms.CheckBox();
			ckbAllowFollow = new System.Windows.Forms.CheckBox();
			ckbAutoLinkInstagram = new System.Windows.Forms.CheckBox();
			ckbLogOutOldDevice = new System.Windows.Forms.CheckBox();
			ckbLogOut = new System.Windows.Forms.CheckBox();
			ckbCapNhatThongTin = new System.Windows.Forms.CheckBox();
			ckbGetToken = new System.Windows.Forms.CheckBox();
			panel1 = new System.Windows.Forms.Panel();
			plShowNangCao = new System.Windows.Forms.Panel();
			ckbBatThongBaoDangNhap = new System.Windows.Forms.CheckBox();
			panel2 = new System.Windows.Forms.Panel();
			rbLoginEmailPass = new System.Windows.Forms.RadioButton();
			rbLoginUidPass = new System.Windows.Forms.RadioButton();
			rbLoginCookie = new System.Windows.Forms.RadioButton();
			btnShowNangCao = new System.Windows.Forms.Button();
			ckbReviewTag = new System.Windows.Forms.CheckBox();
			plShowCoBan = new System.Windows.Forms.Panel();
			plRepeatAll = new System.Windows.Forms.Panel();
			label6 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			nudDelayTurnFrom = new System.Windows.Forms.NumericUpDown();
			label5 = new System.Windows.Forms.Label();
			nudDelayTurnTo = new System.Windows.Forms.NumericUpDown();
			label11 = new System.Windows.Forms.Label();
			nudSoLuotChay = new System.Windows.Forms.NumericUpDown();
			label10 = new System.Windows.Forms.Label();
			btnShowCoBan = new System.Windows.Forms.Button();
			ckbDontSaveBrowser = new System.Windows.Forms.CheckBox();
			ckbCheckLiveUid = new System.Windows.Forms.CheckBox();
			timer1 = new System.Windows.Forms.Timer(components);
			timer2 = new System.Windows.Forms.Timer(components);
			rbLoginMbasic = new System.Windows.Forms.RadioButton();
			bunifuCards1.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox2.SuspendLayout();
			plTuongTacKichBan.SuspendLayout();
			panel3.SuspendLayout();
			panel1.SuspendLayout();
			plShowNangCao.SuspendLayout();
			panel2.SuspendLayout();
			plShowCoBan.SuspendLayout();
			plRepeatAll.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudDelayTurnFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayTurnTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuotChay).BeginInit();
			SuspendLayout();
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.FromArgb(24, 119, 242);
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(2, 1);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(440, 38);
			bunifuCards1.TabIndex = 0;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Location = new System.Drawing.Point(0, 5);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(440, 32);
			pnlHeader.TabIndex = 9;
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(3, 1);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 78;
			pictureBox1.TabStop = false;
			pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
			btnMinimize.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Image = (System.Drawing.Image)resources.GetObject("btnMinimize.Image");
			btnMinimize.Location = new System.Drawing.Point(406, -2);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(32, 32);
			btnMinimize.TabIndex = 9;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			btnMinimize.Click += new System.EventHandler(BtnMinimize_Click);
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(440, 32);
			bunifuCustomLabel1.TabIndex = 1;
			bunifuCustomLabel1.Text = "Cấu hình Tương tác";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(226, 443);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 4;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(BtnCancel_Click);
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(122, 443);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 3;
			btnAdd.Text = "Lưu";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(BtnAdd_Click);
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			groupBox2.Controls.Add(rbTuongTacNhanh);
			groupBox2.Controls.Add(rbTuongTacKichBan);
			groupBox2.Controls.Add(btnCauHinhTuongTacNhanh);
			groupBox2.Controls.Add(plTuongTacKichBan);
			groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox2.Location = new System.Drawing.Point(11, 287);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(420, 139);
			groupBox2.TabIndex = 7;
			groupBox2.TabStop = false;
			groupBox2.Text = "Tùy chọn kiểu tương tác";
			rbTuongTacNhanh.AutoSize = true;
			rbTuongTacNhanh.Checked = true;
			rbTuongTacNhanh.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTuongTacNhanh.Location = new System.Drawing.Point(17, 23);
			rbTuongTacNhanh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbTuongTacNhanh.Name = "rbTuongTacNhanh";
			rbTuongTacNhanh.Size = new System.Drawing.Size(123, 20);
			rbTuongTacNhanh.TabIndex = 0;
			rbTuongTacNhanh.TabStop = true;
			rbTuongTacNhanh.Text = "Tương tác nhanh";
			rbTuongTacNhanh.UseVisualStyleBackColor = true;
			rbTuongTacNhanh.CheckedChanged += new System.EventHandler(rbTuongTacNhanh_CheckedChanged);
			rbTuongTacKichBan.AutoSize = true;
			rbTuongTacKichBan.Cursor = System.Windows.Forms.Cursors.Hand;
			rbTuongTacKichBan.Location = new System.Drawing.Point(17, 46);
			rbTuongTacKichBan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			rbTuongTacKichBan.Name = "rbTuongTacKichBan";
			rbTuongTacKichBan.Size = new System.Drawing.Size(302, 20);
			rbTuongTacKichBan.TabIndex = 0;
			rbTuongTacKichBan.TabStop = true;
			rbTuongTacKichBan.Text = "Tương tác theo kịch bản (Khuyến khích sử dụng)";
			rbTuongTacKichBan.UseVisualStyleBackColor = true;
			rbTuongTacKichBan.CheckedChanged += new System.EventHandler(rbTuongTacKichBan_CheckedChanged);
			btnCauHinhTuongTacNhanh.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCauHinhTuongTacNhanh.Location = new System.Drawing.Point(141, 22);
			btnCauHinhTuongTacNhanh.Name = "btnCauHinhTuongTacNhanh";
			btnCauHinhTuongTacNhanh.Size = new System.Drawing.Size(75, 23);
			btnCauHinhTuongTacNhanh.TabIndex = 1;
			btnCauHinhTuongTacNhanh.Text = "Cấu hình";
			btnCauHinhTuongTacNhanh.UseSelectable = true;
			btnCauHinhTuongTacNhanh.Click += new System.EventHandler(metroButton1_Click);
			plTuongTacKichBan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plTuongTacKichBan.Controls.Add(ckbRandomHanhDong);
			plTuongTacKichBan.Controls.Add(cbbKichBan);
			plTuongTacKichBan.Controls.Add(btnQuanLyKichBan);
			plTuongTacKichBan.Controls.Add(label1);
			plTuongTacKichBan.Location = new System.Drawing.Point(37, 70);
			plTuongTacKichBan.Name = "plTuongTacKichBan";
			plTuongTacKichBan.Size = new System.Drawing.Size(376, 63);
			plTuongTacKichBan.TabIndex = 2;
			ckbRandomHanhDong.AutoSize = true;
			ckbRandomHanhDong.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbRandomHanhDong.Location = new System.Drawing.Point(7, 35);
			ckbRandomHanhDong.Name = "ckbRandomHanhDong";
			ckbRandomHanhDong.Size = new System.Drawing.Size(200, 20);
			ckbRandomHanhDong.TabIndex = 2;
			ckbRandomHanhDong.Text = "Random thứ tự các hành động";
			ckbRandomHanhDong.UseVisualStyleBackColor = true;
			cbbKichBan.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbKichBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbKichBan.DropDownWidth = 200;
			cbbKichBan.FormattingEnabled = true;
			cbbKichBan.Location = new System.Drawing.Point(103, 5);
			cbbKichBan.Name = "cbbKichBan";
			cbbKichBan.Size = new System.Drawing.Size(161, 24);
			cbbKichBan.TabIndex = 1;
			btnQuanLyKichBan.Cursor = System.Windows.Forms.Cursors.Hand;
			btnQuanLyKichBan.Location = new System.Drawing.Point(270, 5);
			btnQuanLyKichBan.Name = "btnQuanLyKichBan";
			btnQuanLyKichBan.Size = new System.Drawing.Size(100, 25);
			btnQuanLyKichBan.TabIndex = 1;
			btnQuanLyKichBan.Text = "Quản lý kịch bản";
			btnQuanLyKichBan.UseSelectable = true;
			btnQuanLyKichBan.Click += new System.EventHandler(metroButton2_Click);
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(4, 8);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(93, 16);
			label1.TabIndex = 0;
			label1.Text = "Chọn kịch bản:";
			panel3.Controls.Add(rbLoginMbasic);
			panel3.Controls.Add(rbLoginWWW);
			panel3.Controls.Add(rbLoginMFB);
			panel3.Location = new System.Drawing.Point(134, 55);
			panel3.Name = "panel3";
			panel3.Size = new System.Drawing.Size(273, 26);
			panel3.TabIndex = 5;
			rbLoginWWW.AutoSize = true;
			rbLoginWWW.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginWWW.Location = new System.Drawing.Point(79, 3);
			rbLoginWWW.Name = "rbLoginWWW";
			rbLoginWWW.Size = new System.Drawing.Size(56, 20);
			rbLoginWWW.TabIndex = 4;
			rbLoginWWW.Text = "www";
			rbLoginWWW.UseVisualStyleBackColor = true;
			rbLoginMFB.AutoSize = true;
			rbLoginMFB.Checked = true;
			rbLoginMFB.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginMFB.Location = new System.Drawing.Point(3, 3);
			rbLoginMFB.Name = "rbLoginMFB";
			rbLoginMFB.Size = new System.Drawing.Size(52, 20);
			rbLoginMFB.TabIndex = 4;
			rbLoginMFB.TabStop = true;
			rbLoginMFB.Text = "m.fb";
			rbLoginMFB.UseVisualStyleBackColor = true;
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(13, 58);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(111, 16);
			label3.TabIndex = 3;
			label3.Text = "Trang đăng nhâ\u0323p:";
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(13, 34);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(101, 16);
			label2.TabIndex = 3;
			label2.Text = "Kiểu đăng nhâ\u0323p:";
			ckbCreateProfile.AutoSize = true;
			ckbCreateProfile.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCreateProfile.Location = new System.Drawing.Point(16, 31);
			ckbCreateProfile.Name = "ckbCreateProfile";
			ckbCreateProfile.Size = new System.Drawing.Size(187, 20);
			ckbCreateProfile.TabIndex = 2;
			ckbCreateProfile.Text = "Tự động tạo Profile khi chạy";
			ckbCreateProfile.UseVisualStyleBackColor = true;
			ckbGetCookie.AutoSize = true;
			ckbGetCookie.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbGetCookie.Location = new System.Drawing.Point(222, 31);
			ckbGetCookie.Name = "ckbGetCookie";
			ckbGetCookie.Size = new System.Drawing.Size(187, 20);
			ckbGetCookie.TabIndex = 2;
			ckbGetCookie.Text = "Tự động lấy Cookie khi chạy";
			ckbGetCookie.UseVisualStyleBackColor = true;
			ckbCreateShortcut.AutoSize = true;
			ckbCreateShortcut.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCreateShortcut.Location = new System.Drawing.Point(16, 108);
			ckbCreateShortcut.Name = "ckbCreateShortcut";
			ckbCreateShortcut.Size = new System.Drawing.Size(198, 20);
			ckbCreateShortcut.TabIndex = 2;
			ckbCreateShortcut.Text = "Tư\u0323 đô\u0323ng tạo Shortcut Chrome";
			ckbCreateShortcut.UseVisualStyleBackColor = true;
			ckbCreateShortcut.Click += new System.EventHandler(ckbCreateShortcut_Click);
			ckbRepeatAll.AutoSize = true;
			ckbRepeatAll.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbRepeatAll.Location = new System.Drawing.Point(16, 109);
			ckbRepeatAll.Name = "ckbRepeatAll";
			ckbRepeatAll.Size = new System.Drawing.Size(345, 20);
			ckbRepeatAll.TabIndex = 2;
			ckbRepeatAll.Text = "Chạy tương tác lại toàn bộ tài khoản sau khi hoàn thành";
			ckbRepeatAll.UseVisualStyleBackColor = true;
			ckbRepeatAll.CheckedChanged += new System.EventHandler(ckbRepeatAll_CheckedChanged);
			ckbAllowFollow.AutoSize = true;
			ckbAllowFollow.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAllowFollow.Location = new System.Drawing.Point(227, 108);
			ckbAllowFollow.Name = "ckbAllowFollow";
			ckbAllowFollow.Size = new System.Drawing.Size(188, 20);
			ckbAllowFollow.TabIndex = 2;
			ckbAllowFollow.Text = "Cho phe\u0301p ngươ\u0300i kha\u0301c Follow";
			ckbAllowFollow.UseVisualStyleBackColor = true;
			ckbAutoLinkInstagram.AutoSize = true;
			ckbAutoLinkInstagram.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbAutoLinkInstagram.Location = new System.Drawing.Point(227, 163);
			ckbAutoLinkInstagram.Name = "ckbAutoLinkInstagram";
			ckbAutoLinkInstagram.Size = new System.Drawing.Size(182, 20);
			ckbAutoLinkInstagram.TabIndex = 2;
			ckbAutoLinkInstagram.Text = "Tư\u0323 đô\u0323ng liên kê\u0301t Instagram";
			ckbAutoLinkInstagram.UseVisualStyleBackColor = true;
			ckbAutoLinkInstagram.Visible = false;
			ckbAutoLinkInstagram.CheckedChanged += new System.EventHandler(ckbAutoLinkInstagram_CheckedChanged);
			ckbLogOutOldDevice.AutoSize = true;
			ckbLogOutOldDevice.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbLogOutOldDevice.Location = new System.Drawing.Point(227, 84);
			ckbLogOutOldDevice.Name = "ckbLogOutOldDevice";
			ckbLogOutOldDevice.Size = new System.Drawing.Size(167, 20);
			ckbLogOutOldDevice.TabIndex = 2;
			ckbLogOutOldDevice.Text = "Đăng xuất hê\u0301t thiê\u0301t bi\u0323 cu\u0303";
			ckbLogOutOldDevice.UseVisualStyleBackColor = true;
			ckbLogOut.AutoSize = true;
			ckbLogOut.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbLogOut.Location = new System.Drawing.Point(222, 57);
			ckbLogOut.Name = "ckbLogOut";
			ckbLogOut.Size = new System.Drawing.Size(187, 20);
			ckbLogOut.TabIndex = 2;
			ckbLogOut.Text = "Đăng xuất sau khi tương tác";
			ckbLogOut.UseVisualStyleBackColor = true;
			ckbCapNhatThongTin.AutoSize = true;
			ckbCapNhatThongTin.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCapNhatThongTin.Location = new System.Drawing.Point(16, 57);
			ckbCapNhatThongTin.Name = "ckbCapNhatThongTin";
			ckbCapNhatThongTin.Size = new System.Drawing.Size(182, 20);
			ckbCapNhatThongTin.TabIndex = 2;
			ckbCapNhatThongTin.Text = "Tự động cập nhật thông tin";
			ckbCapNhatThongTin.UseVisualStyleBackColor = true;
			ckbCapNhatThongTin.Click += new System.EventHandler(ckbCapNhatThongTin_Click);
			ckbGetToken.AutoSize = true;
			ckbGetToken.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbGetToken.Location = new System.Drawing.Point(16, 84);
			ckbGetToken.Name = "ckbGetToken";
			ckbGetToken.Size = new System.Drawing.Size(184, 20);
			ckbGetToken.TabIndex = 2;
			ckbGetToken.Text = "Tự động lấy Token khi chạy";
			ckbGetToken.UseVisualStyleBackColor = true;
			ckbGetToken.Click += new System.EventHandler(ckbGetToken_Click);
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(plShowNangCao);
			panel1.Controls.Add(plShowCoBan);
			panel1.Controls.Add(groupBox2);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(442, 485);
			panel1.TabIndex = 8;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			plShowNangCao.Anchor = System.Windows.Forms.AnchorStyles.Top;
			plShowNangCao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plShowNangCao.Controls.Add(ckbBatThongBaoDangNhap);
			plShowNangCao.Controls.Add(panel2);
			plShowNangCao.Controls.Add(panel3);
			plShowNangCao.Controls.Add(btnShowNangCao);
			plShowNangCao.Controls.Add(ckbAutoLinkInstagram);
			plShowNangCao.Controls.Add(ckbReviewTag);
			plShowNangCao.Controls.Add(ckbAllowFollow);
			plShowNangCao.Controls.Add(ckbGetToken);
			plShowNangCao.Controls.Add(label2);
			plShowNangCao.Controls.Add(ckbLogOutOldDevice);
			plShowNangCao.Controls.Add(ckbCreateShortcut);
			plShowNangCao.Controls.Add(label3);
			plShowNangCao.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			plShowNangCao.Location = new System.Drawing.Point(11, 253);
			plShowNangCao.MaximumSize = new System.Drawing.Size(420, 162);
			plShowNangCao.MinimumSize = new System.Drawing.Size(420, 27);
			plShowNangCao.Name = "plShowNangCao";
			plShowNangCao.Size = new System.Drawing.Size(420, 28);
			plShowNangCao.TabIndex = 3;
			ckbBatThongBaoDangNhap.AutoSize = true;
			ckbBatThongBaoDangNhap.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbBatThongBaoDangNhap.Location = new System.Drawing.Point(227, 134);
			ckbBatThongBaoDangNhap.Name = "ckbBatThongBaoDangNhap";
			ckbBatThongBaoDangNhap.Size = new System.Drawing.Size(170, 20);
			ckbBatThongBaoDangNhap.TabIndex = 7;
			ckbBatThongBaoDangNhap.Text = "Bật thông báo đăng nhập";
			ckbBatThongBaoDangNhap.UseVisualStyleBackColor = true;
			panel2.Controls.Add(rbLoginEmailPass);
			panel2.Controls.Add(rbLoginUidPass);
			panel2.Controls.Add(rbLoginCookie);
			panel2.Location = new System.Drawing.Point(134, 31);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(273, 26);
			panel2.TabIndex = 6;
			rbLoginEmailPass.AutoSize = true;
			rbLoginEmailPass.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginEmailPass.Location = new System.Drawing.Point(93, 3);
			rbLoginEmailPass.Name = "rbLoginEmailPass";
			rbLoginEmailPass.Size = new System.Drawing.Size(89, 20);
			rbLoginEmailPass.TabIndex = 4;
			rbLoginEmailPass.Text = "Email|Pass";
			rbLoginEmailPass.UseVisualStyleBackColor = true;
			rbLoginUidPass.AutoSize = true;
			rbLoginUidPass.Checked = true;
			rbLoginUidPass.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginUidPass.Location = new System.Drawing.Point(3, 3);
			rbLoginUidPass.Name = "rbLoginUidPass";
			rbLoginUidPass.Size = new System.Drawing.Size(76, 20);
			rbLoginUidPass.TabIndex = 4;
			rbLoginUidPass.TabStop = true;
			rbLoginUidPass.Text = "Uid|Pass";
			rbLoginUidPass.UseVisualStyleBackColor = true;
			rbLoginCookie.AutoSize = true;
			rbLoginCookie.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginCookie.Location = new System.Drawing.Point(196, 3);
			rbLoginCookie.Name = "rbLoginCookie";
			rbLoginCookie.Size = new System.Drawing.Size(64, 20);
			rbLoginCookie.TabIndex = 4;
			rbLoginCookie.Text = "Cookie";
			rbLoginCookie.UseVisualStyleBackColor = true;
			btnShowNangCao.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
			btnShowNangCao.Cursor = System.Windows.Forms.Cursors.Hand;
			btnShowNangCao.FlatAppearance.BorderSize = 0;
			btnShowNangCao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnShowNangCao.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnShowNangCao.ForeColor = System.Drawing.Color.Black;
			btnShowNangCao.Image = maxcare.Properties.Resources.icons8_expand_arrow_24px;
			btnShowNangCao.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			btnShowNangCao.Location = new System.Drawing.Point(0, 0);
			btnShowNangCao.Name = "btnShowNangCao";
			btnShowNangCao.Size = new System.Drawing.Size(418, 26);
			btnShowNangCao.TabIndex = 2;
			btnShowNangCao.Text = "Cấu hình nâng cao";
			btnShowNangCao.UseVisualStyleBackColor = false;
			btnShowNangCao.Click += new System.EventHandler(button1_Click);
			ckbReviewTag.AutoSize = true;
			ckbReviewTag.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbReviewTag.Location = new System.Drawing.Point(16, 134);
			ckbReviewTag.Name = "ckbReviewTag";
			ckbReviewTag.Size = new System.Drawing.Size(189, 20);
			ckbReviewTag.TabIndex = 2;
			ckbReviewTag.Text = "Bật duyệt bài viết trên tường";
			ckbReviewTag.UseVisualStyleBackColor = true;
			plShowCoBan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plShowCoBan.Controls.Add(plRepeatAll);
			plShowCoBan.Controls.Add(ckbGetCookie);
			plShowCoBan.Controls.Add(ckbCreateProfile);
			plShowCoBan.Controls.Add(btnShowCoBan);
			plShowCoBan.Controls.Add(ckbDontSaveBrowser);
			plShowCoBan.Controls.Add(ckbCheckLiveUid);
			plShowCoBan.Controls.Add(ckbCapNhatThongTin);
			plShowCoBan.Controls.Add(ckbRepeatAll);
			plShowCoBan.Controls.Add(ckbLogOut);
			plShowCoBan.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			plShowCoBan.Location = new System.Drawing.Point(11, 44);
			plShowCoBan.MaximumSize = new System.Drawing.Size(420, 203);
			plShowCoBan.MinimumSize = new System.Drawing.Size(420, 27);
			plShowCoBan.Name = "plShowCoBan";
			plShowCoBan.Size = new System.Drawing.Size(420, 203);
			plShowCoBan.TabIndex = 3;
			plRepeatAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plRepeatAll.Controls.Add(label6);
			plRepeatAll.Controls.Add(label4);
			plRepeatAll.Controls.Add(nudDelayTurnFrom);
			plRepeatAll.Controls.Add(label5);
			plRepeatAll.Controls.Add(nudDelayTurnTo);
			plRepeatAll.Controls.Add(label11);
			plRepeatAll.Controls.Add(nudSoLuotChay);
			plRepeatAll.Controls.Add(label10);
			plRepeatAll.Location = new System.Drawing.Point(36, 131);
			plRepeatAll.Name = "plRepeatAll";
			plRepeatAll.Size = new System.Drawing.Size(376, 64);
			plRepeatAll.TabIndex = 13;
			label6.AutoSize = true;
			label6.Location = new System.Drawing.Point(3, 6);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(84, 16);
			label6.TabIndex = 5;
			label6.Text = "Sô\u0301 lươ\u0323t cha\u0323y:";
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(3, 34);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(145, 16);
			label4.TabIndex = 6;
			label4.Text = "Chờ cha\u0323y lươ\u0323t tiê\u0301p theo:";
			nudDelayTurnFrom.Location = new System.Drawing.Point(154, 32);
			nudDelayTurnFrom.Maximum = new decimal(new int[4] { 276447231, 23283, 0, 0 });
			nudDelayTurnFrom.Name = "nudDelayTurnFrom";
			nudDelayTurnFrom.Size = new System.Drawing.Size(65, 23);
			nudDelayTurnFrom.TabIndex = 9;
			label5.Location = new System.Drawing.Point(222, 7);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(30, 16);
			label5.TabIndex = 10;
			label5.Text = "lươ\u0323t";
			label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label5.Click += new System.EventHandler(label5_Click);
			nudDelayTurnTo.Location = new System.Drawing.Point(252, 32);
			nudDelayTurnTo.Maximum = new decimal(new int[4] { 276447231, 23283, 0, 0 });
			nudDelayTurnTo.Name = "nudDelayTurnTo";
			nudDelayTurnTo.Size = new System.Drawing.Size(65, 23);
			nudDelayTurnTo.TabIndex = 8;
			label11.AutoSize = true;
			label11.Location = new System.Drawing.Point(320, 35);
			label11.Name = "label11";
			label11.Size = new System.Drawing.Size(33, 16);
			label11.TabIndex = 11;
			label11.Text = "phút";
			nudSoLuotChay.Location = new System.Drawing.Point(154, 4);
			nudSoLuotChay.Maximum = new decimal(new int[4] { 276447231, 23283, 0, 0 });
			nudSoLuotChay.Name = "nudSoLuotChay";
			nudSoLuotChay.Size = new System.Drawing.Size(65, 23);
			nudSoLuotChay.TabIndex = 7;
			label10.Location = new System.Drawing.Point(222, 35);
			label10.Name = "label10";
			label10.Size = new System.Drawing.Size(29, 16);
			label10.TabIndex = 12;
			label10.Text = "đến";
			label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			btnShowCoBan.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
			btnShowCoBan.Cursor = System.Windows.Forms.Cursors.Hand;
			btnShowCoBan.Dock = System.Windows.Forms.DockStyle.Top;
			btnShowCoBan.FlatAppearance.BorderSize = 0;
			btnShowCoBan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnShowCoBan.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnShowCoBan.ForeColor = System.Drawing.Color.Black;
			btnShowCoBan.Image = maxcare.Properties.Resources.icons8_collapse_arrow_24px;
			btnShowCoBan.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			btnShowCoBan.Location = new System.Drawing.Point(0, 0);
			btnShowCoBan.Name = "btnShowCoBan";
			btnShowCoBan.Size = new System.Drawing.Size(418, 25);
			btnShowCoBan.TabIndex = 2;
			btnShowCoBan.Text = "Cấu hình cơ bản";
			btnShowCoBan.UseVisualStyleBackColor = false;
			btnShowCoBan.Click += new System.EventHandler(button5_Click);
			ckbDontSaveBrowser.AutoSize = true;
			ckbDontSaveBrowser.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDontSaveBrowser.Location = new System.Drawing.Point(222, 83);
			ckbDontSaveBrowser.Name = "ckbDontSaveBrowser";
			ckbDontSaveBrowser.Size = new System.Drawing.Size(200, 20);
			ckbDontSaveBrowser.TabIndex = 2;
			ckbDontSaveBrowser.Text = "Không lưu trình duyệt khi login";
			ckbDontSaveBrowser.UseVisualStyleBackColor = true;
			ckbCheckLiveUid.AutoSize = true;
			ckbCheckLiveUid.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbCheckLiveUid.Location = new System.Drawing.Point(16, 83);
			ckbCheckLiveUid.Name = "ckbCheckLiveUid";
			ckbCheckLiveUid.Size = new System.Drawing.Size(193, 20);
			ckbCheckLiveUid.TabIndex = 2;
			ckbCheckLiveUid.Text = "Check Live Uid trước khi chạy";
			ckbCheckLiveUid.UseVisualStyleBackColor = true;
			timer1.Interval = 15;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			timer2.Interval = 15;
			timer2.Tick += new System.EventHandler(timer2_Tick);
			rbLoginMbasic.AutoSize = true;
			rbLoginMbasic.Cursor = System.Windows.Forms.Cursors.Hand;
			rbLoginMbasic.Location = new System.Drawing.Point(161, 3);
			rbLoginMbasic.Name = "rbLoginMbasic";
			rbLoginMbasic.Size = new System.Drawing.Size(66, 20);
			rbLoginMbasic.TabIndex = 5;
			rbLoginMbasic.Text = "mbasic";
			rbLoginMbasic.UseVisualStyleBackColor = true;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(442, 485);
			base.Controls.Add(btnCancel);
			base.Controls.Add(btnAdd);
			base.Controls.Add(bunifuCards1);
			base.Controls.Add(panel1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "fCauHinhTuongTac";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "fAddFile";
			base.Load += new System.EventHandler(fCauHinhTuongTac_Load);
			bunifuCards1.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			plTuongTacKichBan.ResumeLayout(false);
			plTuongTacKichBan.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			panel1.ResumeLayout(false);
			plShowNangCao.ResumeLayout(false);
			plShowNangCao.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			plShowCoBan.ResumeLayout(false);
			plShowCoBan.PerformLayout();
			plRepeatAll.ResumeLayout(false);
			plRepeatAll.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudDelayTurnFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayTurnTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuotChay).EndInit();
			ResumeLayout(false);
		}
	}
}
