using System;
using System.Linq;
using System.Text.RegularExpressions;
using AE.Net.Mail;
using MCommon;

namespace maxcare.Helper
{
	internal class EmailHelper
	{
		public static void DeleteMail(string username, string password, string imap = "")
		{
			int num = 0;
			while (true)
			{
				try
				{
					if (imap == "")
					{
						imap = "outlook.office365.com";
						if (username.Contains("@hotmail.") || username.Contains("@outlook.") || username.Contains("@rickystar.") || username.Contains("@nickpromail."))
						{
							imap = "outlook.office365.com";
						}
						else if (username.EndsWith("@yandex.com"))
						{
							imap = "imap.yandex.com";
						}
						else if (username.EndsWith("@gmail.com"))
						{
							imap = "imap.gmail.com";
						}
					}
					ImapClient imapClient = new ImapClient(imap, username, password, AuthMethods.Login, 993, secure: true);
					Lazy<MailMessage>[] array = null;
					array = ((!(imap == "imap.yandex.com")) ? imapClient.SearchMessages(SearchCondition.From("security@facebookmail.com").And(SearchCondition.Unseen())) : imapClient.SearchMessages(SearchCondition.Unseen()));
					if (array.Length != 0)
					{
						for (int num2 = array.Length - 1; num2 >= 0; num2--)
						{
							Lazy<MailMessage> lazy = array[num2];
							imapClient.DeleteMessage(lazy.Value);
						}
					}
					if (imapClient.IsDisposed)
					{
						imapClient.Dispose();
					}
					if (imapClient.IsConnected)
					{
						imapClient.Disconnect();
					}
					return;
				}
				catch (Exception ex)
				{
					if (ex.ToString().Contains("The remote certificate is invalid according to the validation procedure"))
					{
						num++;
						if (num < 10)
						{
							continue;
						}
						return;
					}
					return;
				}
			}
		}

		public static string GetOtpFromMail(int type, string username, string password, int timeout = 10, string imap = "")
		{
			int num = 0;
			int num2 = 10;
			if (imap == "")
			{
				imap = "outlook.office365.com";
				if (username.Contains("@hotmail.") || username.Contains("@outlook.") || username.Contains("@rickystar.") || username.Contains("@nickpromail."))
				{
					imap = "outlook.office365.com";
				}
				else if (username.EndsWith("@yandex.com"))
				{
					imap = "imap.yandex.com";
				}
				else if (username.EndsWith("@gmail.com"))
				{
					imap = "imap.gmail.com";
				}
			}
			while (true)
			{
				try
				{
					ImapClient imapClient = new ImapClient(imap, username, password, AuthMethods.Login, 993, secure: true);
					for (int i = 0; i < timeout; i++)
					{
						try
						{
							for (int j = 0; j < 2; j++)
							{
								if (imap == "imap.yandex.com")
								{
									j = 1;
								}
								if (j == 0)
								{
									imapClient.SelectMailbox("Inbox");
								}
								else
								{
									imapClient.SelectMailbox("Spam");
								}
								int messageCount = imapClient.GetMessageCount();
								if (messageCount <= 0)
								{
									continue;
								}
								Lazy<MailMessage>[] array = null;
								array = ((!(imap == "imap.yandex.com")) ? imapClient.SearchMessages(SearchCondition.From("security@facebookmail.com").Or(SearchCondition.From("registration@facebookmail.com")).And(SearchCondition.Unseen())) : imapClient.SearchMessages(SearchCondition.Unseen()));
								if (array.Length == 0)
								{
									continue;
								}
								int num3 = array.Count() - 1;
								while (num3 >= 0)
								{
									string input = array[num3].Value.Body.ToString();
									string text = "";
									switch (type)
									{
									case 0:
										text = Regex.Match(input, "https://www.facebook.com/confirmcontact.php(.*?)\n").Value.Trim();
										break;
									case 1:
										text = Regex.Match(input, "\\d{8}").Value.Trim();
										break;
									case 2:
										text = Regex.Match(input, "https://www.facebook.com/n/\\?confirmemail.php(.*?)\n").Value.Trim();
										if (text == "")
										{
											text = Regex.Match(input, "https://www.facebook.com/confirmcontact.php(.*?)\n").Value.Trim();
										}
										break;
									case 3:
										text = Regex.Match(input, "confirmcontact.php\\?c=(.*?)&").Groups[1].Value;
										break;
									}
									if (!(text != ""))
									{
										num3--;
										continue;
									}
									if (imapClient.IsDisposed)
									{
										imapClient.Dispose();
									}
									if (imapClient.IsConnected)
									{
										imapClient.Disconnect();
									}
									return text;
								}
							}
						}
						catch
						{
						}
						MCommon.Common.DelayTime(1.0);
					}
					if (imapClient.IsDisposed)
					{
						imapClient.Dispose();
					}
					if (imapClient.IsConnected)
					{
						imapClient.Disconnect();
					}
				}
				catch (Exception ex)
				{
					if (ex.ToString().ToLower().Contains("blocked"))
					{
						return "block";
					}
					num++;
					if (num < num2)
					{
						continue;
					}
				}
				break;
			}
			return "";
		}

		public static string GetOtpFromMail2(int type, string username, string password, string subUser, int timeout = 10, string imap = "")
		{
			int num = 0;
			int num2 = 10;
			if (imap == "")
			{
				imap = "outlook.office365.com";
				if (username.Contains("@hotmail.") || username.Contains("@outlook.") || username.Contains("@rickystar.") || username.Contains("@nickpromail."))
				{
					imap = "outlook.office365.com";
				}
				else if (username.EndsWith("@yandex.com"))
				{
					imap = "imap.yandex.com";
				}
				else if (username.EndsWith("@gmail.com"))
				{
					imap = "imap.gmail.com";
				}
			}
			while (true)
			{
				try
				{
					ImapClient imapClient = new ImapClient(imap, username, password, AuthMethods.Login, 993, secure: true);
					for (int i = 0; i < timeout; i++)
					{
						try
						{
							for (int j = 0; j < 3; j++)
							{
								if (j <= 1)
								{
									imapClient.SelectMailbox("Inbox");
								}
								else
								{
									imapClient.SelectMailbox("Spam");
								}
								int messageCount = imapClient.GetMessageCount();
								if (messageCount <= 0)
								{
									continue;
								}
								Lazy<MailMessage>[] array = null;
								if (imap == "imap.yandex.com")
								{
									array = imapClient.SearchMessages(SearchCondition.To(subUser));
								}
								if (array.Length == 0)
								{
									continue;
								}
								for (int num3 = array.Count() - 1; num3 >= array.Count() - 20; num3--)
								{
									try
									{
										string text = array[num3].Value.Body.ToString();
										if (text.Contains(subUser))
										{
											string text2 = "";
											switch (type)
											{
											case 1:
												text2 = Regex.Match(text, "\\d{8}").Value.Trim();
												break;
											case 0:
												text2 = Regex.Match(text, "https://www.facebook.com/confirmcontact.php(.*?)\n").Value.Trim();
												break;
											}
											if (text2 != "")
											{
												if (imapClient.IsDisposed)
												{
													imapClient.Dispose();
												}
												if (imapClient.IsConnected)
												{
													imapClient.Disconnect();
												}
												return text2;
											}
										}
									}
									catch
									{
										goto IL_0277;
									}
								}
								IL_0277:;
							}
						}
						catch (Exception)
						{
						}
						MCommon.Common.DelayTime(1.0);
					}
					if (imapClient.IsDisposed)
					{
						imapClient.Dispose();
					}
					if (imapClient.IsConnected)
					{
						imapClient.Disconnect();
					}
				}
				catch (Exception ex2)
				{
					if (ex2.ToString().ToLower().Contains("blocked"))
					{
						return "block";
					}
					num++;
					if (num < num2)
					{
						continue;
					}
				}
				break;
			}
			return "";
		}
	}
}
