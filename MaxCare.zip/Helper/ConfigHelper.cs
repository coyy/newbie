using System.Linq;

namespace maxcare.Helper
{
	public class ConfigHelper
	{
		public static string GetPathProfile()
		{
			JsonHelper jsonHelper = new JsonHelper("configGeneral");
			string text = jsonHelper.GetValue("txbPathProfile");
			if (!text.Contains('\\'))
			{
				text = FileHelper.GetPathToCurrentFolder() + "\\" + ((jsonHelper.GetValue("txbPathProfile") == "") ? "profiles" : jsonHelper.GetValue("txbPathProfile"));
			}
			return text;
		}

		public static string GetPathBackup()
		{
			return FileHelper.GetPathToCurrentFolder() + "\\backup";
		}
	}
}
