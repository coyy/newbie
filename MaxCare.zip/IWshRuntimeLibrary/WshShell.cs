using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace IWshRuntimeLibrary
{
	[ComImport]
	[CompilerGenerated]
	[Guid("41904400-BE18-11D3-A28B-00104BD35090")]
	[CoClass(typeof(Object))]
	[TypeIdentifier]
	public interface WshShell : IWshShell3
	{
	}
}
