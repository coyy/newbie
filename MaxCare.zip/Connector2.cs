using System.Data;
using System.Data.SQLite;

namespace maxcare
{
	public class Connector2
	{
		private static Connector2 instance;

		private string connectionSTR = "Data Source=database/db_post.db;Version=3;";

		public static Connector2 Instance
		{
			get
			{
				if (instance == null)
				{
					instance = new Connector2();
				}
				return instance;
			}
			private set
			{
				instance = value;
			}
		}

		private Connector2()
		{
		}

		public DataTable ExecuteQuery(string query)
		{
			DataTable dataTable = new DataTable();
			using (SQLiteConnection sQLiteConnection = new SQLiteConnection(connectionSTR))
			{
				sQLiteConnection.Open();
				SQLiteCommand cmd = new SQLiteCommand(query, sQLiteConnection);
				SQLiteDataAdapter sQLiteDataAdapter = new SQLiteDataAdapter(cmd);
				sQLiteDataAdapter.Fill(dataTable);
				sQLiteConnection.Close();
			}
			return dataTable;
		}

		public int ExecuteNonQuery(string query)
		{
			int result = 0;
			try
			{
				using SQLiteConnection sQLiteConnection = new SQLiteConnection(connectionSTR);
				sQLiteConnection.Open();
				SQLiteCommand sQLiteCommand = new SQLiteCommand(query, sQLiteConnection);
				result = sQLiteCommand.ExecuteNonQuery();
				sQLiteConnection.Close();
			}
			catch
			{
			}
			return result;
		}

		public object ExecuteScalar(string query)
		{
			object result = 0;
			using (SQLiteConnection sQLiteConnection = new SQLiteConnection(connectionSTR))
			{
				sQLiteConnection.Open();
				SQLiteCommand sQLiteCommand = new SQLiteCommand(query, sQLiteConnection);
				long num = (long)sQLiteCommand.ExecuteScalar();
				result = (int)num;
				sQLiteConnection.Close();
			}
			return result;
		}
	}
}
