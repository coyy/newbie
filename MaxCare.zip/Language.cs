using System.Windows.Forms;

namespace maxcare
{
	public class Language
	{
		public static string data = "";

		public static string GetValue(string key)
		{
			return key;
		}

		public static void GetValue(Control control)
		{
			control.Text = GetValue(control.Text);
		}

		public static void GetValue(ToolStripItem control)
		{
			control.Text = GetValue(control.Text);
		}

		public static void GetValue(DataGridViewColumn control)
		{
			control.HeaderText = GetValue(control.HeaderText);
		}
	}
}
