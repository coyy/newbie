using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.Properties;
using MCommon;

namespace maxcare
{
	public class fCheckPoint : Form
	{
		private JSON_Settings setting;

		public static bool isOK;

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private Panel panel1;

		private Button btnCancel;

		private Button btnAdd;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private Button button1;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private CheckBox ckbCaptcha;

		private TextBox txtImage;

		private CheckBox ckbImage;

		private TextBox txtTextNow;

		private CheckBox ckbPhone;

		private TextBox txt2Captcha;

		private Panel panel2;

		private Label label3;

		private NumericUpDown nudTime;

		private Label label2;

		private RadioButton rbSimCode;

		private TextBox txtSimCode;

		private RadioButton rbOtpSim;

		private TextBox txtOtpSim;

		private RadioButton rbTextNow;

		private Panel panel3;

		private RadioButton rbGuru;

		private RadioButton rb2Captcha;

		private TextBox txtGuru;

		private RadioButton rbOtpmmo;

		private TextBox txtOtpmmo;

		private RadioButton rbAnyCaptcha;

		private TextBox txtAnyCaptcha;

		private RadioButton rbPrimeOtp;

		private TextBox txtPrimeOtp;

		public fCheckPoint()
		{
			InitializeComponent();
			isOK = false;
			setting = new JSON_Settings("configCheckpoint");
		}

		private void FConfigInteract_Load(object sender, EventArgs e)
		{
			try
			{
				ckbCaptcha.Checked = setting.GetValueBool("ckbCaptcha");
				switch (setting.GetValueInt("typeCaptcha"))
				{
				case 0:
					rb2Captcha.Checked = true;
					break;
				case 1:
					rbGuru.Checked = true;
					break;
				default:
					rbAnyCaptcha.Checked = true;
					break;
				}
				txt2Captcha.Text = setting.GetValue("txt2Captcha");
				txtGuru.Text = setting.GetValue("txtGuru");
				txtAnyCaptcha.Text = setting.GetValue("txtAnyCaptcha");
				ckbPhone.Checked = setting.GetValueBool("ckbPhone");
				switch (setting.GetValueInt("typeSim"))
				{
				case 0:
					rbTextNow.Checked = true;
					break;
				case 1:
					rbOtpSim.Checked = true;
					break;
				case 2:
					rbSimCode.Checked = true;
					break;
				case 3:
					rbOtpmmo.Checked = true;
					break;
				default:
					rbPrimeOtp.Checked = true;
					break;
				}
				txtTextNow.Text = setting.GetValue("txtTextNow");
				txtOtpSim.Text = setting.GetValue("txtOtpSim");
				txtSimCode.Text = setting.GetValue("txtSimCode");
				txtOtpmmo.Text = setting.GetValue("txtOtpmmo");
				txtPrimeOtp.Text = setting.GetValue("txtPrimeOtp");
				nudTime.Value = setting.GetValueInt("nudTime", 120);
				ckbImage.Checked = setting.GetValueBool("ckbImage");
				txtImage.Text = setting.GetValue("txtImage");
			}
			catch
			{
			}
			CheckedChangeFull();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			try
			{
				setting.Update("ckbCaptcha", ckbCaptcha.Checked);
				int num = 0;
				if (rb2Captcha.Checked)
				{
					num = 0;
				}
				if (rbGuru.Checked)
				{
					num = 1;
				}
				else if (rbAnyCaptcha.Checked)
				{
					num = 2;
				}
				setting.Update("typeCaptcha", num);
				setting.Update("txt2Captcha", txt2Captcha.Text);
				setting.Update("txtGuru", txtGuru.Text);
				setting.Update("txtAnyCaptcha", txtAnyCaptcha.Text);
				setting.Update("ckbPhone", ckbPhone.Checked);
				int num2 = 0;
				if (rbTextNow.Checked)
				{
					num2 = 0;
				}
				if (rbOtpSim.Checked)
				{
					num2 = 1;
				}
				else if (rbSimCode.Checked)
				{
					num2 = 2;
				}
				else if (rbOtpmmo.Checked)
				{
					num2 = 3;
				}
				else if (rbPrimeOtp.Checked)
				{
					num2 = 4;
				}
				setting.Update("typeSim", num2);
				setting.Update("txtTextNow", txtTextNow.Text);
				setting.Update("txtOtpSim", txtOtpSim.Text);
				setting.Update("txtSimCode", txtSimCode.Text);
				setting.Update("txtOtpmmo", txtOtpmmo.Text);
				setting.Update("txtPrimeOtp", txtPrimeOtp.Text);
				setting.Update("nudTime", nudTime.Value);
				setting.Update("ckbImage", ckbImage.Checked);
				setting.Update("txtImage", txtImage.Text);
				setting.Save();
				isOK = true;
				Close();
			}
			catch
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lòng thử lại sau!"), 2);
			}
		}

		private void CheckedChangeFull()
		{
			checkBox1_CheckedChanged(null, null);
			ckbPhone_CheckedChanged(null, null);
			ckbImage_CheckedChanged(null, null);
			rbTextNow_CheckedChanged(null, null);
			rbOtpSim_CheckedChanged(null, null);
			rbSimCode_CheckedChanged(null, null);
			rb2Captcha_CheckedChanged(null, null);
			rbGuru_CheckedChanged(null, null);
			rbAnyCaptcha_CheckedChanged(null, null);
			rbOtpmmo_CheckedChanged(null, null);
			rbPrimeOtp_CheckedChanged(null, null);
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			if (panel1.BorderStyle == BorderStyle.FixedSingle)
			{
				int num = 1;
				int num2 = 0;
				using Pen pen = new Pen(Color.DarkViolet, 1f);
				e.Graphics.DrawRectangle(pen, new Rectangle(num2, num2, panel1.ClientSize.Width - num, panel1.ClientSize.Height - num));
			}
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			panel3.Enabled = ckbCaptcha.Checked;
		}

		private void ckbPhone_CheckedChanged(object sender, EventArgs e)
		{
			panel2.Enabled = ckbPhone.Checked;
		}

		private void ckbImage_CheckedChanged(object sender, EventArgs e)
		{
			txtImage.Enabled = ckbImage.Checked;
		}

		private void rbTextNow_CheckedChanged(object sender, EventArgs e)
		{
			if (rbTextNow.Checked)
			{
				txtTextNow.Enabled = true;
				txtOtpSim.Enabled = false;
				txtSimCode.Enabled = false;
				txtOtpmmo.Enabled = false;
				txtPrimeOtp.Enabled = false;
			}
		}

		private void rbOtpSim_CheckedChanged(object sender, EventArgs e)
		{
			if (rbOtpSim.Checked)
			{
				txtTextNow.Enabled = false;
				txtOtpSim.Enabled = true;
				txtSimCode.Enabled = false;
				txtOtpmmo.Enabled = false;
				txtPrimeOtp.Enabled = false;
			}
		}

		private void rbSimCode_CheckedChanged(object sender, EventArgs e)
		{
			if (rbSimCode.Checked)
			{
				txtTextNow.Enabled = false;
				txtOtpSim.Enabled = false;
				txtSimCode.Enabled = true;
				txtOtpmmo.Enabled = false;
				txtPrimeOtp.Enabled = false;
			}
		}

		private void rb2Captcha_CheckedChanged(object sender, EventArgs e)
		{
			txt2Captcha.Enabled = rb2Captcha.Checked;
			txtGuru.Enabled = !rb2Captcha.Checked;
			txtAnyCaptcha.Enabled = !rb2Captcha.Checked;
		}

		private void rbOtpmmo_CheckedChanged(object sender, EventArgs e)
		{
			if (rbOtpmmo.Checked)
			{
				txtTextNow.Enabled = false;
				txtOtpSim.Enabled = false;
				txtSimCode.Enabled = false;
				txtOtpmmo.Enabled = true;
				txtPrimeOtp.Enabled = false;
			}
		}

		private void rbAnyCaptcha_CheckedChanged(object sender, EventArgs e)
		{
			txt2Captcha.Enabled = !rbAnyCaptcha.Checked;
			txtGuru.Enabled = !rbAnyCaptcha.Checked;
			txtAnyCaptcha.Enabled = rbAnyCaptcha.Checked;
		}

		private void rbGuru_CheckedChanged(object sender, EventArgs e)
		{
			txt2Captcha.Enabled = !rbGuru.Checked;
			txtGuru.Enabled = rbGuru.Checked;
			txtAnyCaptcha.Enabled = !rbGuru.Checked;
		}

		private void rbPrimeOtp_CheckedChanged(object sender, EventArgs e)
		{
			if (rbPrimeOtp.Checked)
			{
				txtTextNow.Enabled = false;
				txtOtpSim.Enabled = false;
				txtSimCode.Enabled = false;
				txtOtpmmo.Enabled = false;
				txtPrimeOtp.Enabled = true;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			button1 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			panel1 = new System.Windows.Forms.Panel();
			panel3 = new System.Windows.Forms.Panel();
			rbGuru = new System.Windows.Forms.RadioButton();
			rb2Captcha = new System.Windows.Forms.RadioButton();
			txtGuru = new System.Windows.Forms.TextBox();
			txt2Captcha = new System.Windows.Forms.TextBox();
			panel2 = new System.Windows.Forms.Panel();
			rbOtpmmo = new System.Windows.Forms.RadioButton();
			txtOtpmmo = new System.Windows.Forms.TextBox();
			rbSimCode = new System.Windows.Forms.RadioButton();
			txtSimCode = new System.Windows.Forms.TextBox();
			rbOtpSim = new System.Windows.Forms.RadioButton();
			txtOtpSim = new System.Windows.Forms.TextBox();
			rbTextNow = new System.Windows.Forms.RadioButton();
			label3 = new System.Windows.Forms.Label();
			nudTime = new System.Windows.Forms.NumericUpDown();
			label2 = new System.Windows.Forms.Label();
			txtTextNow = new System.Windows.Forms.TextBox();
			txtImage = new System.Windows.Forms.TextBox();
			ckbImage = new System.Windows.Forms.CheckBox();
			ckbPhone = new System.Windows.Forms.CheckBox();
			ckbCaptcha = new System.Windows.Forms.CheckBox();
			btnCancel = new System.Windows.Forms.Button();
			btnAdd = new System.Windows.Forms.Button();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			rbAnyCaptcha = new System.Windows.Forms.RadioButton();
			txtAnyCaptcha = new System.Windows.Forms.TextBox();
			rbPrimeOtp = new System.Windows.Forms.RadioButton();
			txtPrimeOtp = new System.Windows.Forms.TextBox();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel1.SuspendLayout();
			panel3.SuspendLayout();
			panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudTime).BeginInit();
			bunifuCards1.SuspendLayout();
			SuspendLayout();
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(420, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Cấu hình Giải Checkpoint";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = pnlHeader;
			bunifuDragControl2.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button1);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(420, 31);
			pnlHeader.TabIndex = 9;
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Image = maxcare.Properties.Resources.button21;
			button1.Location = new System.Drawing.Point(389, 1);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(30, 30);
			button1.TabIndex = 77;
			button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(panel3);
			panel1.Controls.Add(panel2);
			panel1.Controls.Add(txtImage);
			panel1.Controls.Add(ckbImage);
			panel1.Controls.Add(ckbPhone);
			panel1.Controls.Add(ckbCaptcha);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(btnAdd);
			panel1.Controls.Add(bunifuCards1);
			panel1.Cursor = System.Windows.Forms.Cursors.Arrow;
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(423, 450);
			panel1.TabIndex = 0;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel3.Controls.Add(rbAnyCaptcha);
			panel3.Controls.Add(txtAnyCaptcha);
			panel3.Controls.Add(rbGuru);
			panel3.Controls.Add(rb2Captcha);
			panel3.Controls.Add(txtGuru);
			panel3.Controls.Add(txt2Captcha);
			panel3.Location = new System.Drawing.Point(43, 80);
			panel3.Name = "panel3";
			panel3.Size = new System.Drawing.Size(368, 83);
			panel3.TabIndex = 39;
			rbGuru.AutoSize = true;
			rbGuru.Location = new System.Drawing.Point(3, 56);
			rbGuru.Name = "rbGuru";
			rbGuru.Size = new System.Drawing.Size(105, 20);
			rbGuru.TabIndex = 42;
			rbGuru.Text = "captcha.guru:";
			rbGuru.UseVisualStyleBackColor = true;
			rbGuru.CheckedChanged += new System.EventHandler(rbGuru_CheckedChanged);
			rb2Captcha.AutoSize = true;
			rb2Captcha.Checked = true;
			rb2Captcha.Location = new System.Drawing.Point(3, 29);
			rb2Captcha.Name = "rb2Captcha";
			rb2Captcha.Size = new System.Drawing.Size(110, 20);
			rb2Captcha.TabIndex = 41;
			rb2Captcha.TabStop = true;
			rb2Captcha.Text = "2captcha.com:";
			rb2Captcha.UseVisualStyleBackColor = true;
			rb2Captcha.CheckedChanged += new System.EventHandler(rb2Captcha_CheckedChanged);
			txtGuru.Location = new System.Drawing.Point(123, 55);
			txtGuru.Name = "txtGuru";
			txtGuru.Size = new System.Drawing.Size(240, 23);
			txtGuru.TabIndex = 34;
			txt2Captcha.Location = new System.Drawing.Point(123, 28);
			txt2Captcha.Name = "txt2Captcha";
			txt2Captcha.Size = new System.Drawing.Size(240, 23);
			txt2Captcha.TabIndex = 33;
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel2.Controls.Add(rbPrimeOtp);
			panel2.Controls.Add(txtPrimeOtp);
			panel2.Controls.Add(rbOtpmmo);
			panel2.Controls.Add(txtOtpmmo);
			panel2.Controls.Add(rbSimCode);
			panel2.Controls.Add(txtSimCode);
			panel2.Controls.Add(rbOtpSim);
			panel2.Controls.Add(txtOtpSim);
			panel2.Controls.Add(rbTextNow);
			panel2.Controls.Add(label3);
			panel2.Controls.Add(nudTime);
			panel2.Controls.Add(label2);
			panel2.Controls.Add(txtTextNow);
			panel2.Location = new System.Drawing.Point(40, 195);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(371, 170);
			panel2.TabIndex = 38;
			rbOtpmmo.AutoSize = true;
			rbOtpmmo.Checked = true;
			rbOtpmmo.Location = new System.Drawing.Point(6, 7);
			rbOtpmmo.Name = "rbOtpmmo";
			rbOtpmmo.Size = new System.Drawing.Size(108, 20);
			rbOtpmmo.TabIndex = 46;
			rbOtpmmo.TabStop = true;
			rbOtpmmo.Text = "Otpmmo.com:";
			rbOtpmmo.UseVisualStyleBackColor = true;
			rbOtpmmo.CheckedChanged += new System.EventHandler(rbOtpmmo_CheckedChanged);
			txtOtpmmo.Location = new System.Drawing.Point(165, 3);
			txtOtpmmo.Name = "txtOtpmmo";
			txtOtpmmo.Size = new System.Drawing.Size(201, 23);
			txtOtpmmo.TabIndex = 45;
			rbSimCode.AutoSize = true;
			rbSimCode.Location = new System.Drawing.Point(6, 112);
			rbSimCode.Name = "rbSimCode";
			rbSimCode.Size = new System.Drawing.Size(153, 20);
			rbSimCode.TabIndex = 44;
			rbSimCode.Text = "Chothuesimcode.com:";
			rbSimCode.UseVisualStyleBackColor = true;
			rbSimCode.CheckedChanged += new System.EventHandler(rbSimCode_CheckedChanged);
			txtSimCode.Location = new System.Drawing.Point(165, 111);
			txtSimCode.Name = "txtSimCode";
			txtSimCode.Size = new System.Drawing.Size(201, 23);
			txtSimCode.TabIndex = 43;
			rbOtpSim.AutoSize = true;
			rbOtpSim.Location = new System.Drawing.Point(6, 84);
			rbOtpSim.Name = "rbOtpSim";
			rbOtpSim.Size = new System.Drawing.Size(101, 20);
			rbOtpSim.TabIndex = 42;
			rbOtpSim.Text = "OtpSim.com:";
			rbOtpSim.UseVisualStyleBackColor = true;
			rbOtpSim.CheckedChanged += new System.EventHandler(rbOtpSim_CheckedChanged);
			txtOtpSim.Location = new System.Drawing.Point(165, 83);
			txtOtpSim.Name = "txtOtpSim";
			txtOtpSim.Size = new System.Drawing.Size(201, 23);
			txtOtpSim.TabIndex = 41;
			rbTextNow.AutoSize = true;
			rbTextNow.Location = new System.Drawing.Point(6, 32);
			rbTextNow.Name = "rbTextNow";
			rbTextNow.Size = new System.Drawing.Size(133, 20);
			rbTextNow.TabIndex = 40;
			rbTextNow.Text = "Codetextnow.com:";
			rbTextNow.UseVisualStyleBackColor = true;
			rbTextNow.CheckedChanged += new System.EventHandler(rbTextNow_CheckedChanged);
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(103, 144);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(31, 16);
			label3.TabIndex = 39;
			label3.Text = "giây";
			nudTime.Location = new System.Drawing.Point(41, 141);
			nudTime.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudTime.Name = "nudTime";
			nudTime.Size = new System.Drawing.Size(56, 23);
			nudTime.TabIndex = 38;
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(3, 144);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(35, 16);
			label2.TabIndex = 37;
			label2.Text = "Chờ:";
			txtTextNow.Location = new System.Drawing.Point(165, 31);
			txtTextNow.Name = "txtTextNow";
			txtTextNow.Size = new System.Drawing.Size(201, 23);
			txtTextNow.TabIndex = 35;
			txtImage.Location = new System.Drawing.Point(120, 369);
			txtImage.Name = "txtImage";
			txtImage.Size = new System.Drawing.Size(290, 23);
			txtImage.TabIndex = 37;
			ckbImage.AutoSize = true;
			ckbImage.Location = new System.Drawing.Point(22, 371);
			ckbImage.Name = "ckbImage";
			ckbImage.Size = new System.Drawing.Size(72, 20);
			ckbImage.TabIndex = 36;
			ckbImage.Text = "Up ảnh:";
			ckbImage.UseVisualStyleBackColor = true;
			ckbImage.CheckedChanged += new System.EventHandler(ckbImage_CheckedChanged);
			ckbPhone.AutoSize = true;
			ckbPhone.Location = new System.Drawing.Point(22, 169);
			ckbPhone.Name = "ckbPhone";
			ckbPhone.Size = new System.Drawing.Size(94, 20);
			ckbPhone.TabIndex = 34;
			ckbPhone.Text = "Thêm SĐT:";
			ckbPhone.UseVisualStyleBackColor = true;
			ckbPhone.CheckedChanged += new System.EventHandler(ckbPhone_CheckedChanged);
			ckbCaptcha.AutoSize = true;
			ckbCaptcha.Location = new System.Drawing.Point(22, 54);
			ckbCaptcha.Name = "ckbCaptcha";
			ckbCaptcha.Size = new System.Drawing.Size(101, 20);
			ckbCaptcha.TabIndex = 32;
			ckbCaptcha.Text = "Giải captcha:";
			ckbCaptcha.UseVisualStyleBackColor = true;
			ckbCaptcha.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(221, 408);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 10;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(btnCancel_Click);
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(114, 408);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 9;
			btnAdd.Text = "Lưu";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(btnAdd_Click);
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.DarkViolet;
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(1, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(420, 37);
			bunifuCards1.TabIndex = 28;
			rbAnyCaptcha.AutoSize = true;
			rbAnyCaptcha.Location = new System.Drawing.Point(3, 3);
			rbAnyCaptcha.Name = "rbAnyCaptcha";
			rbAnyCaptcha.Size = new System.Drawing.Size(118, 20);
			rbAnyCaptcha.TabIndex = 44;
			rbAnyCaptcha.Text = "anycaptcha.com";
			rbAnyCaptcha.UseVisualStyleBackColor = true;
			rbAnyCaptcha.CheckedChanged += new System.EventHandler(rbAnyCaptcha_CheckedChanged);
			txtAnyCaptcha.Location = new System.Drawing.Point(123, 2);
			txtAnyCaptcha.Name = "txtAnyCaptcha";
			txtAnyCaptcha.Size = new System.Drawing.Size(240, 23);
			txtAnyCaptcha.TabIndex = 43;
			rbPrimeOtp.AutoSize = true;
			rbPrimeOtp.Location = new System.Drawing.Point(6, 58);
			rbPrimeOtp.Name = "rbPrimeOtp";
			rbPrimeOtp.Size = new System.Drawing.Size(104, 20);
			rbPrimeOtp.TabIndex = 48;
			rbPrimeOtp.Text = "Primeotp.me:";
			rbPrimeOtp.UseVisualStyleBackColor = true;
			rbPrimeOtp.CheckedChanged += new System.EventHandler(rbPrimeOtp_CheckedChanged);
			txtPrimeOtp.Location = new System.Drawing.Point(165, 57);
			txtPrimeOtp.Name = "txtPrimeOtp";
			txtPrimeOtp.Size = new System.Drawing.Size(201, 23);
			txtPrimeOtp.TabIndex = 47;
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(423, 450);
			base.Controls.Add(panel1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fCheckPoint";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình tương tác";
			base.Load += new System.EventHandler(FConfigInteract_Load);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudTime).EndInit();
			bunifuCards1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
