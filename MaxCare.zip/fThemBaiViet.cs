using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Properties;
using MCommon;
using MetroFramework.Controls;

namespace maxcare
{
	public class fThemBaiViet : Form
	{
		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Panel panel1;

		private BunifuDragControl bunifuDragControl1;

		private ToolTip toolTip1;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem thêmMớiToolStripMenuItem;

		private ToolStripMenuItem sửaToolStripMenuItem;

		private ToolStripMenuItem xóaToolStripMenuItem;

		private MetroButton metroButton1;

		private Label label1;

		private ComboBox cbbChuDe;

		private BunifuCards bunifuCards2;

		private Panel pnlHeader;

		private Button button2;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private DataGridView dgvPic;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private TextBox txtName;

		private Label label2;

		private Label label5;

		private Button btnCancel;

		private Button button1;

		private Label lblNanh;

		private MetroButton metroButton3;

		private MetroButton metroButton2;

		private RichTextBox txtConten;

		private Label label8;

		public fThemBaiViet(int cbbChuDeSlectedIndex)
		{
			InitializeComponent();
			LoadcbbChuDe();
			cbbChuDe.SelectedIndex = cbbChuDeSlectedIndex;
		}

		private void LoadcbbChuDe()
		{
			List<string> listChuDe = CommonSQL.GetListChuDe();
			for (int i = 0; i < listChuDe.Count; i++)
			{
				cbbChuDe.Items.Add(listChuDe[i]);
			}
			try
			{
				cbbChuDe.SelectedIndex = 0;
			}
			catch
			{
			}
		}

		private void BtnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fDanhSachChuDe());
			cbbChuDe.Items.Clear();
			LoadcbbChuDe();
		}

		private void btnAddLink_Click(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
			openFileDialog.FilterIndex = 0;
			openFileDialog.Multiselect = true;
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				string[] fileNames = openFileDialog.FileNames;
				for (int i = 0; i < fileNames.Length; i++)
				{
					dgvPic.Rows.Add(fileNames[i]);
				}
				lblNanh.Text = "Ảnh (" + dgvPic.Rows.Count + "):";
			}
		}

		private void btnDelLink_Click(object sender, EventArgs e)
		{
			foreach (DataGridViewRow selectedRow in dgvPic.SelectedRows)
			{
				dgvPic.Rows.RemoveAt(selectedRow.Index);
			}
			lblNanh.Text = "Ảnh (" + dgvPic.Rows.Count + "):";
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			if (txtName.Text != "")
			{
				string text = "";
				if (dgvPic.Rows.Count != 0)
				{
					for (int i = 0; i < dgvPic.Rows.Count; i++)
					{
						text = text + dgvPic.Rows[i].Cells[0].Value.ToString() + "|";
					}
				}
				string video = "";
				string tenchuDe = cbbChuDe.SelectedItem.ToString();
				BaiViet baiviet = new BaiViet
				{
					tieuDe = txtName.Text,
					anh = text,
					video = video,
					ngayTao = DateTime.Now.ToString("dd/MM/yyyy"),
					noiDung = txtConten.Text
				};
				CommonSQL.AddBaiViet(tenchuDe, baiviet);
				DialogResult dialogResult = MessageBox.Show("Thêm thành công. Bạn muốn có muốn đóng cửa sổ không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					Close();
				}
			}
			else
			{
				MCommon.Common.ShowMessageBox("Chưa nhập tiêu đề!", 2);
			}
		}

		private void btnEdit_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void dgvPic_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			Process.Start(dgvPic.SelectedRows[0].Cells[0].Value.ToString());
		}

		private void cbbChuDe_Click(object sender, EventArgs e)
		{
		}

		private void Panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void DgvVideo_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void BunifuCustomLabel1_Click(object sender, EventArgs e)
		{
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			MCommon.Common.ShowForm(new fHuongDanRandom());
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel1 = new System.Windows.Forms.Panel();
			txtConten = new System.Windows.Forms.RichTextBox();
			metroButton3 = new MetroFramework.Controls.MetroButton();
			metroButton2 = new MetroFramework.Controls.MetroButton();
			lblNanh = new System.Windows.Forms.Label();
			btnCancel = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			dgvPic = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			txtName = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			metroButton1 = new MetroFramework.Controls.MetroButton();
			label1 = new System.Windows.Forms.Label();
			cbbChuDe = new System.Windows.Forms.ComboBox();
			bunifuCards2 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			button2 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			thêmMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			sửaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			label8 = new System.Windows.Forms.Label();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dgvPic).BeginInit();
			bunifuCards2.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 5;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.SaddleBrown;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(43, 47);
			bunifuCards1.TabIndex = 12;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(label8);
			panel1.Controls.Add(txtConten);
			panel1.Controls.Add(metroButton3);
			panel1.Controls.Add(metroButton2);
			panel1.Controls.Add(lblNanh);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(button1);
			panel1.Controls.Add(dgvPic);
			panel1.Controls.Add(txtName);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(label5);
			panel1.Controls.Add(metroButton1);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(cbbChuDe);
			panel1.Controls.Add(bunifuCards2);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(372, 411);
			panel1.TabIndex = 37;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(Panel1_Paint);
			txtConten.Location = new System.Drawing.Point(76, 187);
			txtConten.Name = "txtConten";
			txtConten.Size = new System.Drawing.Size(271, 149);
			txtConten.TabIndex = 120;
			txtConten.Text = "";
			txtConten.WordWrap = false;
			metroButton3.BackgroundImage = maxcare.Properties.Resources.icons8_minus_30px;
			metroButton3.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton3.Location = new System.Drawing.Point(317, 149);
			metroButton3.Name = "metroButton3";
			metroButton3.Size = new System.Drawing.Size(30, 30);
			metroButton3.TabIndex = 114;
			metroButton3.UseSelectable = true;
			metroButton3.Click += new System.EventHandler(btnDelLink_Click);
			metroButton2.BackgroundImage = maxcare.Properties.Resources.icons8_add_30px;
			metroButton2.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton2.Location = new System.Drawing.Point(317, 110);
			metroButton2.Name = "metroButton2";
			metroButton2.Size = new System.Drawing.Size(30, 30);
			metroButton2.TabIndex = 115;
			metroButton2.UseSelectable = true;
			metroButton2.Click += new System.EventHandler(btnAddLink_Click);
			lblNanh.AutoSize = true;
			lblNanh.Location = new System.Drawing.Point(6, 110);
			lblNanh.Name = "lblNanh";
			lblNanh.Size = new System.Drawing.Size(56, 16);
			lblNanh.TabIndex = 109;
			lblNanh.Text = "Ảnh (0):";
			lblNanh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(184, 369);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 108;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(btnEdit_Click);
			button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			button1.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Location = new System.Drawing.Point(77, 369);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(92, 29);
			button1.TabIndex = 107;
			button1.Text = "Lưu";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(btnAdd_Click);
			dgvPic.AllowUserToAddRows = false;
			dgvPic.AllowUserToDeleteRows = false;
			dgvPic.AllowUserToResizeColumns = false;
			dgvPic.AllowUserToResizeRows = false;
			dgvPic.BackgroundColor = System.Drawing.Color.White;
			dgvPic.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgvPic.ColumnHeadersVisible = false;
			dgvPic.Columns.AddRange(dataGridViewTextBoxColumn4);
			dgvPic.Cursor = System.Windows.Forms.Cursors.Hand;
			dgvPic.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dgvPic.Location = new System.Drawing.Point(77, 109);
			dgvPic.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			dgvPic.Name = "dgvPic";
			dgvPic.RowHeadersVisible = false;
			dgvPic.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dgvPic.Size = new System.Drawing.Size(234, 70);
			dgvPic.TabIndex = 83;
			dgvPic.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvPic_CellDoubleClick);
			dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			dataGridViewTextBoxColumn4.DataPropertyName = "Day";
			dataGridViewTextBoxColumn4.FillWeight = 57.38708f;
			dataGridViewTextBoxColumn4.HeaderText = "Đường dẫn";
			dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
			txtName.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			txtName.Location = new System.Drawing.Point(77, 78);
			txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			txtName.Name = "txtName";
			txtName.Size = new System.Drawing.Size(270, 23);
			txtName.TabIndex = 87;
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label2.ForeColor = System.Drawing.SystemColors.ControlText;
			label2.Location = new System.Drawing.Point(6, 187);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(63, 16);
			label2.TabIndex = 86;
			label2.Text = "Nội dung:";
			label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label5.ForeColor = System.Drawing.SystemColors.ControlText;
			label5.Location = new System.Drawing.Point(6, 81);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(56, 16);
			label5.TabIndex = 85;
			label5.Text = "Tiêu đề:";
			label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			metroButton1.Location = new System.Drawing.Point(254, 46);
			metroButton1.Name = "metroButton1";
			metroButton1.Size = new System.Drawing.Size(93, 25);
			metroButton1.TabIndex = 82;
			metroButton1.Text = "Quản lý chủ đề";
			metroButton1.UseSelectable = true;
			metroButton1.Click += new System.EventHandler(metroButton1_Click);
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(6, 50);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(53, 16);
			label1.TabIndex = 81;
			label1.Text = "Chủ đề:";
			cbbChuDe.Cursor = System.Windows.Forms.Cursors.Hand;
			cbbChuDe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cbbChuDe.FormattingEnabled = true;
			cbbChuDe.Location = new System.Drawing.Point(77, 47);
			cbbChuDe.Name = "cbbChuDe";
			cbbChuDe.Size = new System.Drawing.Size(171, 24);
			cbbChuDe.TabIndex = 80;
			cbbChuDe.Click += new System.EventHandler(cbbChuDe_Click);
			bunifuCards2.BackColor = System.Drawing.Color.White;
			bunifuCards2.BorderRadius = 0;
			bunifuCards2.BottomSahddow = true;
			bunifuCards2.color = System.Drawing.Color.SaddleBrown;
			bunifuCards2.Controls.Add(pnlHeader);
			bunifuCards2.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards2.LeftSahddow = false;
			bunifuCards2.Location = new System.Drawing.Point(0, 0);
			bunifuCards2.Name = "bunifuCards2";
			bunifuCards2.RightSahddow = true;
			bunifuCards2.ShadowDepth = 20;
			bunifuCards2.Size = new System.Drawing.Size(370, 37);
			bunifuCards2.TabIndex = 43;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button2);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(370, 31);
			pnlHeader.TabIndex = 9;
			button2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.FlatAppearance.BorderSize = 0;
			button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button2.ForeColor = System.Drawing.Color.White;
			button2.Image = maxcare.Properties.Resources.btnMinimize_Image;
			button2.Location = new System.Drawing.Point(339, 1);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(30, 30);
			button2.TabIndex = 77;
			button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(370, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Thêm bình luận";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuCustomLabel1.Click += new System.EventHandler(BunifuCustomLabel1_Click);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { thêmMớiToolStripMenuItem, sửaToolStripMenuItem, xóaToolStripMenuItem });
			contextMenuStrip1.Name = "contextMenuStrip1";
			contextMenuStrip1.Size = new System.Drawing.Size(153, 70);
			thêmMớiToolStripMenuItem.Name = "thêmMớiToolStripMenuItem";
			thêmMớiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			thêmMớiToolStripMenuItem.Text = "Thêm chủ đề";
			sửaToolStripMenuItem.Name = "sửaToolStripMenuItem";
			sửaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			sửaToolStripMenuItem.Text = "Sửa tên chủ đề";
			xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
			xóaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			xóaToolStripMenuItem.Text = "Xóa chủ đề";
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 200;
			toolTip1.ReshowDelay = 40;
			label8.AutoSize = true;
			label8.Location = new System.Drawing.Point(74, 339);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(134, 16);
			label8.TabIndex = 121;
			label8.Text = "Spin nội dung {a|b|c}";
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(372, 411);
			base.Controls.Add(panel1);
			base.Controls.Add(bunifuCards1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fThemBaiViet";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình chung";
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dgvPic).EndInit();
			bunifuCards2.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
