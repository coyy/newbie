using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.KichBan;
using maxcare.Properties;
using MCommon;

namespace maxcare
{
	public class fHDLinkToInstagram : Form
	{
		private JSON_Settings setting = null;

		private string id_KichBan;

		private string id_TuongTac;

		private string Id_HanhDong;

		private int type;

		public static bool isSave;

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private Panel panel1;

		private TextBox txtTenHanhDong;

		private Label label1;

		private Button btnCancel;

		private Button btnAdd;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private Button button1;

		private TextBox txtPassword;

		private Label label5;

		private RadioButton rbPassTuNhap;

		private RadioButton rbPassRandom;

		private Label lblStatus;

		private CheckBox ckbFollow;

		private TextBox txtPathFileSaveAcc;

		private Panel panel3;

		private TextBox txtPathImage;

		private Label label2;

		private CheckBox ckbUpAvatar;

		private Panel panel2;

		private NumericUpDown nudSoLuongFrom;

		private NumericUpDown nudSoLuongTo;

		private Label label4;

		private Label label3;

		public fHDLinkToInstagram(string id_KichBan, int type = 0, string id_HanhDong = "")
		{
			InitializeComponent();
			ChangeLanguage();
			isSave = false;
			this.id_KichBan = id_KichBan;
			Id_HanhDong = id_HanhDong;
			this.type = type;
			if (InteractSQL.GetTuongTac("", "HDLinkToInstagram").Rows.Count == 0)
			{
				maxcare.KichBan.Connector.Instance.ExecuteNonQuery("INSERT INTO \"main\".\"Tuong_Tac\" (\"TenTuongTac\", \"MoTa\") VALUES ('HDLinkToInstagram', 'Liên kết Instagram');");
			}
			string jsonStringOrPathFile = "";
			switch (type)
			{
			case 0:
			{
				DataTable tuongTac = InteractSQL.GetTuongTac("", "HDLinkToInstagram");
				id_TuongTac = tuongTac.Rows[0]["Id_TuongTac"].ToString();
				txtTenHanhDong.Text = Language.GetValue(tuongTac.Rows[0]["MoTa"].ToString());
				break;
			}
			case 1:
			{
				DataTable hanhDongById = InteractSQL.GetHanhDongById(id_HanhDong);
				jsonStringOrPathFile = hanhDongById.Rows[0]["CauHinh"].ToString();
				btnAdd.Text = Language.GetValue("Câ\u0323p nhâ\u0323t");
				txtTenHanhDong.Text = hanhDongById.Rows[0]["TenHanhDong"].ToString();
				break;
			}
			}
			setting = new JSON_Settings(jsonStringOrPathFile, isJsonString: true);
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(label1);
			Language.GetValue(lblStatus);
			Language.GetValue(label2);
			Language.GetValue(label4);
			Language.GetValue(label3);
			Language.GetValue(btnAdd);
			Language.GetValue(btnCancel);
		}

		private void FConfigInteract_Load(object sender, EventArgs e)
		{
			try
			{
				if (setting.GetValueInt("typePass") == 0)
				{
					rbPassRandom.Checked = true;
				}
				else
				{
					rbPassTuNhap.Checked = true;
				}
				txtPassword.Text = setting.GetValue("txtPassword");
				txtPathFileSaveAcc.Text = FileHelper.GetPathToCurrentFolder() + "\\accountIG.txt";
				ckbUpAvatar.Checked = setting.GetValueBool("ckbUpAvatar");
				txtPathImage.Text = setting.GetValue("txtPathImage");
				ckbFollow.Checked = setting.GetValueBool("ckbFollow");
				nudSoLuongFrom.Value = setting.GetValueInt("nudSoLuongFrom", 1);
				nudSoLuongTo.Value = setting.GetValueInt("nudSoLuongTo", 1);
			}
			catch
			{
			}
			rbPassTuNhap_CheckedChanged(null, null);
			ckbUpAvatar_CheckedChanged(null, null);
			ckbFollow_CheckedChanged(null, null);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			string text = txtTenHanhDong.Text.Trim();
			if (text == "")
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lo\u0300ng nhâ\u0323p tên ha\u0300nh đô\u0323ng!"), 3);
				return;
			}
			JSON_Settings jSON_Settings = new JSON_Settings();
			int num = 0;
			if (rbPassTuNhap.Checked)
			{
				num = 1;
			}
			jSON_Settings.Update("typePass", num);
			jSON_Settings.Update("txtPassword", txtPassword.Text.Trim());
			jSON_Settings.Update("ckbUpAvatar", ckbUpAvatar.Checked);
			jSON_Settings.Update("txtPathImage", txtPathImage.Text.Trim());
			jSON_Settings.Update("ckbFollow", ckbFollow.Checked);
			jSON_Settings.Update("nudSoLuongFrom", nudSoLuongFrom.Value);
			jSON_Settings.Update("nudSoLuongTo", nudSoLuongTo.Value);
			string fullString = jSON_Settings.GetFullString();
			if (type == 0)
			{
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n thêm ha\u0300nh đô\u0323ng mơ\u0301i?")) == DialogResult.Yes)
				{
					if (InteractSQL.InsertHanhDong(id_KichBan, text, id_TuongTac, fullString))
					{
						isSave = true;
						Close();
					}
					else
					{
						MessageBoxHelper.ShowMessageBox(Language.GetValue("Thêm thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
					}
				}
			}
			else if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n câ\u0323p nhâ\u0323t ha\u0300nh đô\u0323ng?")) == DialogResult.Yes)
			{
				if (InteractSQL.UpdateHanhDong(Id_HanhDong, text, fullString))
				{
					isSave = true;
					Close();
				}
				else
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Câ\u0323p nhâ\u0323t thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
				}
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			if (panel1.BorderStyle == BorderStyle.FixedSingle)
			{
				int num = 1;
				int num2 = 0;
				using Pen pen = new Pen(Color.DarkViolet, 1f);
				e.Graphics.DrawRectangle(pen, new Rectangle(num2, num2, panel1.ClientSize.Width - num, panel1.ClientSize.Height - num));
			}
		}

		private void rbPassTuNhap_CheckedChanged(object sender, EventArgs e)
		{
			txtPassword.Enabled = rbPassTuNhap.Checked;
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void ckbUpAvatar_CheckedChanged(object sender, EventArgs e)
		{
			panel3.Enabled = ckbUpAvatar.Checked;
		}

		private void ckbFollow_CheckedChanged(object sender, EventArgs e)
		{
			panel2.Enabled = ckbFollow.Checked;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			button1 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			panel1 = new System.Windows.Forms.Panel();
			txtPassword = new System.Windows.Forms.TextBox();
			txtTenHanhDong = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			btnCancel = new System.Windows.Forms.Button();
			btnAdd = new System.Windows.Forms.Button();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			lblStatus = new System.Windows.Forms.Label();
			rbPassRandom = new System.Windows.Forms.RadioButton();
			rbPassTuNhap = new System.Windows.Forms.RadioButton();
			label5 = new System.Windows.Forms.Label();
			txtPathFileSaveAcc = new System.Windows.Forms.TextBox();
			ckbFollow = new System.Windows.Forms.CheckBox();
			nudSoLuongTo = new System.Windows.Forms.NumericUpDown();
			nudSoLuongFrom = new System.Windows.Forms.NumericUpDown();
			label3 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			panel2 = new System.Windows.Forms.Panel();
			ckbUpAvatar = new System.Windows.Forms.CheckBox();
			panel3 = new System.Windows.Forms.Panel();
			txtPathImage = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel1.SuspendLayout();
			bunifuCards1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudSoLuongTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongFrom).BeginInit();
			panel2.SuspendLayout();
			panel3.SuspendLayout();
			SuspendLayout();
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(402, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Cấu hình Liên kết Instagram";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = pnlHeader;
			bunifuDragControl2.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button1);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(402, 31);
			pnlHeader.TabIndex = 9;
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Image = maxcare.Properties.Resources.btnMinimize_Image;
			button1.Location = new System.Drawing.Point(371, 1);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(30, 30);
			button1.TabIndex = 77;
			button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(panel3);
			panel1.Controls.Add(ckbUpAvatar);
			panel1.Controls.Add(panel2);
			panel1.Controls.Add(ckbFollow);
			panel1.Controls.Add(label5);
			panel1.Controls.Add(rbPassTuNhap);
			panel1.Controls.Add(rbPassRandom);
			panel1.Controls.Add(txtPassword);
			panel1.Controls.Add(lblStatus);
			panel1.Controls.Add(txtPathFileSaveAcc);
			panel1.Controls.Add(txtTenHanhDong);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(btnAdd);
			panel1.Controls.Add(bunifuCards1);
			panel1.Cursor = System.Windows.Forms.Cursors.Arrow;
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(405, 268);
			panel1.TabIndex = 0;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			txtPassword.Location = new System.Drawing.Point(230, 99);
			txtPassword.Name = "txtPassword";
			txtPassword.Size = new System.Drawing.Size(146, 23);
			txtPassword.TabIndex = 38;
			txtTenHanhDong.Location = new System.Drawing.Point(145, 49);
			txtTenHanhDong.Name = "txtTenHanhDong";
			txtTenHanhDong.Size = new System.Drawing.Size(231, 23);
			txtTenHanhDong.TabIndex = 0;
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(27, 52);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(99, 16);
			label1.TabIndex = 31;
			label1.Text = "Tên ha\u0300nh đô\u0323ng:";
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(214, 227);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 10;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(btnCancel_Click);
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(107, 227);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 9;
			btnAdd.Text = "Thêm";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(btnAdd_Click);
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.DarkViolet;
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(1, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(402, 37);
			bunifuCards1.TabIndex = 28;
			lblStatus.AutoSize = true;
			lblStatus.Location = new System.Drawing.Point(28, 75);
			lblStatus.Name = "lblStatus";
			lblStatus.Size = new System.Drawing.Size(65, 16);
			lblStatus.TabIndex = 0;
			lblStatus.Text = "Mật khẩu:";
			rbPassRandom.AutoSize = true;
			rbPassRandom.Checked = true;
			rbPassRandom.Location = new System.Drawing.Point(145, 76);
			rbPassRandom.Name = "rbPassRandom";
			rbPassRandom.Size = new System.Drawing.Size(90, 20);
			rbPassRandom.TabIndex = 39;
			rbPassRandom.TabStop = true;
			rbPassRandom.Text = "Ngẫu nhiên";
			rbPassRandom.UseVisualStyleBackColor = true;
			rbPassTuNhap.AutoSize = true;
			rbPassTuNhap.Location = new System.Drawing.Point(145, 100);
			rbPassTuNhap.Name = "rbPassTuNhap";
			rbPassTuNhap.Size = new System.Drawing.Size(79, 20);
			rbPassTuNhap.TabIndex = 40;
			rbPassTuNhap.Text = "Tự nhập:";
			rbPassTuNhap.UseVisualStyleBackColor = true;
			rbPassTuNhap.CheckedChanged += new System.EventHandler(rbPassTuNhap_CheckedChanged);
			label5.AutoSize = true;
			label5.Location = new System.Drawing.Point(28, 131);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(111, 16);
			label5.TabIndex = 41;
			label5.Text = "File lưu tài khoản:";
			txtPathFileSaveAcc.Location = new System.Drawing.Point(145, 128);
			txtPathFileSaveAcc.Name = "txtPathFileSaveAcc";
			txtPathFileSaveAcc.ReadOnly = true;
			txtPathFileSaveAcc.Size = new System.Drawing.Size(231, 23);
			txtPathFileSaveAcc.TabIndex = 0;
			txtPathFileSaveAcc.TextChanged += new System.EventHandler(textBox1_TextChanged);
			ckbFollow.AutoSize = true;
			ckbFollow.Location = new System.Drawing.Point(31, 189);
			ckbFollow.Name = "ckbFollow";
			ckbFollow.Size = new System.Drawing.Size(100, 20);
			ckbFollow.TabIndex = 42;
			ckbFollow.Text = "Follow gợi ý:";
			ckbFollow.UseVisualStyleBackColor = true;
			ckbFollow.CheckedChanged += new System.EventHandler(ckbFollow_CheckedChanged);
			nudSoLuongTo.Location = new System.Drawing.Point(97, 2);
			nudSoLuongTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudSoLuongTo.Name = "nudSoLuongTo";
			nudSoLuongTo.Size = new System.Drawing.Size(56, 23);
			nudSoLuongTo.TabIndex = 44;
			nudSoLuongFrom.Location = new System.Drawing.Point(1, 2);
			nudSoLuongFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudSoLuongFrom.Name = "nudSoLuongFrom";
			nudSoLuongFrom.Size = new System.Drawing.Size(56, 23);
			nudSoLuongFrom.TabIndex = 43;
			label3.Location = new System.Drawing.Point(62, 4);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(29, 16);
			label3.TabIndex = 46;
			label3.Text = "đê\u0301n";
			label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(155, 4);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(40, 16);
			label4.TabIndex = 45;
			label4.Text = "người";
			panel2.Controls.Add(nudSoLuongFrom);
			panel2.Controls.Add(nudSoLuongTo);
			panel2.Controls.Add(label4);
			panel2.Controls.Add(label3);
			panel2.Location = new System.Drawing.Point(145, 186);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(200, 27);
			panel2.TabIndex = 47;
			ckbUpAvatar.AutoSize = true;
			ckbUpAvatar.Location = new System.Drawing.Point(31, 159);
			ckbUpAvatar.Name = "ckbUpAvatar";
			ckbUpAvatar.Size = new System.Drawing.Size(88, 20);
			ckbUpAvatar.TabIndex = 42;
			ckbUpAvatar.Text = "Up Avatar:";
			ckbUpAvatar.UseVisualStyleBackColor = true;
			ckbUpAvatar.CheckedChanged += new System.EventHandler(ckbUpAvatar_CheckedChanged);
			panel3.Controls.Add(txtPathImage);
			panel3.Controls.Add(label2);
			panel3.Location = new System.Drawing.Point(145, 156);
			panel3.Name = "panel3";
			panel3.Size = new System.Drawing.Size(231, 27);
			panel3.TabIndex = 47;
			txtPathImage.Location = new System.Drawing.Point(97, 2);
			txtPathImage.Name = "txtPathImage";
			txtPathImage.Size = new System.Drawing.Size(131, 23);
			txtPathImage.TabIndex = 0;
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(3, 5);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(89, 16);
			label2.TabIndex = 41;
			label2.Text = "Thư mục ảnh:";
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(405, 268);
			base.Controls.Add(panel1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fHDLinkToInstagram";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình tương tác";
			base.Load += new System.EventHandler(FConfigInteract_Load);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			bunifuCards1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)nudSoLuongTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudSoLuongFrom).EndInit();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			ResumeLayout(false);
		}
	}
}
