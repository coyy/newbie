using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Properties;
using MCommon;

namespace maxcare
{
	public class fDanhSachChuDe : Form
	{
		private IContainer components = null;

		private BunifuCards bunifuCards1;

		private Panel panel1;

		private BunifuDragControl bunifuDragControl1;

		private ToolTip toolTip1;

		private GroupBox groupBox2;

		public DataGridView dgvChuDe;

		private Label lblCountChuDe;

		private Label label7;

		private BunifuCards bunifuCards2;

		private Panel pnlHeader;

		private Button button2;

		private PictureBox pictureBox1;

		private Button btnMinimize;

		private BunifuCustomLabel bunifuCustomLabel1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem thêmMớiToolStripMenuItem;

		private ToolStripMenuItem sửaToolStripMenuItem;

		private ToolStripMenuItem xóaToolStripMenuItem;

		private ToolStripMenuItem tảiLạiToolStripMenuItem;

		public fDanhSachChuDe()
		{
			InitializeComponent();
			LoadcbbChuDe();
		}

		private void LoadcbbChuDe()
		{
			List<string> listChuDe = CommonSQL.GetListChuDe();
			for (int i = 0; i < listChuDe.Count; i++)
			{
				dgvChuDe.Rows.Add(i + 1, listChuDe[i]);
			}
			lblCountChuDe.Text = listChuDe.Count().ToString();
		}

		private void BtnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void metroButton1_Click(object sender, EventArgs e)
		{
		}

		private void thêmMớiToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MCommon.Common.ShowForm(new fThemChuDe());
			dgvChuDe.Rows.Clear();
			LoadcbbChuDe();
		}

		private void sửaToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string oldChude = dgvChuDe.SelectedRows[0].Cells[1].Value.ToString();
			MCommon.Common.ShowForm(new fSuaChuDe(oldChude));
			dgvChuDe.Rows.Clear();
			LoadcbbChuDe();
		}

		private void label7_Click(object sender, EventArgs e)
		{
		}

		private void lblCountChuDe_Click(object sender, EventArgs e)
		{
		}

		private void btnThem_Click(object sender, EventArgs e)
		{
		}

		private void btnSua_Click(object sender, EventArgs e)
		{
		}

		private void toolTip1_Popup(object sender, PopupEventArgs e)
		{
		}

		private void xóaToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Bạn có muốn xóa chủ đề này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				string text = dgvChuDe.SelectedRows[0].Cells[1].Value.ToString();
				CommonSQL.DeleteChuDe(text);
				CommonSQL.DeleteBaiVietByChuDe(text);
				dgvChuDe.Rows.Clear();
				LoadcbbChuDe();
			}
		}

		private void tảiLạiToolStripMenuItem_Click(object sender, EventArgs e)
		{
			dgvChuDe.Rows.Clear();
			LoadcbbChuDe();
		}

		private void dgvChuDe_Click(object sender, EventArgs e)
		{
		}

		private void dgvChuDe_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void fDanhSachChuDe_Load(object sender, EventArgs e)
		{
		}

		private void GroupBox2_Enter(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel1 = new System.Windows.Forms.Panel();
			bunifuCards2 = new Bunifu.Framework.UI.BunifuCards();
			pnlHeader = new System.Windows.Forms.Panel();
			button2 = new System.Windows.Forms.Button();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			btnMinimize = new System.Windows.Forms.Button();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			groupBox2 = new System.Windows.Forms.GroupBox();
			lblCountChuDe = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			dgvChuDe = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			thêmMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			sửaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			tảiLạiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			panel1.SuspendLayout();
			bunifuCards2.SuspendLayout();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dgvChuDe).BeginInit();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 5;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.SaddleBrown;
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, 0);
			bunifuCards1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(0, 47);
			bunifuCards1.TabIndex = 12;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(bunifuCards2);
			panel1.Controls.Add(groupBox2);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(329, 317);
			panel1.TabIndex = 37;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			bunifuCards2.BackColor = System.Drawing.Color.White;
			bunifuCards2.BorderRadius = 0;
			bunifuCards2.BottomSahddow = true;
			bunifuCards2.color = System.Drawing.Color.SaddleBrown;
			bunifuCards2.Controls.Add(pnlHeader);
			bunifuCards2.Dock = System.Windows.Forms.DockStyle.Top;
			bunifuCards2.LeftSahddow = false;
			bunifuCards2.Location = new System.Drawing.Point(0, 0);
			bunifuCards2.Name = "bunifuCards2";
			bunifuCards2.RightSahddow = true;
			bunifuCards2.ShadowDepth = 20;
			bunifuCards2.Size = new System.Drawing.Size(327, 37);
			bunifuCards2.TabIndex = 43;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(button2);
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(327, 31);
			pnlHeader.TabIndex = 9;
			button2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.FlatAppearance.BorderSize = 0;
			button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button2.ForeColor = System.Drawing.Color.White;
			button2.Image = maxcare.Properties.Resources.icons8_close_window_25px;
			button2.Location = new System.Drawing.Point(296, 1);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(30, 30);
			button2.TabIndex = 77;
			button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Location = new System.Drawing.Point(899, 1);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(30, 30);
			btnMinimize.TabIndex = 9;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(327, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Danh sách chủ đề";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			groupBox2.BackColor = System.Drawing.Color.White;
			groupBox2.Controls.Add(lblCountChuDe);
			groupBox2.Controls.Add(label7);
			groupBox2.Controls.Add(dgvChuDe);
			groupBox2.Location = new System.Drawing.Point(6, 40);
			groupBox2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox2.Name = "groupBox2";
			groupBox2.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
			groupBox2.Size = new System.Drawing.Size(311, 269);
			groupBox2.TabIndex = 41;
			groupBox2.TabStop = false;
			groupBox2.Text = "Danh sách chủ đề";
			groupBox2.Enter += new System.EventHandler(GroupBox2_Enter);
			lblCountChuDe.AutoSize = true;
			lblCountChuDe.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 163);
			lblCountChuDe.ForeColor = System.Drawing.Color.Blue;
			lblCountChuDe.Location = new System.Drawing.Point(273, 248);
			lblCountChuDe.Name = "lblCountChuDe";
			lblCountChuDe.Size = new System.Drawing.Size(16, 16);
			lblCountChuDe.TabIndex = 78;
			lblCountChuDe.Text = "0";
			lblCountChuDe.Click += new System.EventHandler(lblCountChuDe_Click);
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 163);
			label7.Location = new System.Drawing.Point(231, 248);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(44, 16);
			label7.TabIndex = 79;
			label7.Text = "Tổng:";
			label7.Click += new System.EventHandler(label7_Click);
			dgvChuDe.AllowUserToAddRows = false;
			dgvChuDe.AllowUserToDeleteRows = false;
			dgvChuDe.AllowUserToResizeRows = false;
			dgvChuDe.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.Color.Teal;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dgvChuDe.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dgvChuDe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgvChuDe.Columns.AddRange(dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn4);
			dgvChuDe.ContextMenuStrip = contextMenuStrip1;
			dgvChuDe.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dgvChuDe.Location = new System.Drawing.Point(9, 23);
			dgvChuDe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			dgvChuDe.MultiSelect = false;
			dgvChuDe.Name = "dgvChuDe";
			dgvChuDe.RowHeadersVisible = false;
			dgvChuDe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dgvChuDe.Size = new System.Drawing.Size(293, 221);
			dgvChuDe.TabIndex = 76;
			dgvChuDe.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvChuDe_CellContentClick);
			dgvChuDe.Click += new System.EventHandler(dgvChuDe_Click);
			dataGridViewTextBoxColumn1.HeaderText = "STT";
			dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			dataGridViewTextBoxColumn1.Width = 35;
			dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			dataGridViewTextBoxColumn4.HeaderText = "Tên chủ đề";
			dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { thêmMớiToolStripMenuItem, sửaToolStripMenuItem, xóaToolStripMenuItem, tảiLạiToolStripMenuItem });
			contextMenuStrip1.Name = "contextMenuStrip1";
			contextMenuStrip1.Size = new System.Drawing.Size(179, 92);
			thêmMớiToolStripMenuItem.Name = "thêmMớiToolStripMenuItem";
			thêmMớiToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
			thêmMớiToolStripMenuItem.Text = "Thêm chủ đề";
			thêmMớiToolStripMenuItem.Click += new System.EventHandler(thêmMớiToolStripMenuItem_Click);
			sửaToolStripMenuItem.Name = "sửaToolStripMenuItem";
			sửaToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
			sửaToolStripMenuItem.Text = "Sửa tên chủ đề";
			sửaToolStripMenuItem.Click += new System.EventHandler(sửaToolStripMenuItem_Click);
			xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
			xóaToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
			xóaToolStripMenuItem.Text = "Xóa chủ đề";
			xóaToolStripMenuItem.Click += new System.EventHandler(xóaToolStripMenuItem_Click);
			tảiLạiToolStripMenuItem.Name = "tảiLạiToolStripMenuItem";
			tảiLạiToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
			tảiLạiToolStripMenuItem.Text = "Làm mới danh sách";
			tảiLạiToolStripMenuItem.Click += new System.EventHandler(tảiLạiToolStripMenuItem_Click);
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 10000;
			toolTip1.InitialDelay = 200;
			toolTip1.ReshowDelay = 40;
			toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(toolTip1_Popup);
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(329, 317);
			base.Controls.Add(panel1);
			base.Controls.Add(bunifuCards1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fDanhSachChuDe";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "Cấu hình chung";
			base.Load += new System.EventHandler(fDanhSachChuDe_Load);
			panel1.ResumeLayout(false);
			bunifuCards2.ResumeLayout(false);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dgvChuDe).EndInit();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
