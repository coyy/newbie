namespace maxcare
{
	internal class BaiViet
	{
		public int id { get; set; }

		public string tenChuDe { get; set; }

		public string tieuDe { get; set; }

		public string anh { get; set; }

		public string video { get; set; }

		public string noiDung { get; set; }

		public string ngayTao { get; set; }
	}
}
