using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.Properties;
using MCommon;

namespace maxcare
{
	public class fQuanLyTinNhan : Form
	{
		private Random rd = new Random();

		private JSON_Settings settings = new JSON_Settings("configGeneral");

		private List<string> lstData = new List<string>();

		private List<Thread> lstThread = null;

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private ToolTip toolTip1;

		private Panel pnlHeader;

		private PictureBox pictureBox1;

		private Button button2;

		private Button button1;

		private Button btnMinimize;

		private BunifuCustomLabel bunifuCustomLabel1;

		private BunifuCards bunifuCards1;

		private Panel panel1;

		private TabControl tabMain;

		public DataGridView dgvTaiKhoan;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem hiểnThịToolStripMenuItem;

		private ToolStripMenuItem đóngToolStripMenuItem;

		private Panel panel2;

		private ToolStripMenuItem sửaGhiChúToolStripMenuItem;

		private DataGridViewTextBoxColumn cStt;

		private DataGridViewImageColumn cAvatar;

		private DataGridViewTextBoxColumn cTaiKhoan;

		private DataGridViewTextBoxColumn cUid;

		private DataGridViewTextBoxColumn cPassword;

		private DataGridViewTextBoxColumn cFa2;

		private DataGridViewTextBoxColumn cCookies;

		private DataGridViewTextBoxColumn cProxy;

		private DataGridViewTextBoxColumn cGhiChu;

		private DataGridViewTextBoxColumn cId;

		[DllImport("user32.dll", SetLastError = true)]
		public static extern long SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool MoveWindow(IntPtr hwnd, int x, int y, int cx, int cy, bool repaint);

		public fQuanLyTinNhan(List<string> lstData)
		{
			InitializeComponent();
			MCommon.Common.CreateFolder("avatar");
			this.lstData = lstData;
			base.Width = Screen.PrimaryScreen.WorkingArea.Width;
			base.Height = Screen.PrimaryScreen.WorkingArea.Height;
		}

		public int CountChooseRowInDatagridview()
		{
			int result = 0;
			try
			{
				result = dgvTaiKhoan.SelectedRows.Count;
			}
			catch
			{
			}
			return result;
		}

		public void BtnMinimize_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			if (base.Width == Screen.PrimaryScreen.WorkingArea.Width && base.Height == Screen.PrimaryScreen.WorkingArea.Height)
			{
				base.Width = Base.width;
				base.Height = Base.heigh;
				base.Top = Base.top;
				base.Left = Base.left;
			}
			else
			{
				Base.top = base.Top;
				Base.left = base.Left;
				base.Top = 0;
				base.Left = 0;
				base.Width = Screen.PrimaryScreen.WorkingArea.Width;
				base.Height = Screen.PrimaryScreen.WorkingArea.Height;
			}
		}

		public void SetCellAccount(int indexRow, string column, object value, bool isAllowEmptyValue = true)
		{
			if (isAllowEmptyValue || !(value.ToString().Trim() == ""))
			{
				DatagridviewHelper.SetStatusDataGridView(dgvTaiKhoan, indexRow, column, value);
			}
		}

		public string GetCellAccount(int indexRow, string column)
		{
			return DatagridviewHelper.GetStatusDataGridView(dgvTaiKhoan, indexRow, column);
		}

		private void Button2_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		private void AddDataIntoDgv()
		{
			for (int i = 0; i < lstData.Count; i++)
			{
				string[] array = lstData[i].Split('|');
				dgvTaiKhoan.Rows.Add(dgvTaiKhoan.RowCount + 1, Image.FromFile("images\\no_avatar.png"), array[0] + "\r\n" + array[5], array[0], array[1], array[2], array[3], array[4], array[6], array[7]);
			}
		}

		private void fQuanLyTinNhan_Load(object sender, EventArgs e)
		{
			AddDataIntoDgv();
		}

		private void dgvTaiKhoan_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void AddChromeIntoControl(Chrome chrome, Control control)
		{
			Invoke((MethodInvoker)delegate
			{
				SetParent(chrome.process.MainWindowHandle, control.Handle);
				MoveWindow(chrome.process.MainWindowHandle, -10, 0, control.Size.Width + 20, control.Size.Height + 20, repaint: false);
			});
		}

		public int ShowChrome(int indexRow, string uid, string pass, string pass2fa, TabPage tabPage1, string cookie = "", string proxy = "")
		{
			int result = 0;
			int num = 0;
			try
			{
				string text = uid;
				if (uid == "")
				{
					uid = Regex.Match(cookie + ";", "c_user=(.*?);").Groups[1].Value;
				}
				Chrome chrome = null;
				bool flag = false;
				string text2 = "";
				if (uid != "")
				{
					text2 = settings.GetValue("txbPathProfile") + "\\" + uid;
					if (!Directory.Exists(text2))
					{
						text2 = "";
					}
				}
				chrome = new Chrome
				{
					DisableImage = false,
					Size = new Point(300, 500),
					Position = new Point(0, -1000),
					TimeWaitForSearchingElement = 3,
					TimeWaitForLoadingPage = 60,
					ProfilePath = text2,
					UserAgent = Base.useragentDefault
				};
				if (proxy != "")
				{
					int typeProxy = 0;
					if (proxy.EndsWith("*1"))
					{
						typeProxy = 1;
					}
					if (proxy.EndsWith("*0") || proxy.EndsWith("*1"))
					{
						proxy = proxy.Substring(0, proxy.Length - 2);
					}
					chrome.Proxy = proxy;
					chrome.TypeProxy = typeProxy;
				}
				while (chrome.Open())
				{
					chrome.ExecuteScript("document.title=\"proxyauth=" + proxy + "\"");
					chrome.DelayTime(2.0);
					if (!settings.GetValueBool("ckbKhongCheckIP") && proxy.Split(':').Length > 1)
					{
						chrome.GotoURL("https://api.myip.com/");
						chrome.DelayTime(1.0);
						string pageSource = chrome.GetPageSource();
						if (!pageSource.Contains("ip"))
						{
							chrome.Close();
							num++;
							if (num >= 3)
							{
								break;
							}
							continue;
						}
					}
					chrome.GetProcess();
					AddChromeIntoControl(chrome, tabPage1);
					if (!(flag = CommonChrome.CheckLiveCookie(chrome, "https://m.facebook.com/") == 1))
					{
						if (text != "" && pass != "")
						{
							flag = CommonChrome.LoginFacebookUsingUidPassNew(chrome, text, pass, pass2fa, "https://m.facebook.com/", 2) == "1";
						}
						else if (cookie != "")
						{
							flag = CommonChrome.LoginFacebookUsingCookie(chrome, cookie, "https://m.facebook.com/") == "1";
						}
					}
					if (!flag)
					{
						SetRowColor(indexRow, 1);
						string idTap = dgvTaiKhoan.Rows[indexRow].Cells[3].Value.ToString();
						tabMain.Invoke((MethodInvoker)delegate
						{
							tabMain.TabPages.Remove(tabMain.TabPages[idTap]);
						});
						break;
					}
					SetRowColor(indexRow, 2);
					chrome.GotoURL("https://m.facebook.com/messages/t/");
					CommonRequest.DownLoadImageByUid(uid, "avatar");
					if (File.Exists("avatar\\" + uid + ".png"))
					{
						dgvTaiKhoan.Rows[indexRow].Cells[1].Value = Image.FromFile("avatar\\" + uid + ".png");
					}
					break;
				}
			}
			catch (Exception)
			{
			}
			return result;
		}

		private void SetRowColor(int indexRow, int typeColor)
		{
			switch (typeColor)
			{
			case 1:
				dgvTaiKhoan.Rows[indexRow].DefaultCellStyle.BackColor = Color.FromArgb(255, 182, 193);
				break;
			case 2:
				dgvTaiKhoan.Rows[indexRow].DefaultCellStyle.BackColor = Color.FromArgb(212, 237, 182);
				break;
			case 3:
				dgvTaiKhoan.Rows[indexRow].DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 255);
				break;
			}
		}

		private void DownloadImage(string url, string filePath)
		{
			try
			{
				using WebClient webClient = new WebClient();
				byte[] buffer = webClient.DownloadData(url);
				using MemoryStream stream = new MemoryStream(buffer);
				using Image image = Image.FromStream(stream);
				try
				{
					image.Save(filePath + ".png", ImageFormat.Png);
				}
				catch
				{
					image.Save(filePath + ".jpg", ImageFormat.Jpeg);
				}
			}
			catch
			{
			}
		}

		private void hiểnThịToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				lstThread = new List<Thread>();
				List<int> lstRow = new List<int>();
				foreach (DataGridViewRow selectedRow in dgvTaiKhoan.SelectedRows)
				{
					lstRow.Add(selectedRow.Index);
				}
				int maxThread = lstRow.Count;
				new Thread((ThreadStart)delegate
				{
					try
					{
						int num = 0;
						while (num < lstRow.Count && lstThread.Count < maxThread)
						{
							int row = lstRow[num++];
							if (row != 0)
							{
								Thread.Sleep(rd.Next(settings.GetValueInt("nudDelayOpenChromeFrom"), settings.GetValueInt("nudDelayOpenChromeTo") + 1) * 1000);
							}
							Thread thread = new Thread((ThreadStart)delegate
							{
								try
								{
									MoTrinhDuyetOneThread(row);
								}
								catch (Exception ex3)
								{
									MCommon.Common.ExportError(null, ex3);
								}
							})
							{
								Name = row.ToString()
							};
							lstThread.Add(thread);
							MCommon.Common.DelayTime(1.0);
							thread.Start();
						}
						for (int i = 0; i < lstThread.Count; i++)
						{
							lstThread[i].Join();
						}
					}
					catch (Exception ex2)
					{
						MCommon.Common.ExportError(null, ex2);
					}
				}).Start();
			}
			catch (Exception ex)
			{
				MCommon.Common.ExportError(null, ex);
			}
		}

		private void MoTrinhDuyetOneThread(int index)
		{
			int num = 0;
			string cookie = dgvTaiKhoan.Rows[index].Cells[6].Value.ToString();
			string text = dgvTaiKhoan.Rows[index].Cells[3].Value.ToString();
			string pass = dgvTaiKhoan.Rows[index].Cells[4].Value.ToString();
			string pass2fa = dgvTaiKhoan.Rows[index].Cells[5].Value.ToString();
			string proxy = dgvTaiKhoan.Rows[index].Cells[7].Value.ToString();
			TabPage tabPage1 = new TabPage();
			tabPage1.Name = text;
			tabPage1.Text = text;
			tabPage1.BackColor = Color.White;
			tabPage1.ForeColor = Color.White;
			for (int i = 0; i < tabMain.TabPages.Count; i++)
			{
				if (tabMain.TabPages[i].Name.ToString() == tabPage1.Name)
				{
					num++;
					break;
				}
			}
			if (num == 0)
			{
				tabMain.Invoke((MethodInvoker)delegate
				{
					tabMain.ItemSize = new Size(0, 1);
					tabMain.TabPages.Add(tabPage1);
				});
				ShowChrome(index, text, pass, pass2fa, tabPage1, cookie, proxy);
			}
		}

		private void đóngToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string idTap = "";
				for (int i = 0; i < dgvTaiKhoan.SelectedRows.Count; i++)
				{
					idTap = dgvTaiKhoan.SelectedRows[i].Cells[3].Value.ToString();
					if (tabMain.TabPages.Contains(tabMain.TabPages[idTap]))
					{
						tabMain.Invoke((MethodInvoker)delegate
						{
							tabMain.TabPages.Remove(tabMain.TabPages[idTap]);
						});
						SetRowColor(dgvTaiKhoan.SelectedRows[i].Index, 3);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private void dgvTaiKhoan_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			string text = dgvTaiKhoan.SelectedRows[0].Cells[3].Value.ToString();
			int num = 0;
			while (true)
			{
				if (num < tabMain.TabPages.Count)
				{
					if (tabMain.TabPages[num].Name.ToString() == text)
					{
						break;
					}
					num++;
					continue;
				}
				return;
			}
			tabMain.SelectedTab = tabMain.TabPages[text];
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		private void sửaGhiChúToolStripMenuItem_Click(object sender, EventArgs e)
		{
			OpenFormUpdate("Notes");
		}

		private void OpenFormUpdate(string type)
		{
			try
			{
				List<string> list = new List<string>();
				for (int i = 0; i < dgvTaiKhoan.SelectedRows.Count; i++)
				{
					list.Add(GetCellAccount(dgvTaiKhoan.SelectedRows[i].Index, "cId"));
				}
				if (list.Count == 0)
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lo\u0300ng cho\u0323n ta\u0300i khoa\u0309n câ\u0300n câ\u0323p nhâ\u0323t!"), 3);
				}
				else
				{
					MCommon.Common.ShowForm(new fUpdateData2(this, type));
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			btnMinimize = new System.Windows.Forms.Button();
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel1 = new System.Windows.Forms.Panel();
			panel2 = new System.Windows.Forms.Panel();
			tabMain = new System.Windows.Forms.TabControl();
			dgvTaiKhoan = new System.Windows.Forms.DataGridView();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			hiểnThịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			đóngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			sửaGhiChúToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			cId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cProxy = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cCookies = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cFa2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cUid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cTaiKhoan = new System.Windows.Forms.DataGridViewTextBoxColumn();
			cAvatar = new System.Windows.Forms.DataGridViewImageColumn();
			cStt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			bunifuCards1.SuspendLayout();
			panel1.SuspendLayout();
			panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dgvTaiKhoan).BeginInit();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = pnlHeader;
			bunifuDragControl1.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(button2);
			pnlHeader.Controls.Add(button1);
			pnlHeader.Controls.Add(btnMinimize);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 5);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(1080, 29);
			pnlHeader.TabIndex = 0;
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
			pictureBox1.Image = maxcare.Properties.Resources.icon_64;
			pictureBox1.Location = new System.Drawing.Point(6, 1);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 12;
			pictureBox1.TabStop = false;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.Dock = System.Windows.Forms.DockStyle.Right;
			button2.FlatAppearance.BorderSize = 0;
			button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button2.ForeColor = System.Drawing.Color.White;
			button2.Image = maxcare.Properties.Resources.button2_Image;
			button2.Location = new System.Drawing.Point(984, 0);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(32, 29);
			button2.TabIndex = 0;
			button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(Button2_Click);
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Dock = System.Windows.Forms.DockStyle.Right;
			button1.Enabled = false;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Image = maxcare.Properties.Resources.button1_Image;
			button1.Location = new System.Drawing.Point(1016, 0);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(32, 29);
			button1.TabIndex = 1;
			button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(Button1_Click);
			btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			btnMinimize.Dock = System.Windows.Forms.DockStyle.Right;
			btnMinimize.FlatAppearance.BorderSize = 0;
			btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			btnMinimize.ForeColor = System.Drawing.Color.White;
			btnMinimize.Image = maxcare.Properties.Resources.btnMinimize_Image;
			btnMinimize.Location = new System.Drawing.Point(1048, 0);
			btnMinimize.Name = "btnMinimize";
			btnMinimize.Size = new System.Drawing.Size(32, 29);
			btnMinimize.TabIndex = 2;
			btnMinimize.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			btnMinimize.UseVisualStyleBackColor = true;
			btnMinimize.Click += new System.EventHandler(BtnMinimize_Click);
			bunifuCustomLabel1.AutoSize = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(43, 6);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(178, 16);
			bunifuCustomLabel1.TabIndex = 3;
			bunifuCustomLabel1.Text = "Quản lý tin nhắn hàng loạt";
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = bunifuCustomLabel1;
			bunifuDragControl2.Vertical = true;
			toolTip1.AutomaticDelay = 0;
			toolTip1.AutoPopDelay = 30000;
			toolTip1.InitialDelay = 0;
			toolTip1.ReshowDelay = 40;
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.RoyalBlue;
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(0, -1);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(1081, 38);
			bunifuCards1.TabIndex = 0;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(panel2);
			panel1.Controls.Add(dgvTaiKhoan);
			panel1.Controls.Add(bunifuCards1);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(1082, 565);
			panel1.TabIndex = 8;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			panel2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel2.Controls.Add(tabMain);
			panel2.Location = new System.Drawing.Point(7, 39);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(693, 519);
			panel2.TabIndex = 8;
			tabMain.Alignment = System.Windows.Forms.TabAlignment.Bottom;
			tabMain.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			tabMain.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			tabMain.Location = new System.Drawing.Point(0, 0);
			tabMain.Multiline = true;
			tabMain.Name = "tabMain";
			tabMain.SelectedIndex = 0;
			tabMain.Size = new System.Drawing.Size(693, 518);
			tabMain.TabIndex = 7;
			dgvTaiKhoan.AllowUserToAddRows = false;
			dgvTaiKhoan.AllowUserToDeleteRows = false;
			dgvTaiKhoan.AllowUserToResizeColumns = false;
			dgvTaiKhoan.AllowUserToResizeRows = false;
			dgvTaiKhoan.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
			dgvTaiKhoan.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dgvTaiKhoan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dgvTaiKhoan.Columns.AddRange(cStt, cAvatar, cTaiKhoan, cUid, cPassword, cFa2, cCookies, cProxy, cGhiChu, cId);
			dgvTaiKhoan.ContextMenuStrip = contextMenuStrip1;
			dgvTaiKhoan.Cursor = System.Windows.Forms.Cursors.Hand;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dgvTaiKhoan.DefaultCellStyle = dataGridViewCellStyle2;
			dgvTaiKhoan.Location = new System.Drawing.Point(706, 39);
			dgvTaiKhoan.Name = "dgvTaiKhoan";
			dgvTaiKhoan.ReadOnly = true;
			dgvTaiKhoan.RowHeadersVisible = false;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dgvTaiKhoan.RowsDefaultCellStyle = dataGridViewCellStyle3;
			dgvTaiKhoan.RowTemplate.Height = 50;
			dgvTaiKhoan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			dgvTaiKhoan.Size = new System.Drawing.Size(369, 519);
			dgvTaiKhoan.TabIndex = 6;
			dgvTaiKhoan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvTaiKhoan_CellClick);
			dgvTaiKhoan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dgvTaiKhoan_CellContentClick);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { hiểnThịToolStripMenuItem, đóngToolStripMenuItem, sửaGhiChúToolStripMenuItem });
			contextMenuStrip1.Name = "contextMenuStrip1";
			contextMenuStrip1.Size = new System.Drawing.Size(165, 70);
			hiểnThịToolStripMenuItem.Image = maxcare.Properties.Resources.icons8_play_21px1;
			hiểnThịToolStripMenuItem.Name = "hiểnThịToolStripMenuItem";
			hiểnThịToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
			hiểnThịToolStripMenuItem.Text = "Mở trình duyệt";
			hiểnThịToolStripMenuItem.Click += new System.EventHandler(hiểnThịToolStripMenuItem_Click);
			đóngToolStripMenuItem.Image = maxcare.Properties.Resources.icons8_stop_21px;
			đóngToolStripMenuItem.Name = "đóngToolStripMenuItem";
			đóngToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
			đóngToolStripMenuItem.Text = "Đóng trình duyệt";
			đóngToolStripMenuItem.Click += new System.EventHandler(đóngToolStripMenuItem_Click);
			sửaGhiChúToolStripMenuItem.Image = maxcare.Properties.Resources.icons8_create_1;
			sửaGhiChúToolStripMenuItem.Name = "sửaGhiChúToolStripMenuItem";
			sửaGhiChúToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
			sửaGhiChúToolStripMenuItem.Text = "Sửa ghi chú";
			sửaGhiChúToolStripMenuItem.Click += new System.EventHandler(sửaGhiChúToolStripMenuItem_Click);
			cId.HeaderText = "Id";
			cId.Name = "cId";
			cId.ReadOnly = true;
			cId.Visible = false;
			cGhiChu.HeaderText = "Ghi chú";
			cGhiChu.Name = "cGhiChu";
			cGhiChu.ReadOnly = true;
			cProxy.HeaderText = "Proxy";
			cProxy.Name = "cProxy";
			cProxy.ReadOnly = true;
			cProxy.Visible = false;
			cCookies.HeaderText = "Cookie";
			cCookies.Name = "cCookies";
			cCookies.ReadOnly = true;
			cCookies.Visible = false;
			cFa2.HeaderText = "2fa";
			cFa2.Name = "cFa2";
			cFa2.ReadOnly = true;
			cFa2.Visible = false;
			cPassword.HeaderText = "Password";
			cPassword.Name = "cPassword";
			cPassword.ReadOnly = true;
			cPassword.Visible = false;
			cUid.HeaderText = "Uid";
			cUid.Name = "cUid";
			cUid.ReadOnly = true;
			cUid.Visible = false;
			cTaiKhoan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			cTaiKhoan.DefaultCellStyle = dataGridViewCellStyle4;
			cTaiKhoan.HeaderText = "Tài khoản";
			cTaiKhoan.Name = "cTaiKhoan";
			cTaiKhoan.ReadOnly = true;
			cTaiKhoan.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			cTaiKhoan.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cAvatar.FillWeight = 50f;
			cAvatar.HeaderText = "Avatar";
			cAvatar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
			cAvatar.Name = "cAvatar";
			cAvatar.ReadOnly = true;
			cAvatar.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			cAvatar.Width = 70;
			cStt.HeaderText = "STT";
			cStt.Name = "cStt";
			cStt.ReadOnly = true;
			cStt.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			cStt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			cStt.Width = 40;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			base.ClientSize = new System.Drawing.Size(1082, 565);
			base.Controls.Add(panel1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "fQuanLyTinNhan";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Quản lý tin nhắn";
			base.Load += new System.EventHandler(fQuanLyTinNhan_Load);
			pnlHeader.ResumeLayout(false);
			pnlHeader.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			bunifuCards1.ResumeLayout(false);
			panel1.ResumeLayout(false);
			panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dgvTaiKhoan).EndInit();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
