using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using maxcare.Helper;
using maxcare.KichBan;
using MCommon;
using MetroFramework.Controls;

namespace maxcare
{
	public class fHDDangBaiTheoID : Form
	{
		private JSON_Settings setting;

		private string id_KichBan;

		private string id_TuongTac;

		private string Id_HanhDong;

		private int type;

		public static bool isSave;

		private List<string> lstNhomTuNhap = new List<string>();

		private IContainer components = null;

		private BunifuDragControl bunifuDragControl1;

		private BunifuDragControl bunifuDragControl2;

		private Panel panel1;

		private TextBox txtTenHanhDong;

		private Label label1;

		private Button btnCancel;

		private Button btnAdd;

		private BunifuCards bunifuCards1;

		private Panel pnlHeader;

		private Button button1;

		private PictureBox pictureBox1;

		private BunifuCustomLabel bunifuCustomLabel1;

		private NumericUpDown nudDelayTo;

		private NumericUpDown nudDelayFrom;

		private Label label20;

		private Label label19;

		private Label label15;

		private GroupBox groupBox2;

		private Panel plDangBaiLenPage;

		private Label label21;

		private Label label22;

		private NumericUpDown nudCountPageTo;

		private Label label23;

		private NumericUpDown nudCountPageFrom;

		private Panel plDangBaiLenNhom;

		private NumericUpDown nudCountGroupTo;

		private NumericUpDown nudCountGroupFrom;

		private Label label24;

		private Label label25;

		private Label label26;

		private CheckBox ckbDangBaiLenNhom;

		private CheckBox ckbDangBaiLenTuong;

		private CheckBox ckbOnlyDangNhomKhongKiemDuyet;

		private CheckBox ckbDelete;

		private Label label2;

		private TextBox txtIdPost;

		private CheckBox ckbDangBaiLenPage;

		private Panel panel4;

		private MetroButton btnNhapNhom;

		private RadioButton rbNhomTuNhap;

		private RadioButton rbNgauNhienNhomThamGia;

		private Label label27;

		public fHDDangBaiTheoID(string id_KichBan, int type = 0, string id_HanhDong = "")
		{
			InitializeComponent();
			ChangeLanguage();
			isSave = false;
			this.id_KichBan = id_KichBan;
			Id_HanhDong = id_HanhDong;
			this.type = type;
			string text = base.Name.Substring(1);
			if (InteractSQL.GetTuongTac("", text).Rows.Count == 0)
			{
				maxcare.KichBan.Connector.Instance.ExecuteNonQuery("INSERT INTO \"main\".\"Tuong_Tac\" (\"TenTuongTac\",\"MoTa\") VALUES ('" + text + "', 'Đăng bài clone ID');");
			}
			string jsonStringOrPathFile = "";
			switch (type)
			{
			case 0:
			{
				DataTable tuongTac = InteractSQL.GetTuongTac("", text);
				jsonStringOrPathFile = tuongTac.Rows[0]["CauHinh"].ToString();
				id_TuongTac = tuongTac.Rows[0]["Id_TuongTac"].ToString();
				txtTenHanhDong.Text = Language.GetValue(tuongTac.Rows[0]["MoTa"].ToString());
				break;
			}
			case 1:
			{
				DataTable hanhDongById = InteractSQL.GetHanhDongById(id_HanhDong);
				jsonStringOrPathFile = hanhDongById.Rows[0]["CauHinh"].ToString();
				btnAdd.Text = Language.GetValue("Câ\u0323p nhâ\u0323t");
				txtTenHanhDong.Text = hanhDongById.Rows[0]["TenHanhDong"].ToString();
				break;
			}
			}
			setting = new JSON_Settings(jsonStringOrPathFile, isJsonString: true);
		}

		private void ChangeLanguage()
		{
			Language.GetValue(bunifuCustomLabel1);
			Language.GetValue(label1);
			Language.GetValue(label15);
			Language.GetValue(label20);
			Language.GetValue(label19);
			Language.GetValue(groupBox2);
			Language.GetValue(ckbDangBaiLenTuong);
			Language.GetValue(ckbDangBaiLenNhom);
			Language.GetValue(label26);
			Language.GetValue(label24);
			Language.GetValue(label25);
			Language.GetValue(ckbOnlyDangNhomKhongKiemDuyet);
			Language.GetValue(ckbDangBaiLenPage);
			Language.GetValue(label21);
			Language.GetValue(label23);
			Language.GetValue(label22);
			Language.GetValue(btnAdd);
			Language.GetValue(btnCancel);
		}

		private void FConfigInteract_Load(object sender, EventArgs e)
		{
			try
			{
				nudDelayFrom.Value = setting.GetValueInt("nudDelayFrom", 3);
				nudDelayTo.Value = setting.GetValueInt("nudDelayTo", 5);
				ckbDangBaiLenTuong.Checked = setting.GetValueBool("ckbDangBaiLenTuong");
				ckbDangBaiLenNhom.Checked = setting.GetValueBool("ckbDangBaiLenNhom");
				if (setting.GetValueInt("typePost") == 0)
				{
					rbNgauNhienNhomThamGia.Checked = true;
				}
				else
				{
					rbNhomTuNhap.Checked = true;
				}
				lstNhomTuNhap = setting.GetValueList("lstNhomTuNhap");
				ckbOnlyDangNhomKhongKiemDuyet.Checked = setting.GetValueBool("ckbOnlyDangNhomKhongKiemDuyet");
				nudCountGroupFrom.Value = setting.GetValueInt("nudCountGroupFrom", 1);
				nudCountGroupTo.Value = setting.GetValueInt("nudCountGroupTo", 1);
				ckbDangBaiLenPage.Checked = setting.GetValueBool("ckbDangBaiLenPage");
				nudCountPageFrom.Value = setting.GetValueInt("nudCountPageFrom", 1);
				nudCountPageTo.Value = setting.GetValueInt("nudCountPageTo", 1);
				txtIdPost.Text = setting.GetValue("txtIdPost");
				ckbDelete.Checked = setting.GetValueBool("ckbDelete");
			}
			catch (Exception)
			{
			}
			CheckedChangeFull();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			string text = txtTenHanhDong.Text.Trim();
			if (text == "")
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lo\u0300ng nhâ\u0323p tên ha\u0300nh đô\u0323ng!"), 3);
				return;
			}
			if (txtIdPost.Text == "")
			{
				MessageBoxHelper.ShowMessageBox(Language.GetValue("Vui lo\u0300ng nhâ\u0323p id post cần clone!"), 3);
				return;
			}
			JSON_Settings jSON_Settings = new JSON_Settings();
			jSON_Settings.Update("nudDelayFrom", nudDelayFrom.Value);
			jSON_Settings.Update("nudDelayTo", nudDelayTo.Value);
			jSON_Settings.Update("ckbDangBaiLenTuong", ckbDangBaiLenTuong.Checked);
			jSON_Settings.Update("ckbDangBaiLenNhom", ckbDangBaiLenNhom.Checked);
			int num = 0;
			if (rbNhomTuNhap.Checked)
			{
				num = 1;
			}
			jSON_Settings.Update("typePost", num);
			jSON_Settings.Update("lstNhomTuNhap", lstNhomTuNhap);
			jSON_Settings.Update("ckbOnlyDangNhomKhongKiemDuyet", ckbOnlyDangNhomKhongKiemDuyet.Checked);
			jSON_Settings.Update("nudCountGroupFrom", nudCountGroupFrom.Value);
			jSON_Settings.Update("nudCountGroupTo", nudCountGroupTo.Value);
			jSON_Settings.Update("ckbDangBaiLenPage", ckbDangBaiLenPage.Checked);
			jSON_Settings.Update("nudCountPageFrom", nudCountPageFrom.Value);
			jSON_Settings.Update("nudCountPageTo", nudCountPageTo.Value);
			jSON_Settings.Update("txtIdPost", txtIdPost.Text.Trim());
			jSON_Settings.Update("ckbDelete", ckbDelete.Checked);
			string fullString = jSON_Settings.GetFullString();
			if (type == 0)
			{
				if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n thêm ha\u0300nh đô\u0323ng mơ\u0301i?")) == DialogResult.Yes)
				{
					if (InteractSQL.InsertHanhDong(id_KichBan, text, id_TuongTac, fullString))
					{
						isSave = true;
						Close();
					}
					else
					{
						MessageBoxHelper.ShowMessageBox(Language.GetValue("Thêm thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
					}
				}
			}
			else if (MessageBoxHelper.ShowMessageBoxWithQuestion(Language.GetValue("Ba\u0323n co\u0301 muô\u0301n câ\u0323p nhâ\u0323t ha\u0300nh đô\u0323ng?")) == DialogResult.Yes)
			{
				if (InteractSQL.UpdateHanhDong(Id_HanhDong, text, fullString))
				{
					isSave = true;
					Close();
				}
				else
				{
					MessageBoxHelper.ShowMessageBox(Language.GetValue("Câ\u0323p nhâ\u0323t thâ\u0301t ba\u0323i, vui lo\u0300ng thư\u0309 la\u0323i sau!"), 2);
				}
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			if (panel1.BorderStyle == BorderStyle.FixedSingle)
			{
				int num = 1;
				int num2 = 0;
				using Pen pen = new Pen(Color.DarkViolet, 1f);
				e.Graphics.DrawRectangle(pen, new Rectangle(num2, num2, panel1.ClientSize.Width - num, panel1.ClientSize.Height - num));
			}
		}

		private void CheckedChangeFull()
		{
			ckbDangBaiLenNhom_CheckedChanged(null, null);
			ckbDangBaiLenPage_CheckedChanged(null, null);
			rbNhomTuNhap_CheckedChanged(null, null);
		}

		private void ckbDangBaiLenNhom_CheckedChanged(object sender, EventArgs e)
		{
			plDangBaiLenNhom.Enabled = ckbDangBaiLenNhom.Checked;
		}

		private void ckbDangBaiLenPage_CheckedChanged(object sender, EventArgs e)
		{
			plDangBaiLenPage.Enabled = ckbDangBaiLenPage.Checked;
		}

		private void btnNhapNhom_Click(object sender, EventArgs e)
		{
			string text = Guid.NewGuid().ToString() + ".txt";
			MCommon.Common.ShowForm(new fNhapDuLieu1(text, "Nhâ\u0323p danh sa\u0301ch ID nho\u0301m", "Danh sa\u0301ch ID nho\u0301m", "(Mô\u0303i nô\u0323i dung 1 do\u0300ng)", lstNhomTuNhap));
			lstNhomTuNhap = File.ReadAllLines(text).ToList();
			try
			{
				File.Delete(text);
			}
			catch
			{
			}
		}

		private void rbNhomTuNhap_CheckedChanged(object sender, EventArgs e)
		{
			btnNhapNhom.Enabled = rbNhomTuNhap.Checked;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maxcare.fHDDangBaiTheoID));
			bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(components);
			bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
			bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(components);
			pnlHeader = new System.Windows.Forms.Panel();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			button1 = new System.Windows.Forms.Button();
			panel1 = new System.Windows.Forms.Panel();
			ckbDelete = new System.Windows.Forms.CheckBox();
			label2 = new System.Windows.Forms.Label();
			txtIdPost = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			plDangBaiLenPage = new System.Windows.Forms.Panel();
			label21 = new System.Windows.Forms.Label();
			label22 = new System.Windows.Forms.Label();
			nudCountPageTo = new System.Windows.Forms.NumericUpDown();
			label23 = new System.Windows.Forms.Label();
			nudCountPageFrom = new System.Windows.Forms.NumericUpDown();
			plDangBaiLenNhom = new System.Windows.Forms.Panel();
			ckbOnlyDangNhomKhongKiemDuyet = new System.Windows.Forms.CheckBox();
			nudCountGroupTo = new System.Windows.Forms.NumericUpDown();
			nudCountGroupFrom = new System.Windows.Forms.NumericUpDown();
			label24 = new System.Windows.Forms.Label();
			label25 = new System.Windows.Forms.Label();
			label26 = new System.Windows.Forms.Label();
			ckbDangBaiLenPage = new System.Windows.Forms.CheckBox();
			ckbDangBaiLenNhom = new System.Windows.Forms.CheckBox();
			ckbDangBaiLenTuong = new System.Windows.Forms.CheckBox();
			nudDelayTo = new System.Windows.Forms.NumericUpDown();
			nudDelayFrom = new System.Windows.Forms.NumericUpDown();
			label20 = new System.Windows.Forms.Label();
			label19 = new System.Windows.Forms.Label();
			label15 = new System.Windows.Forms.Label();
			btnAdd = new System.Windows.Forms.Button();
			txtTenHanhDong = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			btnCancel = new System.Windows.Forms.Button();
			bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
			panel4 = new System.Windows.Forms.Panel();
			btnNhapNhom = new MetroFramework.Controls.MetroButton();
			rbNhomTuNhap = new System.Windows.Forms.RadioButton();
			rbNgauNhienNhomThamGia = new System.Windows.Forms.RadioButton();
			label27 = new System.Windows.Forms.Label();
			pnlHeader.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel1.SuspendLayout();
			groupBox2.SuspendLayout();
			plDangBaiLenPage.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudCountPageTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudCountPageFrom).BeginInit();
			plDangBaiLenNhom.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nudCountGroupTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudCountGroupFrom).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayTo).BeginInit();
			((System.ComponentModel.ISupportInitialize)nudDelayFrom).BeginInit();
			bunifuCards1.SuspendLayout();
			panel4.SuspendLayout();
			SuspendLayout();
			bunifuDragControl1.Fixed = true;
			bunifuDragControl1.Horizontal = true;
			bunifuDragControl1.TargetControl = bunifuCustomLabel1;
			bunifuDragControl1.Vertical = true;
			bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
			bunifuCustomLabel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
			bunifuCustomLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			bunifuCustomLabel1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
			bunifuCustomLabel1.Location = new System.Drawing.Point(0, 0);
			bunifuCustomLabel1.Name = "bunifuCustomLabel1";
			bunifuCustomLabel1.Size = new System.Drawing.Size(372, 31);
			bunifuCustomLabel1.TabIndex = 12;
			bunifuCustomLabel1.Text = "Cấu hình Đăng bài theo ID";
			bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			bunifuDragControl2.Fixed = true;
			bunifuDragControl2.Horizontal = true;
			bunifuDragControl2.TargetControl = pnlHeader;
			bunifuDragControl2.Vertical = true;
			pnlHeader.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pnlHeader.BackColor = System.Drawing.Color.White;
			pnlHeader.Controls.Add(pictureBox1);
			pnlHeader.Controls.Add(bunifuCustomLabel1);
			pnlHeader.Cursor = System.Windows.Forms.Cursors.SizeAll;
			pnlHeader.Location = new System.Drawing.Point(0, 3);
			pnlHeader.Name = "pnlHeader";
			pnlHeader.Size = new System.Drawing.Size(372, 31);
			pnlHeader.TabIndex = 9;
			pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new System.Drawing.Point(3, 2);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(34, 27);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			pictureBox1.TabIndex = 76;
			pictureBox1.TabStop = false;
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			button1.ForeColor = System.Drawing.Color.White;
			button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
			button1.Location = new System.Drawing.Point(342, 5);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(30, 30);
			button1.TabIndex = 0;
			button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel1.BackColor = System.Drawing.Color.White;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(ckbDelete);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(txtIdPost);
			panel1.Controls.Add(groupBox2);
			panel1.Controls.Add(nudDelayTo);
			panel1.Controls.Add(nudDelayFrom);
			panel1.Controls.Add(label20);
			panel1.Controls.Add(label19);
			panel1.Controls.Add(label15);
			panel1.Controls.Add(btnAdd);
			panel1.Controls.Add(txtTenHanhDong);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(btnCancel);
			panel1.Controls.Add(bunifuCards1);
			panel1.Cursor = System.Windows.Forms.Cursors.Arrow;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(377, 642);
			panel1.TabIndex = 0;
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			ckbDelete.AutoSize = true;
			ckbDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDelete.Location = new System.Drawing.Point(13, 567);
			ckbDelete.Name = "ckbDelete";
			ckbDelete.Size = new System.Drawing.Size(141, 20);
			ckbDelete.TabIndex = 65;
			ckbDelete.Text = "Tự động xóa id post";
			ckbDelete.UseVisualStyleBackColor = true;
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(11, 387);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(116, 16);
			label2.TabIndex = 64;
			label2.Text = "Danh sách ID post:";
			txtIdPost.Location = new System.Drawing.Point(13, 406);
			txtIdPost.Multiline = true;
			txtIdPost.Name = "txtIdPost";
			txtIdPost.Size = new System.Drawing.Size(348, 155);
			txtIdPost.TabIndex = 63;
			groupBox2.Controls.Add(plDangBaiLenPage);
			groupBox2.Controls.Add(plDangBaiLenNhom);
			groupBox2.Controls.Add(ckbDangBaiLenPage);
			groupBox2.Controls.Add(ckbDangBaiLenNhom);
			groupBox2.Controls.Add(ckbDangBaiLenTuong);
			groupBox2.Location = new System.Drawing.Point(14, 107);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(347, 277);
			groupBox2.TabIndex = 62;
			groupBox2.TabStop = false;
			groupBox2.Text = "Tùy chọn đăng";
			plDangBaiLenPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDangBaiLenPage.Controls.Add(label21);
			plDangBaiLenPage.Controls.Add(label22);
			plDangBaiLenPage.Controls.Add(nudCountPageTo);
			plDangBaiLenPage.Controls.Add(label23);
			plDangBaiLenPage.Controls.Add(nudCountPageFrom);
			plDangBaiLenPage.Location = new System.Drawing.Point(25, 243);
			plDangBaiLenPage.Name = "plDangBaiLenPage";
			plDangBaiLenPage.Size = new System.Drawing.Size(310, 27);
			plDangBaiLenPage.TabIndex = 1;
			label21.AutoSize = true;
			label21.Location = new System.Drawing.Point(3, 3);
			label21.Name = "label21";
			label21.Size = new System.Drawing.Size(96, 16);
			label21.TabIndex = 49;
			label21.Text = "Số lượng page:";
			label22.AutoSize = true;
			label22.Location = new System.Drawing.Point(261, 3);
			label22.Name = "label22";
			label22.Size = new System.Drawing.Size(36, 16);
			label22.TabIndex = 50;
			label22.Text = "page";
			nudCountPageTo.Location = new System.Drawing.Point(205, 1);
			nudCountPageTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudCountPageTo.Name = "nudCountPageTo";
			nudCountPageTo.Size = new System.Drawing.Size(56, 23);
			nudCountPageTo.TabIndex = 48;
			label23.Location = new System.Drawing.Point(170, 3);
			label23.Name = "label23";
			label23.Size = new System.Drawing.Size(29, 16);
			label23.TabIndex = 51;
			label23.Text = "đê\u0301n";
			label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			nudCountPageFrom.Location = new System.Drawing.Point(108, 1);
			nudCountPageFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudCountPageFrom.Name = "nudCountPageFrom";
			nudCountPageFrom.Size = new System.Drawing.Size(56, 23);
			nudCountPageFrom.TabIndex = 47;
			plDangBaiLenNhom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			plDangBaiLenNhom.Controls.Add(panel4);
			plDangBaiLenNhom.Controls.Add(label27);
			plDangBaiLenNhom.Controls.Add(ckbOnlyDangNhomKhongKiemDuyet);
			plDangBaiLenNhom.Controls.Add(nudCountGroupTo);
			plDangBaiLenNhom.Controls.Add(nudCountGroupFrom);
			plDangBaiLenNhom.Controls.Add(label24);
			plDangBaiLenNhom.Controls.Add(label25);
			plDangBaiLenNhom.Controls.Add(label26);
			plDangBaiLenNhom.Location = new System.Drawing.Point(25, 80);
			plDangBaiLenNhom.Name = "plDangBaiLenNhom";
			plDangBaiLenNhom.Size = new System.Drawing.Size(310, 131);
			plDangBaiLenNhom.TabIndex = 1;
			ckbOnlyDangNhomKhongKiemDuyet.AutoSize = true;
			ckbOnlyDangNhomKhongKiemDuyet.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbOnlyDangNhomKhongKiemDuyet.Location = new System.Drawing.Point(7, 110);
			ckbOnlyDangNhomKhongKiemDuyet.Name = "ckbOnlyDangNhomKhongKiemDuyet";
			ckbOnlyDangNhomKhongKiemDuyet.Size = new System.Drawing.Size(217, 20);
			ckbOnlyDangNhomKhongKiemDuyet.TabIndex = 2;
			ckbOnlyDangNhomKhongKiemDuyet.Text = "Chỉ đăng nhóm không kiểm duyệt";
			ckbOnlyDangNhomKhongKiemDuyet.UseVisualStyleBackColor = true;
			nudCountGroupTo.Location = new System.Drawing.Point(205, 5);
			nudCountGroupTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudCountGroupTo.Name = "nudCountGroupTo";
			nudCountGroupTo.Size = new System.Drawing.Size(56, 23);
			nudCountGroupTo.TabIndex = 53;
			nudCountGroupFrom.Location = new System.Drawing.Point(108, 5);
			nudCountGroupFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudCountGroupFrom.Name = "nudCountGroupFrom";
			nudCountGroupFrom.Size = new System.Drawing.Size(56, 23);
			nudCountGroupFrom.TabIndex = 52;
			label24.Location = new System.Drawing.Point(170, 7);
			label24.Name = "label24";
			label24.Size = new System.Drawing.Size(29, 16);
			label24.TabIndex = 56;
			label24.Text = "đê\u0301n";
			label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label25.AutoSize = true;
			label25.Location = new System.Drawing.Point(261, 7);
			label25.Name = "label25";
			label25.Size = new System.Drawing.Size(40, 16);
			label25.TabIndex = 55;
			label25.Text = "nhóm";
			label26.AutoSize = true;
			label26.Location = new System.Drawing.Point(3, 7);
			label26.Name = "label26";
			label26.Size = new System.Drawing.Size(100, 16);
			label26.TabIndex = 54;
			label26.Text = "Số lượng nhóm:";
			ckbDangBaiLenPage.AutoSize = true;
			ckbDangBaiLenPage.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDangBaiLenPage.Location = new System.Drawing.Point(11, 217);
			ckbDangBaiLenPage.Name = "ckbDangBaiLenPage";
			ckbDangBaiLenPage.Size = new System.Drawing.Size(131, 20);
			ckbDangBaiLenPage.TabIndex = 0;
			ckbDangBaiLenPage.Text = "Đăng bài lên page";
			ckbDangBaiLenPage.UseVisualStyleBackColor = true;
			ckbDangBaiLenPage.CheckedChanged += new System.EventHandler(ckbDangBaiLenPage_CheckedChanged);
			ckbDangBaiLenNhom.AutoSize = true;
			ckbDangBaiLenNhom.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDangBaiLenNhom.Location = new System.Drawing.Point(11, 54);
			ckbDangBaiLenNhom.Name = "ckbDangBaiLenNhom";
			ckbDangBaiLenNhom.Size = new System.Drawing.Size(135, 20);
			ckbDangBaiLenNhom.TabIndex = 0;
			ckbDangBaiLenNhom.Text = "Đăng bài lên nhóm";
			ckbDangBaiLenNhom.UseVisualStyleBackColor = true;
			ckbDangBaiLenNhom.CheckedChanged += new System.EventHandler(ckbDangBaiLenNhom_CheckedChanged);
			ckbDangBaiLenTuong.AutoSize = true;
			ckbDangBaiLenTuong.Cursor = System.Windows.Forms.Cursors.Hand;
			ckbDangBaiLenTuong.Location = new System.Drawing.Point(11, 23);
			ckbDangBaiLenTuong.Name = "ckbDangBaiLenTuong";
			ckbDangBaiLenTuong.Size = new System.Drawing.Size(136, 20);
			ckbDangBaiLenTuong.TabIndex = 0;
			ckbDangBaiLenTuong.Text = "Đăng bài lên tường";
			ckbDangBaiLenTuong.UseVisualStyleBackColor = true;
			nudDelayTo.Location = new System.Drawing.Point(222, 79);
			nudDelayTo.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayTo.Name = "nudDelayTo";
			nudDelayTo.Size = new System.Drawing.Size(58, 23);
			nudDelayTo.TabIndex = 58;
			nudDelayFrom.Location = new System.Drawing.Point(125, 79);
			nudDelayFrom.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			nudDelayFrom.Name = "nudDelayFrom";
			nudDelayFrom.Size = new System.Drawing.Size(58, 23);
			nudDelayFrom.TabIndex = 57;
			label20.Location = new System.Drawing.Point(187, 81);
			label20.Name = "label20";
			label20.Size = new System.Drawing.Size(31, 16);
			label20.TabIndex = 61;
			label20.Text = "đê\u0301n";
			label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label19.Anchor = System.Windows.Forms.AnchorStyles.Left;
			label19.AutoSize = true;
			label19.Location = new System.Drawing.Point(286, 81);
			label19.Name = "label19";
			label19.Size = new System.Drawing.Size(31, 16);
			label19.TabIndex = 60;
			label19.Text = "giây";
			label15.AutoSize = true;
			label15.Location = new System.Drawing.Point(11, 81);
			label15.Name = "label15";
			label15.Size = new System.Drawing.Size(117, 16);
			label15.TabIndex = 59;
			label15.Text = "Khoảng cách đăng:";
			btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnAdd.BackColor = System.Drawing.Color.FromArgb(53, 120, 229);
			btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			btnAdd.FlatAppearance.BorderSize = 0;
			btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnAdd.ForeColor = System.Drawing.Color.White;
			btnAdd.Location = new System.Drawing.Point(92, 600);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new System.Drawing.Size(92, 29);
			btnAdd.TabIndex = 3;
			btnAdd.Text = "Thêm";
			btnAdd.UseVisualStyleBackColor = false;
			btnAdd.Click += new System.EventHandler(btnAdd_Click);
			txtTenHanhDong.Location = new System.Drawing.Point(125, 49);
			txtTenHanhDong.Name = "txtTenHanhDong";
			txtTenHanhDong.Size = new System.Drawing.Size(195, 23);
			txtTenHanhDong.TabIndex = 0;
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(11, 52);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(99, 16);
			label1.TabIndex = 31;
			label1.Text = "Tên ha\u0300nh đô\u0323ng:";
			btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			btnCancel.BackColor = System.Drawing.Color.Maroon;
			btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
			btnCancel.FlatAppearance.BorderSize = 0;
			btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			btnCancel.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnCancel.ForeColor = System.Drawing.Color.White;
			btnCancel.Location = new System.Drawing.Point(191, 600);
			btnCancel.Name = "btnCancel";
			btnCancel.Size = new System.Drawing.Size(92, 29);
			btnCancel.TabIndex = 4;
			btnCancel.Text = "Đóng";
			btnCancel.UseVisualStyleBackColor = false;
			btnCancel.Click += new System.EventHandler(btnCancel_Click);
			bunifuCards1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			bunifuCards1.BackColor = System.Drawing.Color.White;
			bunifuCards1.BorderRadius = 0;
			bunifuCards1.BottomSahddow = true;
			bunifuCards1.color = System.Drawing.Color.DarkViolet;
			bunifuCards1.Controls.Add(button1);
			bunifuCards1.Controls.Add(pnlHeader);
			bunifuCards1.LeftSahddow = false;
			bunifuCards1.Location = new System.Drawing.Point(1, 0);
			bunifuCards1.Name = "bunifuCards1";
			bunifuCards1.RightSahddow = true;
			bunifuCards1.ShadowDepth = 20;
			bunifuCards1.Size = new System.Drawing.Size(375, 37);
			bunifuCards1.TabIndex = 28;
			panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel4.Controls.Add(btnNhapNhom);
			panel4.Controls.Add(rbNhomTuNhap);
			panel4.Controls.Add(rbNgauNhienNhomThamGia);
			panel4.Location = new System.Drawing.Point(20, 54);
			panel4.Name = "panel4";
			panel4.Size = new System.Drawing.Size(285, 50);
			panel4.TabIndex = 57;
			btnNhapNhom.Cursor = System.Windows.Forms.Cursors.Hand;
			btnNhapNhom.Location = new System.Drawing.Point(205, 23);
			btnNhapNhom.Name = "btnNhapNhom";
			btnNhapNhom.Size = new System.Drawing.Size(75, 23);
			btnNhapNhom.TabIndex = 1;
			btnNhapNhom.Text = "Nhâ\u0323p";
			btnNhapNhom.UseSelectable = true;
			btnNhapNhom.Click += new System.EventHandler(btnNhapNhom_Click);
			rbNhomTuNhap.AutoSize = true;
			rbNhomTuNhap.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNhomTuNhap.Location = new System.Drawing.Point(4, 25);
			rbNhomTuNhap.Name = "rbNhomTuNhap";
			rbNhomTuNhap.Size = new System.Drawing.Size(177, 20);
			rbNhomTuNhap.TabIndex = 0;
			rbNhomTuNhap.Text = "Nho\u0301m do ngươ\u0300i du\u0300ng nhâ\u0323p";
			rbNhomTuNhap.UseVisualStyleBackColor = true;
			rbNhomTuNhap.CheckedChanged += new System.EventHandler(rbNhomTuNhap_CheckedChanged);
			rbNgauNhienNhomThamGia.AutoSize = true;
			rbNgauNhienNhomThamGia.Checked = true;
			rbNgauNhienNhomThamGia.Cursor = System.Windows.Forms.Cursors.Hand;
			rbNgauNhienNhomThamGia.Location = new System.Drawing.Point(4, 3);
			rbNgauNhienNhomThamGia.Name = "rbNgauNhienNhomThamGia";
			rbNgauNhienNhomThamGia.Size = new System.Drawing.Size(198, 20);
			rbNgauNhienNhomThamGia.TabIndex = 0;
			rbNgauNhienNhomThamGia.TabStop = true;
			rbNgauNhienNhomThamGia.Text = "Ngâ\u0303u nhiên nho\u0301m đa\u0303 tham gia";
			rbNgauNhienNhomThamGia.UseVisualStyleBackColor = true;
			label27.AutoSize = true;
			label27.Location = new System.Drawing.Point(4, 35);
			label27.Name = "label27";
			label27.Size = new System.Drawing.Size(155, 16);
			label27.TabIndex = 58;
			label27.Text = "Tu\u0300y cho\u0323n nho\u0301m đê\u0309 share:";
			base.AutoScaleDimensions = new System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(377, 642);
			base.Controls.Add(panel1);
			Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			base.Name = "fHDDangBaiTheoID";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			Text = "Cấu hình tương tác";
			base.Load += new System.EventHandler(FConfigInteract_Load);
			pnlHeader.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			plDangBaiLenPage.ResumeLayout(false);
			plDangBaiLenPage.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudCountPageTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudCountPageFrom).EndInit();
			plDangBaiLenNhom.ResumeLayout(false);
			plDangBaiLenNhom.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nudCountGroupTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudCountGroupFrom).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayTo).EndInit();
			((System.ComponentModel.ISupportInitialize)nudDelayFrom).EndInit();
			bunifuCards1.ResumeLayout(false);
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			ResumeLayout(false);
		}
	}
}
